const PLANET_RADIUS_METERS: f32 = 4000000.0;
// Material/height tiles are intentionally denser than the fixed 32x32 chunk
// grid, so material detail and coastline transitions do not inherit mesh size.
const MATERIAL_TILE_LOGICAL_QUADS: f32 = 128.0;
const TILE_GUTTER: f32 = 1.0;
const MATERIAL_TILE_LAST_STORED_COORD: i32 = 130;
const ATMOSPHERE_HEIGHT_METERS: f32 = 360000.0;
const ATMOSPHERE_EDGE_FADE_METERS: f32 = 240000.0;
const ATMOSPHERE_RADIUS_METERS: f32 = PLANET_RADIUS_METERS + ATMOSPHERE_HEIGHT_METERS;
const RAYLEIGH_SCALE_HEIGHT_METERS: f32 = 36000.0;
const MIE_SCALE_HEIGHT_METERS: f32 = 4800.0;
const RAYLEIGH_COEFFICIENT: vec3<f32> = vec3<f32>(5.8e-6, 13.5e-6, 33.1e-6);
const MIE_COEFFICIENT: vec3<f32> = vec3<f32>(21.0e-6);
const MIE_G: f32 = 0.76;
const SOLAR_RADIANCE: f32 = 4.0;
// Artistic surface exposure only: this does not alter sky scattering or the
// camera-facing sun disc.
const SURFACE_SUNLIGHT_SCALE: f32 = 5.0;
const SKY_DIFFUSE_LIGHT_SCALE: f32 = 0.18;

struct Camera {
    projection_matrix: mat4x4<f32>,
    camera_forward: vec4<f32>,
    camera_right: vec4<f32>,
    camera_up: vec4<f32>,
    camera_planet_direction_view_altitude: vec4<f32>,
    sun_direction: vec4<f32>,
    sun_direction_view: vec4<f32>,
    projection: vec4<f32>,
}

@group(0) @binding(0)
var<uniform> camera: Camera;

@group(1) @binding(0)
var height_map: texture_2d<f32>;

@group(1) @binding(1)
var biome_map: texture_2d<u32>;

@group(1) @binding(2)
var moisture_map: texture_2d<f32>;

@group(1) @binding(3)
var environment_map: texture_cube<f32>;

@group(1) @binding(4)
var environment_sampler: sampler;

struct VertexInput {
    @location(0) anchor_relative_position: vec3<f32>,
    @location(1) sphere_direction: vec3<f32>,
    @location(2) tile_uv: vec2<f32>,
    @location(3) skirt_depth_meters: f32,
    @location(4) anchor_view_position: vec3<f32>,
    @location(5) source_uv_scale: vec2<f32>,
    @location(6) source_uv_offset: vec2<f32>,
    @location(7) terrain_info: u32,
    @location(8) lod_transition: vec2<f32>,
}

struct VertexOutput {
    @builtin(position) position: vec4<f32>,
    @location(0) camera_relative_view_position: vec3<f32>,
    @location(1) world_normal: vec3<f32>,
    @location(2) aerial_color: vec3<f32>,
    @location(3) lod_transition: vec2<f32>,
    @location(4) surface_direction: vec3<f32>,
    @location(5) ocean: f32,
    @location(6) source_uv: vec2<f32>,
    @location(7) outmap: f32,
}

struct OceanWaveContribution {
    horizontal_displacement: vec3<f32>,
    vertical_displacement: f32,
    slope: vec3<f32>,
}

struct OceanSurface {
    horizontal_displacement: vec3<f32>,
    vertical_displacement: f32,
    normal: vec3<f32>,
}

fn planet_to_view(vector: vec3<f32>) -> vec3<f32> {
    return vec3<f32>(
        dot(vector, camera.camera_right.xyz),
        dot(vector, camera.camera_up.xyz),
        -dot(vector, camera.camera_forward.xyz),
    );
}

fn view_to_planet(vector: vec3<f32>) -> vec3<f32> {
    return camera.camera_right.xyz * vector.x
        + camera.camera_up.xyz * vector.y
        - camera.camera_forward.xyz * vector.z;
}

fn uses_outmap(terrain_info: u32) -> bool {
    return (terrain_info & 1u) != 0u;
}

fn cube_face(terrain_info: u32) -> u32 {
    return (terrain_info >> 1u) & 0x7u;
}

fn requested_level(terrain_info: u32) -> u32 {
    return (terrain_info >> 4u) & 0x1fu;
}

fn placeholder_octave(direction: vec3<f32>, frequency: f32, amplitude: f32) -> f32 {
    let wave = sin(frequency * direction.x) - direction.x * sin(frequency)
        + sin(1.375 * frequency * direction.y)
        + sin(1.75 * frequency * direction.z);
    return amplitude * wave / 4.0;
}

fn placeholder_height(direction: vec3<f32>) -> f32 {
    return placeholder_octave(direction, 8.0, 2800.0)
        + placeholder_octave(direction, 512.0, 600.0)
        + placeholder_octave(direction, 32768.0, 100.0)
        + placeholder_octave(direction, 2097152.0, 3.0);
}

fn sample_height(source_uv: vec2<f32>) -> f32 {
    let gutter_uv = 1.0 / MATERIAL_TILE_LOGICAL_QUADS;
    let coordinate = vec2<f32>(TILE_GUTTER)
        + clamp(source_uv, vec2<f32>(-gutter_uv), vec2<f32>(1.0 + gutter_uv))
            * MATERIAL_TILE_LOGICAL_QUADS;
    let lower = vec2<i32>(floor(coordinate));
    let upper = min(
        lower + vec2<i32>(1),
        vec2<i32>(MATERIAL_TILE_LAST_STORED_COORD),
    );
    let amount = fract(coordinate);
    let lower_left = textureLoad(height_map, lower, 0).x;
    let lower_right = textureLoad(height_map, vec2<i32>(upper.x, lower.y), 0).x;
    let upper_left = textureLoad(height_map, vec2<i32>(lower.x, upper.y), 0).x;
    let upper_right = textureLoad(height_map, upper, 0).x;
    return mix(
        mix(lower_left, lower_right, amount.x),
        mix(upper_left, upper_right, amount.x),
        amount.y,
    );
}

fn terrain_height(outmap: bool, source_uv: vec2<f32>, direction: vec3<f32>) -> f32 {
    if outmap {
        return sample_height(source_uv);
    }
    return placeholder_height(direction);
}

fn gerstner_wave(
    direction: vec3<f32>,
    wave_axis: vec3<f32>,
    wavelength_meters: f32,
    amplitude_meters: f32,
    speed_meters_per_second: f32,
    steepness: f32,
    time_seconds: f32,
) -> OceanWaveContribution {
    let axis = normalize(wave_axis);
    let tangent_unnormalized = axis - direction * dot(axis, direction);
    let tangent_length = length(tangent_unnormalized);
    if tangent_length < 1.0e-4 {
        return OceanWaveContribution(vec3<f32>(0.0), 0.0, vec3<f32>(0.0));
    }
    let tangent = tangent_unnormalized / tangent_length;
    let wave_number = 6.2831853 / wavelength_meters;
    let phase = wave_number
        * (dot(direction, axis) * PLANET_RADIUS_METERS + speed_meters_per_second * time_seconds);
    return OceanWaveContribution(
        tangent * (steepness * amplitude_meters * cos(phase)),
        amplitude_meters * sin(phase),
        tangent * (amplitude_meters * wave_number * cos(phase)),
    );
}

fn ocean_surface(direction: vec3<f32>, time_seconds: f32) -> OceanSurface {
    let first = gerstner_wave(direction, vec3<f32>(0.9, 0.1, 0.4), 900.0, 1.5, 4.0, 0.45, time_seconds);
    let second = gerstner_wave(direction, vec3<f32>(-0.3, 0.4, 0.85), 420.0, 0.85, 5.0, 0.40, time_seconds);
    let third = gerstner_wave(direction, vec3<f32>(0.55, -0.75, 0.35), 160.0, 0.45, 6.5, 0.34, time_seconds);
    let fourth = gerstner_wave(direction, vec3<f32>(-0.75, -0.2, 0.63), 65.0, 0.22, 8.0, 0.28, time_seconds);
    let fifth = gerstner_wave(direction, vec3<f32>(0.2, 0.95, -0.24), 24.0, 0.11, 10.0, 0.20, time_seconds);
    let sixth = gerstner_wave(direction, vec3<f32>(-0.5, 0.7, -0.5), 9.0, 0.05, 12.0, 0.14, time_seconds);
    let horizontal = first.horizontal_displacement + second.horizontal_displacement
        + third.horizontal_displacement + fourth.horizontal_displacement
        + fifth.horizontal_displacement + sixth.horizontal_displacement;
    let vertical = first.vertical_displacement + second.vertical_displacement
        + third.vertical_displacement + fourth.vertical_displacement
        + fifth.vertical_displacement + sixth.vertical_displacement;
    let slope = first.slope + second.slope + third.slope + fourth.slope + fifth.slope + sixth.slope;
    return OceanSurface(horizontal, vertical, normalize(direction - slope));
}

fn density(altitude_meters: f32, scale_height_meters: f32) -> f32 {
    let clamped_altitude_meters = max(altitude_meters, 0.0);
    let edge_fade = 1.0 - smoothstep(
        ATMOSPHERE_HEIGHT_METERS - ATMOSPHERE_EDGE_FADE_METERS,
        ATMOSPHERE_HEIGHT_METERS,
        clamped_altitude_meters,
    );
    return exp(-clamped_altitude_meters / scale_height_meters) * edge_fade;
}

fn phase_rayleigh(cos_theta: f32) -> f32 {
    return 3.0 * (1.0 + cos_theta * cos_theta) / (16.0 * 3.14159265);
}

fn phase_mie(cos_theta: f32) -> f32 {
    let g_squared = MIE_G * MIE_G;
    let denominator = max(1.0 + g_squared - 2.0 * MIE_G * cos_theta, 1.0e-4);
    return 3.0 * (1.0 - g_squared) * (1.0 + cos_theta * cos_theta)
        / (8.0 * 3.14159265 * (2.0 + g_squared) * pow(denominator, 1.5));
}

fn transmittance(
    start_altitude_meters: f32,
    end_altitude_meters: f32,
    distance_meters: f32,
) -> vec3<f32> {
    let rayleigh_density = 0.5
        * (density(start_altitude_meters, RAYLEIGH_SCALE_HEIGHT_METERS)
            + density(end_altitude_meters, RAYLEIGH_SCALE_HEIGHT_METERS));
    let mie_density = 0.5
        * (density(start_altitude_meters, MIE_SCALE_HEIGHT_METERS)
            + density(end_altitude_meters, MIE_SCALE_HEIGHT_METERS));
    return exp(-(RAYLEIGH_COEFFICIENT * rayleigh_density + MIE_COEFFICIENT * mie_density)
        * max(distance_meters, 0.0));
}

fn atmosphere_interval(radius_meters: f32, radial_dot_ray: f32) -> vec2<f32> {
    let discriminant = radial_dot_ray * radial_dot_ray
        + ATMOSPHERE_RADIUS_METERS * ATMOSPHERE_RADIUS_METERS
        - radius_meters * radius_meters;
    if discriminant <= 0.0 {
        return vec2<f32>(-1.0);
    }
    let root = sqrt(discriminant);
    return vec2<f32>(-radial_dot_ray - root, -radial_dot_ray + root);
}

fn atmosphere_exit_distance(radius_meters: f32, radial_dot_ray: f32) -> f32 {
    return max(atmosphere_interval(radius_meters, radial_dot_ray).y, 0.0);
}

fn altitude_along_ray(radius_meters: f32, radial_dot_ray: f32, distance_meters: f32) -> f32 {
    return sqrt(
        radius_meters * radius_meters
            + 2.0 * radial_dot_ray * distance_meters
            + distance_meters * distance_meters,
    ) - PLANET_RADIUS_METERS;
}

fn sun_is_occluded(radius_meters: f32, radial_dot_sun: f32) -> bool {
    let discriminant = radial_dot_sun * radial_dot_sun
        - (radius_meters * radius_meters - PLANET_RADIUS_METERS * PLANET_RADIUS_METERS);
    return radial_dot_sun < 0.0 && discriminant >= 0.0;
}

fn surface_direct_sun_transmittance(
    surface_direction: vec3<f32>,
    surface_altitude_meters: f32,
    sun_direction: vec3<f32>,
) -> vec3<f32> {
    let surface_radius = PLANET_RADIUS_METERS + surface_altitude_meters;
    let radial_dot_sun = surface_radius * dot(surface_direction, sun_direction);
    if sun_is_occluded(surface_radius, radial_dot_sun) {
        return vec3<f32>(0.0);
    }

    // The generic endpoint-average estimate spans the full 360km shell for
    // a noon surface point. That makes the near-zero density at its top count
    // as half the density of the entire path, nearly extinguishing direct
    // daylight before the existing surface-only intensity scale can matter.
    // Estimate a local scale-height air mass instead. It retains directional
    // warm attenuation near the terminator without altering sky scattering.
    let sun_zenith_cosine = max(dot(surface_direction, sun_direction), 0.0);
    let air_mass = min(1.0 / max(sun_zenith_cosine, 0.08), 12.0);
    let rayleigh_optical_depth = RAYLEIGH_COEFFICIENT
        * density(surface_altitude_meters, RAYLEIGH_SCALE_HEIGHT_METERS)
        * RAYLEIGH_SCALE_HEIGHT_METERS
        * air_mass;
    let mie_optical_depth = MIE_COEFFICIENT
        * density(surface_altitude_meters, MIE_SCALE_HEIGHT_METERS)
        * MIE_SCALE_HEIGHT_METERS
        * air_mass;
    return exp(-(rayleigh_optical_depth + mie_optical_depth));
}

fn sky_diffuse_irradiance(
    surface_direction: vec3<f32>,
    surface_altitude_meters: f32,
    sun_direction: vec3<f32>,
) -> vec3<f32> {
    let surface_radius = PLANET_RADIUS_METERS + surface_altitude_meters;
    let radial_dot_sun = surface_radius * dot(surface_direction, sun_direction);
    if sun_is_occluded(surface_radius, radial_dot_sun) {
        return vec3<f32>(0.0);
    }

    // A compact hemispherical approximation of Rayleigh/Mie sky fill. The
    // fraction removed from direct daylight is available as coloured diffuse
    // illumination from the visible sky, so terrain is not direct-lit only.
    let direct_transmittance = surface_direct_sun_transmittance(
        surface_direction,
        surface_altitude_meters,
        sun_direction,
    );
    let sun_elevation = max(dot(surface_direction, sun_direction), 0.0);
    let daylight_weight = mix(0.35, 1.0, smoothstep(0.0, 0.25, sun_elevation));
    return (vec3<f32>(1.0) - direct_transmittance)
        * (SKY_DIFFUSE_LIGHT_SCALE * daylight_weight);
}

fn aerial_view_transmittance(
    start_altitude_meters: f32,
    end_altitude_meters: f32,
    atmospheric_view_length_meters: f32,
    surface_to_camera_zenith_cosine: f32,
) -> vec3<f32> {
    let rayleigh_density = 0.5
        * (density(start_altitude_meters, RAYLEIGH_SCALE_HEIGHT_METERS)
            + density(end_altitude_meters, RAYLEIGH_SCALE_HEIGHT_METERS));
    let mie_density = 0.5
        * (density(start_altitude_meters, MIE_SCALE_HEIGHT_METERS)
            + density(end_altitude_meters, MIE_SCALE_HEIGHT_METERS));
    let air_mass = min(1.0 / max(surface_to_camera_zenith_cosine, 0.08), 12.0);

    // This remains an endpoint-average optical-depth estimate, but a radial
    // space-to-ground ray must not count the entire tall shell as half-dense.
    // Two local scale heights reproduce that column using the same endpoint
    // average, while the air-mass factor retains long, opaque horizon paths.
    let rayleigh_path_length = min(
        atmospheric_view_length_meters,
        2.0 * RAYLEIGH_SCALE_HEIGHT_METERS * air_mass,
    );
    let mie_path_length = min(
        atmospheric_view_length_meters,
        2.0 * MIE_SCALE_HEIGHT_METERS * air_mass,
    );
    return exp(-(
        RAYLEIGH_COEFFICIENT * rayleigh_density * rayleigh_path_length
            + MIE_COEFFICIENT * mie_density * mie_path_length
    ));
}

fn aerial_perspective(
    lit_surface_color: vec3<f32>,
    camera_relative_view_position: vec3<f32>,
    surface_direction: vec3<f32>,
    surface_altitude_meters: f32,
) -> vec3<f32> {
    let distance_meters = length(camera_relative_view_position);
    let camera_altitude_meters = camera.camera_planet_direction_view_altitude.w;
    let view_direction = normalize(camera_relative_view_position);
    let sun_direction = normalize(camera.sun_direction.xyz);
    let sun_direction_view = normalize(camera.sun_direction_view.xyz);
    let camera_radius = PLANET_RADIUS_METERS + camera_altitude_meters;
    let radial_dot_view = camera_radius
        * dot(camera.camera_planet_direction_view_altitude.xyz, view_direction);
    let view_interval = atmosphere_interval(camera_radius, radial_dot_view);
    let view_start = max(view_interval.x, 0.0);
    let view_end = min(view_interval.y, distance_meters);
    if view_end <= view_start {
        return lit_surface_color;
    }
    let atmospheric_view_length = view_end - view_start;
    let atmospheric_view_start_altitude = altitude_along_ray(
        camera_radius,
        radial_dot_view,
        view_start,
    );
    let atmospheric_view_end_altitude = altitude_along_ray(
        camera_radius,
        radial_dot_view,
        view_end,
    );
    let surface_radius = PLANET_RADIUS_METERS + surface_altitude_meters;
    let radial_dot_sun = surface_radius * dot(surface_direction, sun_direction);
    let sun_distance = atmosphere_exit_distance(surface_radius, radial_dot_sun);
    let sun_transmittance = select(
        transmittance(surface_altitude_meters, ATMOSPHERE_HEIGHT_METERS, sun_distance),
        vec3<f32>(0.0),
        sun_is_occluded(surface_radius, radial_dot_sun),
    );
    let surface_to_camera_zenith_cosine = max(
        dot(planet_to_view(surface_direction), -view_direction),
        0.0,
    );
    let view_transmittance = aerial_view_transmittance(
        atmospheric_view_start_altitude,
        atmospheric_view_end_altitude,
        atmospheric_view_length,
        surface_to_camera_zenith_cosine,
    );
    let average_rayleigh_density = 0.5
        * (density(
            atmospheric_view_start_altitude,
            RAYLEIGH_SCALE_HEIGHT_METERS,
        ) + density(
            atmospheric_view_end_altitude,
            RAYLEIGH_SCALE_HEIGHT_METERS,
        ));
    let average_mie_density = 0.5
        * (density(atmospheric_view_start_altitude, MIE_SCALE_HEIGHT_METERS)
            + density(atmospheric_view_end_altitude, MIE_SCALE_HEIGHT_METERS));
    let cos_theta = dot(view_direction, sun_direction_view);
    let in_scatter = sun_transmittance
        * (RAYLEIGH_COEFFICIENT * average_rayleigh_density * phase_rayleigh(cos_theta)
            + MIE_COEFFICIENT * average_mie_density * phase_mie(cos_theta))
        * atmospheric_view_length
        * SOLAR_RADIANCE;
    return lit_surface_color * view_transmittance + in_scatter;
}

fn sample_biome(source_uv: vec2<f32>) -> u32 {
    let coordinate = vec2<i32>(round(
        vec2<f32>(TILE_GUTTER)
            + clamp(source_uv, vec2<f32>(0.0), vec2<f32>(1.0))
                * MATERIAL_TILE_LOGICAL_QUADS,
    ));
    return textureLoad(biome_map, coordinate, 0).x;
}

fn sample_moisture(source_uv: vec2<f32>) -> f32 {
    let coordinate = vec2<i32>(round(
        vec2<f32>(TILE_GUTTER)
            + clamp(source_uv, vec2<f32>(0.0), vec2<f32>(1.0))
                * MATERIAL_TILE_LOGICAL_QUADS,
    ));
    return textureLoad(moisture_map, coordinate, 0).x;
}

fn face_tangent_u(face: u32) -> vec3<f32> {
    switch face {
        case 0u: { return vec3<f32>(0.0, 0.0, -1.0); }
        case 1u: { return vec3<f32>(0.0, 0.0, 1.0); }
        case 2u: { return vec3<f32>(1.0, 0.0, 0.0); }
        case 3u: { return vec3<f32>(1.0, 0.0, 0.0); }
        case 4u: { return vec3<f32>(1.0, 0.0, 0.0); }
        default: { return vec3<f32>(-1.0, 0.0, 0.0); }
    }
}

fn face_tangent_v(face: u32) -> vec3<f32> {
    switch face {
        case 0u: { return vec3<f32>(0.0, 1.0, 0.0); }
        case 1u: { return vec3<f32>(0.0, 1.0, 0.0); }
        case 2u: { return vec3<f32>(0.0, 0.0, -1.0); }
        case 3u: { return vec3<f32>(0.0, 0.0, 1.0); }
        case 4u: { return vec3<f32>(0.0, 1.0, 0.0); }
        default: { return vec3<f32>(0.0, 1.0, 0.0); }
    }
}

fn face_component(direction: vec3<f32>, face: u32) -> f32 {
    if face <= 1u {
        return abs(direction.x);
    }
    if face <= 3u {
        return abs(direction.y);
    }
    return abs(direction.z);
}

fn displaced_surface_normal(
    direction: vec3<f32>,
    source_uv: vec2<f32>,
    source_uv_scale: vec2<f32>,
    terrain_info: u32,
) -> vec3<f32> {
    let face = cube_face(terrain_info);
    let tangent_u = face_tangent_u(face);
    let tangent_v = face_tangent_v(face);
    let cube_position = direction / max(face_component(direction, face), 1.0e-6);
    let cube_step = 2.0
        / (MATERIAL_TILE_LOGICAL_QUADS * exp2(f32(requested_level(terrain_info))));
    let left_direction = normalize(cube_position - tangent_u * cube_step);
    let right_direction = normalize(cube_position + tangent_u * cube_step);
    let down_direction = normalize(cube_position - tangent_v * cube_step);
    let up_direction = normalize(cube_position + tangent_v * cube_step);
    let uv_step = source_uv_scale / MATERIAL_TILE_LOGICAL_QUADS;
    let outmap = uses_outmap(terrain_info);
    let left_height = terrain_height(outmap, source_uv - vec2<f32>(uv_step.x, 0.0), left_direction);
    let right_height = terrain_height(outmap, source_uv + vec2<f32>(uv_step.x, 0.0), right_direction);
    let down_height = terrain_height(outmap, source_uv - vec2<f32>(0.0, uv_step.y), down_direction);
    let up_height = terrain_height(outmap, source_uv + vec2<f32>(0.0, uv_step.y), up_direction);
    let tangent_delta_u = (right_direction - left_direction) * PLANET_RADIUS_METERS
        + right_direction * right_height
        - left_direction * left_height;
    let tangent_delta_v = (up_direction - down_direction) * PLANET_RADIUS_METERS
        + up_direction * up_height
        - down_direction * down_height;
    return normalize(cross(tangent_delta_u, tangent_delta_v));
}

fn srgb_to_linear(color: vec3<f32>) -> vec3<f32> {
    let low = color / 12.92;
    let high = pow((color + vec3<f32>(0.055)) / 1.055, vec3<f32>(2.4));
    return select(high, low, color <= vec3<f32>(0.04045));
}

fn biome_color(biome: u32) -> vec3<f32> {
    var display_color: vec3<f32>;
    switch biome {
        case 0u: { display_color = vec3<f32>(20.0, 65.0, 150.0) / 255.0; }
        case 1u: { display_color = vec3<f32>(45.0, 115.0, 190.0) / 255.0; }
        case 2u: { display_color = vec3<f32>(230.0, 240.0, 245.0) / 255.0; }
        case 3u: { display_color = vec3<f32>(130.0, 145.0, 120.0) / 255.0; }
        case 4u: { display_color = vec3<f32>(45.0, 105.0, 55.0) / 255.0; }
        case 5u: { display_color = vec3<f32>(105.0, 145.0, 65.0) / 255.0; }
        case 6u: { display_color = vec3<f32>(25.0, 125.0, 55.0) / 255.0; }
        case 7u: { display_color = vec3<f32>(205.0, 180.0, 105.0) / 255.0; }
        case 8u: { display_color = vec3<f32>(105.0, 100.0, 95.0) / 255.0; }
        default: { display_color = vec3<f32>(205.0, 210.0, 210.0) / 255.0; }
    }
    return srgb_to_linear(display_color);
}

fn terrain_material_color(outmap: bool, source_uv: vec2<f32>, height_meters: f32) -> vec3<f32> {
    var color = vec3<f32>(0.32, 0.58, 0.74);
    if !outmap {
        return color;
    }

    let biome = sample_biome(source_uv);
    let moisture = sample_moisture(source_uv);
    color = biome_color(biome) * mix(0.88, 1.06, moisture);
    if biome != 2u {
        // Use bilinear terrain height, not a nearest biome class, for the
        // coast. This gives a continuous shallow-water/beach transition.
        let beach = 1.0 - smoothstep(20.0, 220.0, height_meters);
        color = mix(color, srgb_to_linear(vec3<f32>(0.48, 0.40, 0.23)), beach * 0.65);
    }
    return color;
}

fn outmap_ocean_coverage(outmap: bool, height_meters: f32) -> f32 {
    if !outmap {
        return select(0.0, 1.0, height_meters <= 0.0);
    }
    return 1.0 - smoothstep(-80.0, 120.0, height_meters);
}

fn ocean_lighting(
    normal: vec3<f32>,
    camera_relative_view_position: vec3<f32>,
    sun_transmittance: vec3<f32>,
    sky_diffuse: vec3<f32>,
) -> vec3<f32> {
    let view_direction = normalize(-camera_relative_view_position);
    let normal_view = normalize(planet_to_view(normal));
    let sun_direction_view = normalize(camera.sun_direction_view.xyz);
    let reflection_direction = view_to_planet(reflect(-view_direction, normal_view));
    let reflected_color = textureSampleLevel(
        environment_map,
        environment_sampler,
        reflection_direction,
        0.0,
    ).rgb;
    let facing = max(dot(normal_view, view_direction), 0.0);
    let fresnel = vec3<f32>(0.02) + vec3<f32>(0.98) * pow(1.0 - facing, 5.0);
    let half_vector = normalize(sun_direction_view + view_direction);
    let specular = pow(max(dot(normal_view, half_vector), 0.0), 128.0);
    let daylight = max(max(sun_transmittance.x, sun_transmittance.y), sun_transmittance.z);
    let diffuse = vec3<f32>(0.02, 0.12, 0.50)
        * (sky_diffuse + sun_transmittance * (0.4 * SURFACE_SUNLIGHT_SCALE));
    // The Phase 6 cubemap is static. It represents daytime sky reflection, so
    // gate it by direct daylight instead of reflecting a bright blue sky from
    // the fully occluded hemisphere.
    return diffuse + reflected_color * fresnel * daylight
        + sun_transmittance * specular * fresnel * (12.0 * SURFACE_SUNLIGHT_SCALE);
}

fn ocean_with_aerial_perspective(
    direction: vec3<f32>,
    camera_relative_view_position: vec3<f32>,
    sun_direction: vec3<f32>,
) -> vec3<f32> {
    let surface = ocean_surface(direction, camera.projection.z);
    let sun_transmittance = surface_direct_sun_transmittance(
        direction,
        surface.vertical_displacement,
        sun_direction,
    );
    let sky_diffuse = sky_diffuse_irradiance(
        direction,
        surface.vertical_displacement,
        sun_direction,
    );
    let water_color = ocean_lighting(
        surface.normal,
        camera_relative_view_position,
        sun_transmittance,
        sky_diffuse,
    );
    return aerial_perspective(
        water_color,
        camera_relative_view_position,
        direction,
        surface.vertical_displacement,
    );
}

@vertex
fn vs_main(input: VertexInput) -> VertexOutput {
    let direction = normalize(input.sphere_direction);
    let source_uv = input.source_uv_offset + input.tile_uv * input.source_uv_scale;
    let outmap = uses_outmap(input.terrain_info);
    let height = terrain_height(outmap, source_uv, direction);
    let ocean = height <= 0.0;
    let wave_surface = ocean_surface(direction, camera.projection.z);
    let surface_height = select(height, wave_surface.vertical_displacement, ocean);
    let local_planet_position = input.anchor_relative_position
        + direction * (surface_height - input.skirt_depth_meters)
        + select(vec3<f32>(0.0), wave_surface.horizontal_displacement, ocean);
    let camera_relative_view_position = input.anchor_view_position
        + planet_to_view(local_planet_position);
    var normal = displaced_surface_normal(
        direction,
        source_uv,
        input.source_uv_scale,
        input.terrain_info,
    );
    if ocean {
        normal = wave_surface.normal;
    }
    let sun_direction = normalize(camera.sun_direction.xyz);
    let sun_transmittance = surface_direct_sun_transmittance(
        direction,
        surface_height,
        sun_direction,
    );
    let sky_diffuse = sky_diffuse_irradiance(direction, surface_height, sun_direction)
        * max(dot(normal, direction), 0.0);
    let direct_light = max(dot(normal, sun_direction), 0.14);
    let lit_surface_color = terrain_material_color(outmap, source_uv, height)
        * (sky_diffuse + sun_transmittance * direct_light * SURFACE_SUNLIGHT_SCALE);
    return VertexOutput(
        camera.projection_matrix * vec4<f32>(camera_relative_view_position, 1.0),
        camera_relative_view_position,
        normal,
        aerial_perspective(
            lit_surface_color,
            camera_relative_view_position,
            direction,
            surface_height,
        ),
        input.lod_transition,
        direction,
        select(0.0, 1.0, ocean),
        source_uv,
        select(0.0, 1.0, outmap),
    );
}

fn bayer_dither(fragment_position: vec4<f32>) -> f32 {
    let pattern = array<u32, 16>(
        0u, 8u, 2u, 10u,
        12u, 4u, 14u, 6u,
        3u, 11u, 1u, 9u,
        15u, 7u, 13u, 5u,
    );
    let pixel = vec2<u32>(u32(fragment_position.x), u32(fragment_position.y));
    let index = (pixel.y & 3u) * 4u + (pixel.x & 3u);
    return (f32(pattern[index]) + 0.5) / 16.0;
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    let transition_progress = input.lod_transition.x;
    let incoming = input.lod_transition.y > 0.5;
    let threshold = bayer_dither(input.position);
    if (incoming && threshold >= transition_progress)
        || (!incoming && threshold < transition_progress)
    {
        discard;
    }
    let direction = normalize(input.surface_direction);
    let sun_direction = normalize(camera.sun_direction.xyz);
    if input.ocean > 0.5 {
        return vec4<f32>(
            ocean_with_aerial_perspective(
                direction,
                input.camera_relative_view_position,
                sun_direction,
            ),
            1.0,
        );
    }
    let outmap = input.outmap > 0.5;
    if !outmap {
        return vec4<f32>(input.aerial_color, 1.0);
    }
    let terrain_height_meters = terrain_height(outmap, input.source_uv, direction);
    let ocean_coverage = outmap_ocean_coverage(outmap, terrain_height_meters);
    if ocean_coverage <= 0.0 {
        return vec4<f32>(input.aerial_color, 1.0);
    }
    let water_with_aerial_perspective = ocean_with_aerial_perspective(
        direction,
        input.camera_relative_view_position,
        sun_direction,
    );
    return vec4<f32>(
        mix(
            input.aerial_color,
            water_with_aerial_perspective,
            ocean_coverage,
        ),
        1.0,
    );
}
