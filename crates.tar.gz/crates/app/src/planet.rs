use std::{
    cmp::Ordering,
    collections::{BinaryHeap, HashMap, HashSet},
};

use catinthegarden_coretypes::TILE_LOGICAL_SIZE;
use glam::{DQuat, DVec3, IVec3, Mat4, Vec3, Vec4};

/// Re-exported rather than restated. The baker writes outmap tiles against the
/// coretypes radius, so a second literal here could silently place the runtime
/// surface on a different sphere than the data it streams.
pub use catinthegarden_coretypes::PLANET_RADIUS_METERS;
/// Surface swimming may enter the water below sea level while remaining well
/// outside the solid planet. This covers the maximum storm-wave trough and
/// keeps LOD distance math defined until an underwater renderer exists.
pub const MINIMUM_CAMERA_RADIUS_METERS: f64 = PLANET_RADIUS_METERS - 100.0;
/// Full-screen post-processing switches. Keeping these beside the planet's
/// other visual constants makes expensive presentation stages easy to bisect.
pub const BLUR_ENABLED: bool = false;
pub const BLOOM_ENABLED: bool = false;
pub const HDR_EFFECT_ENABLED: bool = false;
pub const AUTO_EXPOSURE_ENABLED: bool = false;
pub const CHUNK_GRID_QUADS: usize = 32;
pub const CHUNK_GRID_VERTICES: usize = CHUNK_GRID_QUADS + 1;
/// Near-flight chunks covered by the raster source window get twice the
/// canonical sampling density without increasing the global leaf budget.
pub const NEAR_FIELD_GRID_QUADS: usize = 40;
pub const MAX_LOD_LEVEL: u8 = 18;
/// The coarsest rendered quadtree leaf. Screen-space error raises the LOD into
/// finer levels only when their geometric error can affect visible pixels.
pub const MINIMUM_LOD_LEVEL: u8 = 2;
/// Historical test fixture for the fixed-policy selector tests. The adaptive
/// runtime renderer does not use it.
#[cfg(test)]
pub const FLAT_TRIANGLE_LOD_LEVEL: u8 = MINIMUM_LOD_LEVEL + 5;
/// Deliberately game-time-scaled so axial rotation is visible during normal play.
pub const PLANET_ROTATION_PERIOD_SECONDS: f64 = 15.0;
/// Earth's mean obliquity. With no simulated annual orbit yet, the default sun
/// uses the northern-solstice declination so the axial tilt is visible and
/// stable rather than implying seasons that are not implemented.
pub const EARTH_AXIAL_TILT_RADIANS: f64 = 23.439_281_f64.to_radians();
/// Hard leaf budget for the current one-draw-call-per-chunk renderer. At the
/// 640px reference size this still provides more mesh cells than pixels while
/// preventing narrow optical zoom from expanding into thousands of draws.
pub const DEFAULT_MAX_ACTIVE_CHUNKS: usize = 256;
/// When the leaf budget binds, retain the finest requested patches around the
/// camera and spend the remaining leaves on the lower-detail horizon. Without
/// this bounded bias, the level-normalised split priority can spend too much
/// of the budget on distant coarse demand, pulling the L6/L7 boundary inward.
const LOD_NEAR_DETAIL_PRIORITY_FLOOR: f64 = 0.35;
/// Half-angle of the low-flight view patch that receives the centre-ray
/// priority. Boosting only the single leaf under the crosshair creates a fine
/// needle surrounded by coarse neighbours; their edge filters then erase the
/// very detail the needle was selected to show. A small view-space cone keeps
/// the centre terrain coherent without raising the global leaf budget.
const LOD_VIEW_FOCUS_HALF_ANGLE_RADIANS: f64 = 12.0_f64.to_radians();
/// Strong enough to keep the whole patch ahead of the camera-centred bias;
/// this redistributes candidates and never changes the leaf count.
const LOD_VIEW_FOCUS_PRIORITY_BOOST: f64 = 16.0;
/// Measurement hook for the budget itself. The cap is load-bearing -- it is the
/// only thing holding the mountains under 40ms -- so the question that keeps
/// coming up is not "what should it be" but "is it binding, and by how much".
/// Answering that needs a run with the budget lifted clear of demand, and
/// rebuilding with an edited constant makes that a different binary each time.
pub fn max_active_chunks_from_env() -> usize {
    std::env::var("CATINGARDEN_MAX_ACTIVE_CHUNKS")
        .ok()
        .and_then(|value| value.trim().parse::<usize>().ok())
        .map(|value| value.max(FACE_COUNT as usize))
        .unwrap_or(DEFAULT_MAX_ACTIVE_CHUNKS)
}
pub const SKIRT_DEPTH_RATIO: f64 = 0.075;
/// Coarse fallback chunks can span hundreds of kilometres. Keep their skirts
/// deep enough to cover residual cracks without exposing coarse edge ribbons.
/// Runtime detail is continuous across mixed LODs, so only a shallow cap is
/// needed for mesh and tile sampling differences.
pub const MAX_SKIRT_DEPTH_METERS: f64 = 10.0;
pub const PLACEHOLDER_HEIGHT_OCTAVES: [(f64, f64); 4] = [
    (8.0, 2_800.0),
    (512.0, 600.0),
    (32_768.0, 100.0),
    (2_097_152.0, 3.0),
];
#[allow(dead_code)]
pub const PLACEHOLDER_HEIGHT_AMPLITUDE_METERS: f64 = 3_503.0;
/// Seam-safe, planet-wide high-frequency relief layered over baked land.
///
/// The baked outmap remains the source of macro geography. These bounded
/// octaves keep ancestor tile fallback visually useful during low flight
/// without privileging one pre-baked corridor. Each octave is coherent value
/// noise, rather than a single global sine wave: the latter created visibly
/// parallel, blanket-like ridges. Keep this table in sync with `planet.wgsl`
/// and mirror any changes in the CPU clearance tests below.
pub const GLOBAL_TERRAIN_DETAIL_OCTAVES: [(f64, f64, [f64; 3], f64); 4] = [
    (4_096.0, 80.0, [0.79, 0.52, -0.32], 0.37),
    (32_768.0, 24.0, [-0.23, 0.91, 0.41], 1.11),
    (262_144.0, 6.0, [0.61, -0.17, 0.77], 2.07),
    (2_097_152.0, 1.5, [-0.48, -0.66, 0.58], 2.73),
];
pub const GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS: f64 = 111.5;
/// Keep the direction-field noise in the material path, not geometry. Even at
/// physical amplitude its repeated hills overwhelmed the already detailed
/// baked landing tiles and read as an endless field of cones.
pub const GLOBAL_TERRAIN_DETAIL_HEIGHT_SCALE: f64 = 0.0;
/// Present positive ETOPO altitude at a uniform 4x while leaving sea level and
/// bathymetry unchanged. Keeping near and far equal makes the CPU clearance,
/// raster displacement/normals, ray hits/normals, and culling shell share one
/// height gradient at every camera altitude.
pub const OUTMAP_TERRAIN_NEAR_HEIGHT_SCALE: f64 = 4.0;
pub const OUTMAP_TERRAIN_FAR_HEIGHT_SCALE: f64 = 4.0;
pub const OUTMAP_TERRAIN_HEIGHT_BLEND_START_METERS: f64 = 100_000.0;
pub const OUTMAP_TERRAIN_HEIGHT_BLEND_END_METERS: f64 = 1_000_000.0;
/// Compatibility alias for conservative far-orbit bounds.
#[cfg(test)]
pub const OUTMAP_TERRAIN_HEIGHT_SCALE: f64 = OUTMAP_TERRAIN_FAR_HEIGHT_SCALE;
const DEFAULT_VERTICAL_FOV_RADIANS: f64 = 45.0_f64.to_radians();
/// The default 640px-high viewport needs roughly this optical field of view
/// before screen-space error naturally requests L18 from a 6,000km orbit.
pub const MIN_VERTICAL_FOV_DEGREES: f64 = 0.000_05;
pub const MAX_VERTICAL_FOV_DEGREES: f64 = 75.0;
pub const REFERENCE_VERTICAL_FOV_VIEWPORT_HEIGHT: u32 = 640;
const MIN_VERTICAL_FOV_RADIANS: f64 = MIN_VERTICAL_FOV_DEGREES.to_radians();
const MAX_VERTICAL_FOV_RADIANS: f64 = MAX_VERTICAL_FOV_DEGREES.to_radians();
const ZOOM_LOG_FOV_PER_WHEEL_STEP: f64 = 0.12;
pub const PLACEHOLDER_GEOMETRIC_ERROR_RATIO: f64 = 0.02;

/// Unresolved height error, separated by what is able to resolve it.
///
/// `baked` is the macro surface's own curvature and resampling error. A split
/// only pays it back while the child grid still has source texels it has not
/// read: past that point the child resamples the same bilinear patch as its
/// parent and returns exactly the same surface. `ladder` is what the runtime
/// detail ladder has left to show, and every split does resolve more of that,
/// all the way down to the finest octave.
///
/// Charging both terms everywhere is what made the selector ask for sub-pixel
/// geometry out at the mountains, where 151 of 256 chunks sat at L14 -- a 12m
/// mesh -- against L4 baked data at ~1953m per texel. The baked term there is
/// a demand no amount of splitting can satisfy.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct GeometricErrorRatio {
    pub baked: f64,
    pub ladder: f64,
}

impl GeometricErrorRatio {
    /// One indivisible error term, always resolvable. The analytic placeholder
    /// has no baked source to run out of.
    pub const fn uniform(ratio: f64) -> Self {
        Self {
            baked: ratio,
            ladder: 0.0,
        }
    }

    pub fn total(self) -> f64 {
        self.baked + self.ladder
    }

    fn for_node(self, baked_is_resolvable: bool) -> f64 {
        if baked_is_resolvable {
            self.total()
        } else {
            self.ladder
        }
    }

    #[cfg(test)]
    pub fn for_node_for_test(self, baked_is_resolvable: bool) -> f64 {
        self.for_node(baked_is_resolvable)
    }
}

pub const LOD_THRASH_WINDOW_UPDATES: u64 = 4;
/// Fine edges already stitch to a grid two levels coarser. Source-aware LOD
/// balancing enforces the same bound so a sparse high-detail patch cannot sit
/// directly beside a giant fallback node.
pub const MAX_ADJACENT_LOD_LEVEL_DELTA: u8 = 2;
pub fn default_sun_direction() -> DVec3 {
    // Preserve the established XZ azimuth while replacing its arbitrary 44
    // degree declination with Earth's 23.44 degree solstice orientation.
    let horizontal_direction = DVec3::new(0.4, 0.0, 0.6).normalize();
    horizontal_direction * EARTH_AXIAL_TILT_RADIANS.cos()
        + DVec3::Y * EARTH_AXIAL_TILT_RADIANS.sin()
}

pub fn minimum_vertical_fov_radians_for_viewport(viewport_height: u32) -> f64 {
    let reference_tangent = (MIN_VERTICAL_FOV_RADIANS * 0.5).tan();
    let scaled_tangent = reference_tangent * f64::from(viewport_height.max(1))
        / f64::from(REFERENCE_VERTICAL_FOV_VIEWPORT_HEIGHT);
    (2.0 * scaled_tangent.atan()).min(MAX_VERTICAL_FOV_RADIANS)
}

pub fn reference_vertical_fov_radians_for_viewport(
    reference_vertical_fov_radians: f64,
    viewport_height: u32,
) -> f64 {
    assert!(
        reference_vertical_fov_radians.is_finite()
            && reference_vertical_fov_radians > 0.0
            && reference_vertical_fov_radians < std::f64::consts::PI
    );
    let scaled_tangent = (reference_vertical_fov_radians * 0.5).tan()
        * f64::from(viewport_height.max(1))
        / f64::from(REFERENCE_VERTICAL_FOV_VIEWPORT_HEIGHT);
    (2.0 * scaled_tangent.atan()).clamp(
        minimum_vertical_fov_radians_for_viewport(viewport_height),
        MAX_VERTICAL_FOV_RADIANS,
    )
}
const FACE_COUNT: u8 = 6;
const FACE_BASES: [(DVec3, DVec3, DVec3); FACE_COUNT as usize] = [
    (DVec3::X, DVec3::NEG_Z, DVec3::Y),
    (DVec3::NEG_X, DVec3::Z, DVec3::Y),
    (DVec3::Y, DVec3::X, DVec3::NEG_Z),
    (DVec3::NEG_Y, DVec3::X, DVec3::Z),
    (DVec3::Z, DVec3::X, DVec3::Y),
    (DVec3::NEG_Z, DVec3::NEG_X, DVec3::Y),
];

/// Orthonormal camera axes retained in f64 until camera-relative values have
/// been transformed into view space. This avoids rotating multi-megameter
/// f32 offsets in the terrain shader at extremely narrow optical zooms.
#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) struct CameraViewBasis {
    forward: DVec3,
    right: DVec3,
    up: DVec3,
}

impl CameraViewBasis {
    pub(crate) fn from_forward(forward: DVec3) -> Self {
        Self::from_forward_and_up(forward, DVec3::Y)
    }

    pub(crate) fn from_forward_and_up(forward: DVec3, up_hint: DVec3) -> Self {
        assert!(forward.is_finite() && forward.length_squared() > 0.0);
        assert!(up_hint.is_finite() && up_hint.length_squared() > 0.0);
        let forward = forward.normalize();
        let right = forward.cross(up_hint).normalize_or_zero();
        let right = if right.length_squared() > 0.0 {
            right
        } else {
            forward.cross(DVec3::X).normalize()
        };
        let up = right.cross(forward).normalize();
        Self { forward, right, up }
    }

    pub(crate) fn world_to_view(self, vector: DVec3) -> DVec3 {
        DVec3::new(
            vector.dot(self.right),
            vector.dot(self.up),
            -vector.dot(self.forward),
        )
    }

    /// Inverse of [`Self::world_to_view`]. The surface probe turns depth
    /// samples back into planet-frame points, and has to invert this exact
    /// convention rather than restate it -- a sign slip here would move every
    /// probed point without making any of them look wrong.
    pub(crate) fn view_to_world(self, vector: DVec3) -> DVec3 {
        self.right * vector.x + self.up * vector.y - self.forward * vector.z
    }
}

/// A leaf in one of the six face-local quadtrees. Coordinates address a node
/// at `level`, so children are `(x * 2 + dx, y * 2 + dy)` at `level + 1`.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash, Ord, PartialOrd)]
pub struct QuadtreeNode {
    pub face: u8,
    pub level: u8,
    pub x: u32,
    pub y: u32,
}

impl QuadtreeNode {
    pub const fn root(face: u8) -> Self {
        Self {
            face,
            level: 0,
            x: 0,
            y: 0,
        }
    }

    pub fn children(self) -> [Self; 4] {
        assert!(
            self.level < MAX_LOD_LEVEL,
            "maximum LOD node has no children"
        );
        let level = self.level + 1;
        let x = self.x * 2;
        let y = self.y * 2;
        [
            Self {
                face: self.face,
                level,
                x,
                y,
            },
            Self {
                face: self.face,
                level,
                x: x + 1,
                y,
            },
            Self {
                face: self.face,
                level,
                x,
                y: y + 1,
            },
            Self {
                face: self.face,
                level,
                x: x + 1,
                y: y + 1,
            },
        ]
    }

    pub fn parent(self) -> Option<Self> {
        (self.level > 0).then(|| Self {
            face: self.face,
            level: self.level - 1,
            x: self.x / 2,
            y: self.y / 2,
        })
    }

    pub fn is_valid(self) -> bool {
        if self.face >= FACE_COUNT || self.level > MAX_LOD_LEVEL {
            return false;
        }
        let nodes_per_axis = 1_u32 << self.level;
        self.x < nodes_per_axis && self.y < nodes_per_axis
    }

    pub fn uv_bounds(self) -> [f64; 4] {
        assert!(self.is_valid(), "invalid quadtree node {self:?}");
        let nodes_per_axis = (1_u64 << self.level) as f64;
        let size = 2.0 / nodes_per_axis;
        let u_min = -1.0 + f64::from(self.x) * size;
        let v_min = -1.0 + f64::from(self.y) * size;
        [u_min, v_min, u_min + size, v_min + size]
    }

    pub fn center_direction(self) -> DVec3 {
        let [u_min, v_min, u_max, v_max] = self.uv_bounds();
        cube_face_direction(self.face, (u_min + u_max) * 0.5, (v_min + v_max) * 0.5)
    }

    #[cfg(test)]
    pub fn geometric_error_meters(self) -> f64 {
        self.geometric_error_meters_with_ratio(PLACEHOLDER_GEOMETRIC_ERROR_RATIO)
    }

    fn geometric_error_meters_with_ratio(self, geometric_error_ratio: f64) -> f64 {
        let root_triangle_spacing =
            PLANET_RADIUS_METERS * std::f64::consts::FRAC_PI_2 / CHUNK_GRID_QUADS as f64;
        // Triangle spacing is resolution, not approximation error. For the smooth analytic
        // placeholder, 2% of the edge is a conservative combined curvature and unresolved-sine
        // bound. Phase 4 replaces this with the baker's per-tile measured geometric error.
        root_triangle_spacing * geometric_error_ratio / f64::from(1_u32 << self.level)
    }
}

pub fn cube_face_basis(face: u8) -> (DVec3, DVec3, DVec3) {
    FACE_BASES
        .get(face as usize)
        .copied()
        .unwrap_or_else(|| panic!("invalid cube face {face}"))
}

pub fn cube_face_direction(face: u8, u: f64, v: f64) -> DVec3 {
    let (normal, tangent_u, tangent_v) = cube_face_basis(face);
    (normal + tangent_u * u + tangent_v * v).normalize()
}

pub fn planet_rotation_radians(sim_time_seconds: f64) -> f64 {
    (sim_time_seconds * std::f64::consts::TAU / PLANET_ROTATION_PERIOD_SECONDS)
        .rem_euclid(std::f64::consts::TAU)
}

/// Expresses a world-space vector in the rotating planet's local frame. The
/// renderer keeps all terrain/outmap data in this local frame and transforms
/// the f64 camera and sun inputs into it each frame.
pub fn planet_local_vector(world_vector: DVec3, planet_rotation_radians: f64) -> DVec3 {
    DQuat::from_rotation_y(-planet_rotation_radians).mul_vec3(world_vector)
}

/// Geographic longitude in the renderer's north-up outward surface frame.
/// A viewer looking inward from +X has screen-right/geographic east along -Z,
/// so this intentionally negates the grid's mathematical `atan2(z, x)` angle.
pub fn geographic_longitude_degrees(direction: DVec3) -> f64 {
    -direction.z.atan2(direction.x).to_degrees()
}

pub fn placeholder_height_meters(direction: DVec3) -> f64 {
    PLACEHOLDER_HEIGHT_OCTAVES
        .iter()
        .map(|(frequency, amplitude_meters)| {
            let wave = (frequency * direction.x).sin() - direction.x * frequency.sin()
                + (1.375 * frequency * direction.y).sin()
                + (1.75 * frequency * direction.z).sin();
            amplitude_meters * wave * 0.25
        })
        .sum()
}

/// The synthesised detail ladder, mirrored from `shared_planet.wgsl`. These
/// four must track the shader's `TERRAIN_DETAIL_*`; `shader_detail_ladder_
/// matches_the_cpu_clearance_ladder` in terrain.rs reads them back out of the
/// shader source and fails if they drift.
pub const TERRAIN_DETAIL_ROUGHNESS: f64 = 0.058;
/// Starts where the *coarsest* baked pyramid runs out, not the finest. See
/// shared_planet.wgsl: away from the sparse corridor the baked data is L4 with
/// 3.9km texels, so it carries nothing below about 7.8km, and the ladder used
/// to start at 256m -- leaving three octaves of hill-scale relief empty.
pub const TERRAIN_DETAIL_START_WAVELENGTH_METERS: f64 = 4096.0;
/// Keep the procedural ladder unboosted while the new ETOPO macro terrain is
/// evaluated. The former 8x long-wave gain added a repeating pattern of large
/// random basins and ridges; directional landform shaping can replace it in a
/// later, separately judged pass without removing the finer detail system.
pub const TERRAIN_DETAIL_LONG_GAIN: f64 = 1.0;
pub const TERRAIN_DETAIL_TILT_TAPER_METERS: f64 = 256.0;
pub const TERRAIN_DETAIL_OCTAVES: u32 = 13;
pub const TERRAIN_DETAIL_MIN_FILTER_METERS: f64 = 0.5;
/// Ridge fold and multifractal attenuation. Mirrors of the shader constants of
/// the same names; see shared_planet.wgsl for where the two ridge numbers come
/// from and why folding without them would lift every coastline.
pub const TERRAIN_DETAIL_RIDGE_SOFTNESS: f64 = 0.15;
pub const TERRAIN_DETAIL_RIDGE_CENTRE: f64 = 0.348_609;
pub const TERRAIN_DETAIL_RIDGE_SCALE: f64 = 2.063_534;
pub const TERRAIN_DETAIL_RIDGE_STRENGTH: f64 = 1.0;
/// Derived from the strength above -- `1 / sqrt((1-s)^2 + s^2)` -- because it
/// exists only to undo the variance a two-field blend loses. At full strength
/// there is no blend left to undo.
pub const TERRAIN_DETAIL_RIDGE_NORMALISATION: f64 = 1.0;
pub const TERRAIN_DETAIL_ATTENUATION_SLOPE: f64 = 4.0;
/// Fade each newly available outmap level in over two of that level's source
/// texels. Sparse child borders are constrained to their parents by the baker;
/// matching that hierarchy in the runtime detail filter prevents the
/// source-level change from opening a height discontinuity at those borders.
pub const TERRAIN_DETAIL_SOURCE_EDGE_FADE_TEXELS: f64 = 2.0;

/// What the GPU actually puts under the camera, evaluated on the CPU so flight
/// clearance and camera placement agree with the render.
///
/// The shader fades each octave against the spacing it is about to be sampled
/// at, so callers must provide that same filter when matching a rendered
/// surface. `terrain_detail_meters` retains the finest-filter convenience used
/// by offline terrain surveys.
///
/// Evaluated straight from the absolute direction in f64. The shader has to
/// split cell index from in-cell fraction to survive f32 at metre wavelengths;
/// f64 carries the whole domain coordinate outright, so the two agree on
/// amplitude and character without agreeing bit for bit.
/// Spacing of the baked samples at a pyramid level: the scale below which the
/// baked data carries nothing, and therefore where the ladder starts.
#[cfg_attr(not(test), allow(dead_code))]
pub fn baked_sample_spacing_meters(source_level: u8) -> f64 {
    baked_sample_spacing_meters_at_level(f64::from(source_level))
}

fn baked_sample_spacing_meters_at_level(source_level: f64) -> f64 {
    2.0 * PLANET_RADIUS_METERS / (2.0_f64.powf(source_level) * f64::from(TILE_LOGICAL_SIZE - 1))
}

pub fn continuous_baked_sample_spacing_meters(
    face_uv: [f64; 2],
    source_level: u8,
    dense_level: u8,
) -> f64 {
    let dense_level = dense_level.min(source_level);
    let mut effective_level = f64::from(dense_level);
    for level in dense_level.saturating_add(1)..=source_level {
        let side = f64::from(1_u32 << level);
        let tile_x = ((face_uv[0] + 1.0) * 0.5 * side).rem_euclid(1.0);
        let tile_y = ((face_uv[1] + 1.0) * 0.5 * side).rem_euclid(1.0);
        let edge_distance = tile_x.min(1.0 - tile_x).min(tile_y.min(1.0 - tile_y));
        effective_level += smoothstep(
            0.0,
            TERRAIN_DETAIL_SOURCE_EDGE_FADE_TEXELS / f64::from(TILE_LOGICAL_SIZE - 1),
            edge_distance,
        );
    }
    baked_sample_spacing_meters_at_level(effective_level)
}

#[cfg(test)]
pub fn terrain_detail_meters(
    direction: DVec3,
    baked_spacing_meters: f64,
    scaled_macro_height_meters: f64,
) -> f64 {
    terrain_detail_meters_with_filter(
        direction,
        baked_spacing_meters,
        scaled_macro_height_meters,
        TERRAIN_DETAIL_MIN_FILTER_METERS,
    )
}

pub fn terrain_detail_meters_with_filter(
    direction: DVec3,
    baked_spacing_meters: f64,
    scaled_macro_height_meters: f64,
    filter_meters: f64,
) -> f64 {
    assert!(filter_meters.is_finite() && filter_meters >= TERRAIN_DETAIL_MIN_FILTER_METERS);
    let domain = terrain_detail_domain(direction.normalize());
    let mut total = 0.0;
    let mut gradient = DVec3::ZERO;
    let mut wavelength = TERRAIN_DETAIL_START_WAVELENGTH_METERS;
    for _ in 0..TERRAIN_DETAIL_OCTAVES {
        // Low cut as the shader's, and the same high cut: octaves the baked
        // data already carries must not be synthesised on top of it.
        let fade = smoothstep(filter_meters * 2.0, filter_meters * 4.0, wavelength)
            * (1.0
                - smoothstep(
                    baked_spacing_meters * 2.0,
                    baked_spacing_meters * 4.0,
                    wavelength,
                ));
        if fade > 0.0 {
            let inverse_wavelength = 1.0 / wavelength;
            let cells = domain * (PLANET_RADIUS_METERS * inverse_wavelength);
            let cell_floor = cells.floor();
            let cell_index = IVec3::new(
                cell_floor.x as i32,
                cell_floor.y as i32,
                cell_floor.z as i32,
            );
            let noise = terrain_detail_ridge(terrain_detail_value_noise_f64(
                cell_index,
                cells - cell_floor,
            ));
            // Mirrors the shader's multifractal attenuation. The gradient is
            // only accumulated because this needs it; nothing on the CPU side
            // consumes a slope directly.
            let attenuation = 1.0 / (1.0 + gradient.length() / TERRAIN_DETAIL_ATTENUATION_SLOPE);
            let octave_amplitude =
                wavelength * TERRAIN_DETAIL_ROUGHNESS * terrain_detail_octave_tilt(wavelength);
            let amplitude = octave_amplitude
                * fade
                * attenuation
                * terrain_detail_octave_headroom(scaled_macro_height_meters, octave_amplitude);
            total += noise.value * amplitude;
            gradient += noise.gradient * (amplitude * inverse_wavelength);
        }
        wavelength *= 0.5;
    }
    total
}

/// Value and slope of one noise octave, in cell units. Mirror of `DetailNoise`
/// in shared_planet.wgsl.
#[derive(Clone, Copy)]
struct DetailNoise {
    value: f64,
    gradient: DVec3,
}

/// Mirror of `terrain_detail_ridge` in shared_planet.wgsl.
fn terrain_detail_ridge(noise: DetailNoise) -> DetailNoise {
    let softened = (noise.value * noise.value
        + TERRAIN_DETAIL_RIDGE_SOFTNESS * TERRAIN_DETAIL_RIDGE_SOFTNESS)
        .sqrt();
    let folded_value = (TERRAIN_DETAIL_RIDGE_CENTRE - softened) * TERRAIN_DETAIL_RIDGE_SCALE;
    // Softening also removes the `sign` discontinuity the hard fold had, so
    // there is no longer a case where WGSL's `sign(0.0) == 0.0` and Rust's
    // `signum` disagree.
    let folded_gradient = noise.gradient * (-TERRAIN_DETAIL_RIDGE_SCALE * noise.value / softened);
    DetailNoise {
        value: lerp(noise.value, folded_value, TERRAIN_DETAIL_RIDGE_STRENGTH)
            * TERRAIN_DETAIL_RIDGE_NORMALISATION,
        gradient: noise
            .gradient
            .lerp(folded_gradient, TERRAIN_DETAIL_RIDGE_STRENGTH)
            * TERRAIN_DETAIL_RIDGE_NORMALISATION,
    }
}

fn lerp(from: f64, to: f64, amount: f64) -> f64 {
    from + (to - from) * amount
}

/// The most the unboosted ladder can reach, summed over the finite octave set.
/// Mirrors the shader constant of the same name and is rounded upward from
/// 475.078m.
#[cfg_attr(not(test), allow(dead_code))]
pub const TERRAIN_DETAIL_TOTAL_AMPLITUDE_METERS: f64 = 475.1;
/// How much elevation an octave needs before it appears at full amplitude,
/// as a multiple of its own amplitude. Asked per octave rather than per ladder;
/// see `terrain_detail_octave_headroom` in shared_planet.wgsl for why, and for
/// where the factor of eight comes from.
pub const TERRAIN_DETAIL_HEADROOM_FACTOR: f64 = 5.5;

/// Mirror of `terrain_detail_octave_tilt` in shared_planet.wgsl.
pub fn terrain_detail_octave_tilt(wavelength_meters: f64) -> f64 {
    1.0 + (TERRAIN_DETAIL_LONG_GAIN - 1.0)
        * smoothstep(
            TERRAIN_DETAIL_TILT_TAPER_METERS,
            TERRAIN_DETAIL_START_WAVELENGTH_METERS,
            wavelength_meters,
        )
}

pub fn terrain_detail_octave_headroom(
    scaled_macro_height_meters: f64,
    octave_amplitude_meters: f64,
) -> f64 {
    smoothstep(
        0.0,
        octave_amplitude_meters * TERRAIN_DETAIL_HEADROOM_FACTOR,
        scaled_macro_height_meters,
    )
}

fn terrain_detail_domain(direction: DVec3) -> DVec3 {
    DVec3::new(
        direction.dot(DVec3::new(0.80, 0.48, -0.36)),
        direction.dot(DVec3::new(-0.30, 0.85, 0.43)),
        direction.dot(DVec3::new(0.52, -0.21, 0.82)),
    )
}

/// Bit-for-bit mirror of `detail_mix` in shared_planet.wgsl.
///
/// The previous hash was `fract(sin(dot(cell, k)) * 43758)`, computed here in
/// f64 and in the shader in f32. At the finest octave the sin argument reaches
/// 1e9, where neighbouring f32 values are 64 radians apart, so the two sides
/// were evaluating unrelated numbers -- and because `fract` folds any
/// difference to a full-scale one, there was no "close enough" to fall back on.
/// The surface probe measured the correlation between the CPU's relief and the
/// rendered relief at 0.02. Both looked like plausible terrain; they were not
/// the same terrain, and the camera collided with the one it could not see.
///
/// Integer arithmetic is the only thing specified identically on both sides.
///
/// A multiply-free chain of shifts and adds was tried first, because Maxwell
/// runs 32-bit integer multiply at quarter rate. It needed so many full-rate
/// operations to diffuse that it cost 2ms in the raster path and up to 13ms in
/// the raymarch path, taking the ground-level scenarios over the 33ms budget.
/// One wide multiply diffuses further than a dozen shifts.
fn detail_mix(value: u32) -> u32 {
    let h = value.wrapping_mul(0x9e37_79b1);
    h ^ (h >> 15)
}

/// Mirror of `detail_avalanche` in shared_planet.wgsl.
fn detail_avalanche(value: u32) -> u32 {
    let h = value.wrapping_mul(0x85eb_ca6b);
    h ^ (h >> 16)
}

/// Mirror of `detail_axis_hashes`: one cell coordinate and its successor.
fn detail_axis_hashes(coordinate: i32, salt: u32) -> [u32; 2] {
    [
        detail_mix(coordinate as u32 ^ salt),
        detail_mix(coordinate.wrapping_add(1) as u32 ^ salt),
    ]
}

/// Mirror of `detail_corner`. The rotations break the symmetry of `x ^ y ^ z`,
/// which would otherwise put a diagonal lattice through the whole planet.
fn detail_corner(x: u32, y: u32, z: u32) -> f64 {
    let combined = detail_avalanche(x ^ y.rotate_left(11) ^ z.rotate_left(22));
    f64::from(combined >> 8) * (2.0 / 16_777_216.0) - 1.0
}

/// Mirror of `terrain_detail_value_noise`. Takes the integer cell and the
/// in-cell fraction separately for the same reason the shader does, and so the
/// two agree about which cell a point belongs to.
fn terrain_detail_value_noise_f64(cell_index: IVec3, cell_fraction: DVec3) -> DetailNoise {
    let carry = cell_fraction.floor();
    let cell = cell_index + IVec3::new(carry.x as i32, carry.y as i32, carry.z as i32);
    let amount = cell_fraction - carry;
    let fade = amount * amount * (DVec3::splat(3.0) - amount * 2.0);
    let fade_slope = 6.0 * amount * (DVec3::ONE - amount);
    let hx = detail_axis_hashes(cell.x, 0x27d4_eb2f);
    let hy = detail_axis_hashes(cell.y, 0x9e37_79b9);
    let hz = detail_axis_hashes(cell.z, 0x85eb_ca6b);
    let a = detail_corner(hx[0], hy[0], hz[0]);
    let b = detail_corner(hx[1], hy[0], hz[0]);
    let c = detail_corner(hx[0], hy[1], hz[0]);
    let d = detail_corner(hx[1], hy[1], hz[0]);
    let e = detail_corner(hx[0], hy[0], hz[1]);
    let f = detail_corner(hx[1], hy[0], hz[1]);
    let g = detail_corner(hx[0], hy[1], hz[1]);
    let h = detail_corner(hx[1], hy[1], hz[1]);
    let k1 = b - a;
    let k2 = c - a;
    let k3 = e - a;
    let k4 = a - b - c + d;
    let k5 = a - c - e + g;
    let k6 = a - b - e + f;
    let k7 = -a + b + c - d + e - f - g + h;
    let value = a
        + k1 * fade.x
        + k2 * fade.y
        + k3 * fade.z
        + k4 * fade.x * fade.y
        + k5 * fade.y * fade.z
        + k6 * fade.z * fade.x
        + k7 * fade.x * fade.y * fade.z;
    let gradient = fade_slope
        * DVec3::new(
            k1 + k4 * fade.y + k6 * fade.z + k7 * fade.y * fade.z,
            k2 + k5 * fade.z + k4 * fade.x + k7 * fade.z * fade.x,
            k3 + k6 * fade.x + k5 * fade.y + k7 * fade.x * fade.y,
        );
    DetailNoise { value, gradient }
}

pub fn global_terrain_detail_meters(direction: DVec3) -> f64 {
    // Evaluate this deliberately in f32, matching the camera-relative GPU
    // path closely enough for flight clearance. It remains direction-based,
    // so it is continuous across cube faces and outmap tiles.
    let direction = direction.normalize().as_vec3();
    GLOBAL_TERRAIN_DETAIL_OCTAVES
        .iter()
        .map(|(frequency, amplitude_meters, axis, phase)| {
            let offset = Vec3::new(axis[0] as f32, axis[1] as f32, axis[2] as f32) * *phase as f32;
            f64::from(*amplitude_meters as f32)
                * f64::from(terrain_detail_value_noise(
                    terrain_detail_noise_domain(direction) * *frequency as f32 + offset,
                ))
        })
        .sum()
}

fn terrain_detail_noise_domain(direction: Vec3) -> Vec3 {
    Vec3::new(
        direction.dot(Vec3::new(0.80, 0.48, -0.36)),
        direction.dot(Vec3::new(-0.30, 0.85, 0.43)),
        direction.dot(Vec3::new(0.52, -0.21, 0.82)),
    )
}

fn terrain_detail_hash(cell: Vec3) -> f32 {
    let value = (cell.dot(Vec3::new(127.1, 311.7, 74.7))).sin() * 43_758.547;
    (value - value.floor()) * 2.0 - 1.0
}

fn terrain_detail_value_noise(position: Vec3) -> f32 {
    let cell = position.floor();
    let amount = position - cell;
    let fade = amount * amount * (Vec3::splat(3.0) - amount * 2.0);
    let lower_lower = terrain_detail_hash(cell);
    let lower_right = terrain_detail_hash(cell + Vec3::X);
    let upper_lower = terrain_detail_hash(cell + Vec3::Y);
    let upper_right = terrain_detail_hash(cell + Vec3::X + Vec3::Y);
    let lower_plane = lower_lower + (lower_right - lower_lower) * fade.x;
    let upper_plane = upper_lower + (upper_right - upper_lower) * fade.x;
    let lower = lower_plane + (upper_plane - lower_plane) * fade.y;

    let lower_lower = terrain_detail_hash(cell + Vec3::Z);
    let lower_right = terrain_detail_hash(cell + Vec3::X + Vec3::Z);
    let upper_lower = terrain_detail_hash(cell + Vec3::Y + Vec3::Z);
    let upper_right = terrain_detail_hash(cell + Vec3::ONE);
    let lower_plane = lower_lower + (lower_right - lower_lower) * fade.x;
    let upper_plane = upper_lower + (upper_right - upper_lower) * fade.x;
    let upper = lower_plane + (upper_plane - lower_plane) * fade.y;
    lower + (upper - lower) * fade.z
}

pub fn outmap_terrain_height_scale(camera_altitude_meters: f64) -> f64 {
    let blend = smoothstep(
        OUTMAP_TERRAIN_HEIGHT_BLEND_START_METERS,
        OUTMAP_TERRAIN_HEIGHT_BLEND_END_METERS,
        camera_altitude_meters,
    );
    OUTMAP_TERRAIN_NEAR_HEIGHT_SCALE
        + (OUTMAP_TERRAIN_FAR_HEIGHT_SCALE - OUTMAP_TERRAIN_NEAR_HEIGHT_SCALE) * blend
}

pub fn scaled_outmap_macro_height_meters(
    macro_height_meters: f64,
    camera_altitude_meters: f64,
) -> f64 {
    if macro_height_meters > 0.0 {
        macro_height_meters * outmap_terrain_height_scale(camera_altitude_meters)
    } else {
        macro_height_meters
    }
}

/// Adds global microrelief without moving the coastline. The transition is
/// deliberately complete well above the 200m beach blend used by the shader.
#[cfg(test)]
pub fn detailed_outmap_land_height_meters(
    macro_height_meters: f64,
    direction: DVec3,
    camera_altitude_meters: f64,
    baked_spacing_meters: f64,
) -> f64 {
    detailed_outmap_land_height_meters_with_filter(
        macro_height_meters,
        direction,
        camera_altitude_meters,
        baked_spacing_meters,
        TERRAIN_DETAIL_MIN_FILTER_METERS,
    )
}

pub fn detailed_outmap_land_height_meters_with_filter(
    macro_height_meters: f64,
    direction: DVec3,
    camera_altitude_meters: f64,
    baked_spacing_meters: f64,
    filter_meters: f64,
) -> f64 {
    let weight = smoothstep(100.0, 400.0, macro_height_meters);
    let scaled_macro_height =
        scaled_outmap_macro_height_meters(macro_height_meters, camera_altitude_meters);
    // Two separate fields. The first is the retired direction-noise, kept gated
    // at zero. The second is the ladder the shader actually displaces with, and
    // without it the CPU believes in a surface up to 17m below the rendered one
    // -- which is what put ground-level cameras inside the terrain.
    scaled_macro_height
        + global_terrain_detail_meters(direction) * weight * GLOBAL_TERRAIN_DETAIL_HEIGHT_SCALE
        + terrain_detail_meters_with_filter(
            direction,
            baked_spacing_meters,
            scaled_macro_height,
            filter_meters,
        )
}

/// Height followed by the low-flight camera. Ocean floor is not the visible
/// surface, so below-sea baked samples resolve to sea level.
pub fn outmap_surface_height_meters(
    macro_height_meters: f64,
    direction: DVec3,
    camera_altitude_meters: f64,
    baked_spacing_meters: f64,
) -> f64 {
    outmap_surface_height_meters_with_filter(
        macro_height_meters,
        direction,
        camera_altitude_meters,
        baked_spacing_meters,
        TERRAIN_DETAIL_MIN_FILTER_METERS,
    )
}

pub fn outmap_surface_height_meters_with_filter(
    macro_height_meters: f64,
    direction: DVec3,
    camera_altitude_meters: f64,
    baked_spacing_meters: f64,
    filter_meters: f64,
) -> f64 {
    if macro_height_meters <= 0.0 {
        0.0
    } else {
        detailed_outmap_land_height_meters_with_filter(
            macro_height_meters,
            direction,
            camera_altitude_meters,
            baked_spacing_meters,
            filter_meters,
        )
    }
}

fn smoothstep(edge0: f64, edge1: f64, value: f64) -> f64 {
    let amount = ((value - edge0) / (edge1 - edge0)).clamp(0.0, 1.0);
    amount * amount * (3.0 - 2.0 * amount)
}

/// Screen-space LOD policy shared by all face trees. The hysteresis band
/// prevents a node from split/merge thrashing at the split boundary.
pub struct LodPolicy {
    pub split_pixels: f64,
    pub merge_pixels: f64,
    pub max_level: u8,
}

impl Default for LodPolicy {
    fn default() -> Self {
        Self {
            // Lowering both pixel thresholds by the same factor moves every
            // split/merge boundary 20% farther from the camera while retaining
            // the established 2:1 hysteresis band. This brings the finest
            // terrain in before the player is almost on top of it.
            split_pixels: 1.25,
            merge_pixels: 0.625,
            max_level: MAX_LOD_LEVEL,
        }
    }
}

impl LodPolicy {
    /// A deliberately fixed level for visual experiments that need every
    /// primitive to remain stable while its shading is inspected.
    #[cfg(test)]
    pub const fn fixed(level: u8) -> Self {
        Self {
            split_pixels: -1.0,
            merge_pixels: -2.0,
            max_level: level,
        }
    }
}

impl LodPolicy {
    fn minimum_level(&self) -> u8 {
        MINIMUM_LOD_LEVEL.min(self.max_level)
    }

    pub fn should_split(&self, projected_error_pixels: f64, level: u8) -> bool {
        level < self.max_level && projected_error_pixels > self.split_pixels
    }

    pub fn should_merge(&self, projected_error_pixels: f64, level: u8) -> bool {
        level >= self.minimum_level() && projected_error_pixels < self.merge_pixels
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TerrainHeightRange {
    minimum_meters: f64,
    maximum_meters: f64,
}

impl TerrainHeightRange {
    pub fn new(minimum_meters: f64, maximum_meters: f64) -> Self {
        assert!(minimum_meters.is_finite());
        assert!(maximum_meters.is_finite());
        assert!(minimum_meters <= maximum_meters);
        Self {
            minimum_meters,
            maximum_meters,
        }
    }

    fn minimum_radius(self) -> f64 {
        PLANET_RADIUS_METERS + self.minimum_meters
    }

    fn maximum_radius(self) -> f64 {
        PLANET_RADIUS_METERS + self.maximum_meters
    }
}

impl Default for TerrainHeightRange {
    fn default() -> Self {
        Self::new(
            -PLACEHOLDER_HEIGHT_AMPLITUDE_METERS,
            PLACEHOLDER_HEIGHT_AMPLITUDE_METERS,
        )
    }
}

#[derive(Clone, Copy)]
struct NodeDirectionalBounds {
    center_direction: DVec3,
    cosine_radius: f64,
    sine_radius: f64,
}

fn node_directional_bounds(node: QuadtreeNode) -> NodeDirectionalBounds {
    let [u_min, v_min, u_max, v_max] = node.uv_bounds();
    let center_direction = node.center_direction();
    let minimum_cosine = [
        cube_face_direction(node.face, u_min, v_min),
        cube_face_direction(node.face, u_max, v_min),
        cube_face_direction(node.face, u_min, v_max),
        cube_face_direction(node.face, u_max, v_max),
    ]
    .into_iter()
    .map(|direction| center_direction.dot(direction))
    .fold(1.0_f64, f64::min)
    .clamp(-1.0, 1.0);
    NodeDirectionalBounds {
        center_direction,
        cosine_radius: minimum_cosine,
        sine_radius: (1.0 - minimum_cosine * minimum_cosine).max(0.0).sqrt(),
    }
}

fn maximum_node_plane_value(
    bounds: NodeDirectionalBounds,
    camera_world: DVec3,
    plane_normal: DVec3,
    height_range: TerrainHeightRange,
) -> f64 {
    let plane_length = plane_normal.length();
    let plane_direction = plane_normal / plane_length;
    let maximum_direction_dot = maximum_direction_dot_in_cone(bounds, plane_direction);
    let radius = if maximum_direction_dot >= 0.0 {
        height_range.maximum_radius()
    } else {
        height_range.minimum_radius()
    };
    plane_length * (radius * maximum_direction_dot - camera_world.dot(plane_direction))
}

fn maximum_direction_dot_in_cone(bounds: NodeDirectionalBounds, direction: DVec3) -> f64 {
    let center_dot = bounds.center_direction.dot(direction).clamp(-1.0, 1.0);
    // Maximise over the node's angular cone. This expands only angularly;
    // unlike a height-inflated world-space sphere, a tall radial range cannot
    // make neighbouring fine nodes overlap the whole low-flight viewport.
    if center_dot >= bounds.cosine_radius {
        // The direction lies inside the node's angular cone.
        1.0
    } else {
        (center_dot * bounds.cosine_radius
            + (1.0 - center_dot * center_dot).max(0.0).sqrt() * bounds.sine_radius)
            .min(1.0)
    }
}

pub(crate) fn minimum_node_distance_with_height_range(
    node: QuadtreeNode,
    camera_world: DVec3,
    height_range: TerrainHeightRange,
) -> f64 {
    let camera_radius = camera_world.length();
    if camera_radius <= f64::EPSILON {
        return height_range.minimum_radius();
    }
    let maximum_direction_dot =
        maximum_direction_dot_in_cone(node_directional_bounds(node), camera_world / camera_radius);
    let closest_radius = (camera_radius * maximum_direction_dot)
        .clamp(height_range.minimum_radius(), height_range.maximum_radius());
    (camera_radius * camera_radius + closest_radius * closest_radius
        - 2.0 * camera_radius * closest_radius * maximum_direction_dot)
        .max(0.0)
        .sqrt()
}

fn node_is_above_horizon_with_height_range(
    node: QuadtreeNode,
    camera_world: DVec3,
    height_range: TerrainHeightRange,
) -> bool {
    maximum_node_plane_value(
        node_directional_bounds(node),
        DVec3::ZERO,
        camera_world,
        height_range,
    ) >= PLANET_RADIUS_METERS * PLANET_RADIUS_METERS
}

fn node_is_in_view_frustum(
    node: QuadtreeNode,
    camera_world: DVec3,
    camera_basis: CameraViewBasis,
    aspect_ratio: f64,
    vertical_fov_radians: f64,
    height_range: TerrainHeightRange,
) -> bool {
    let bounds = node_directional_bounds(node);
    let forward = camera_basis.forward;
    if maximum_node_plane_value(bounds, camera_world, forward, height_range) < 0.0 {
        return false;
    }

    let vertical_tangent = (vertical_fov_radians * 0.5).tan();
    let horizontal_tangent = vertical_tangent * aspect_ratio;

    // Test the node's angular/radial volume against all four side planes.
    for (axis, tangent) in [
        (camera_basis.right, horizontal_tangent),
        (camera_basis.up, vertical_tangent),
    ] {
        if maximum_node_plane_value(bounds, camera_world, forward * tangent + axis, height_range)
            < 0.0
            || maximum_node_plane_value(
                bounds,
                camera_world,
                forward * tangent - axis,
                height_range,
            ) < 0.0
        {
            return false;
        }
    }
    true
}

fn node_contains_direction(node: QuadtreeNode, direction: DVec3) -> bool {
    let (normal, tangent_u, tangent_v) = cube_face_basis(node.face);
    let normal_dot = direction.dot(normal);
    if normal_dot <= 0.0 {
        return false;
    }
    let u = direction.dot(tangent_u) / normal_dot;
    let v = direction.dot(tangent_v) / normal_dot;
    let [u_min, v_min, u_max, v_max] = node.uv_bounds();
    u >= u_min && u <= u_max && v >= v_min && v <= v_max
}

fn direction_across_node_edge(node: QuadtreeNode, edge: usize) -> DVec3 {
    let [u_min, v_min, u_max, v_max] = node.uv_bounds();
    let u_mid = (u_min + u_max) * 0.5;
    let v_mid = (v_min + v_max) * 0.5;
    let outside = (u_max - u_min) * 1.0e-4 + f64::EPSILON;
    let (u, v) = match edge {
        0 => (u_mid, v_min - outside),
        1 => (u_max + outside, v_mid),
        2 => (u_mid, v_max + outside),
        3 => (u_min - outside, v_mid),
        _ => unreachable!("a quadtree node has four edges"),
    };
    cube_face_direction(node.face, u, v)
}

/// Returns coarse visible leaves that must split to keep every shared edge
/// within the mesh stitcher's supported level delta.
fn unbalanced_coarse_neighbors(leaves: &HashSet<QuadtreeNode>) -> Vec<QuadtreeNode> {
    let all_nodes: Vec<_> = leaves.iter().copied().collect();
    unbalanced_coarse_neighbors_touching(&all_nodes, leaves)
}

/// Returns coarse leaves made unbalanced by the nodes most recently added to
/// an otherwise balanced frontier. Checking only that boundary avoids an
/// all-pairs scan for every candidate split.
fn unbalanced_coarse_neighbors_touching(
    added_nodes: &[QuadtreeNode],
    leaves: &HashSet<QuadtreeNode>,
) -> Vec<QuadtreeNode> {
    let mut coarse = HashSet::new();
    for node in added_nodes {
        for edge in 0..4 {
            let direction = direction_across_node_edge(*node, edge);
            let Some(neighbor) = leaves.iter().copied().find(|candidate| {
                *candidate != *node && node_contains_direction(*candidate, direction)
            }) else {
                continue;
            };
            if node.level > neighbor.level.saturating_add(MAX_ADJACENT_LOD_LEVEL_DELTA) {
                coarse.insert(neighbor);
            }
        }
    }
    let mut coarse: Vec<_> = coarse.into_iter().collect();
    coarse.sort_unstable();
    coarse
}

#[cfg(test)]
fn projected_error_pixels_with_height_range(
    node: QuadtreeNode,
    camera_world: DVec3,
    viewport_height: u32,
    vertical_fov_radians: f64,
    height_range: TerrainHeightRange,
) -> f64 {
    projected_error_pixels_with_height_range_and_ratio(
        node,
        camera_world,
        viewport_height,
        vertical_fov_radians,
        height_range,
        PLACEHOLDER_GEOMETRIC_ERROR_RATIO,
    )
}

fn projected_error_pixels_with_height_range_and_ratio(
    node: QuadtreeNode,
    camera_world: DVec3,
    viewport_height: u32,
    vertical_fov_radians: f64,
    height_range: TerrainHeightRange,
    geometric_error_ratio: f64,
) -> f64 {
    let distance =
        minimum_node_distance_with_height_range(node, camera_world, height_range).max(1.0);
    let projection_scale = f64::from(viewport_height.max(1))
        / (2.0
            * (vertical_fov_radians.clamp(
                minimum_vertical_fov_radians_for_viewport(1),
                std::f64::consts::PI - f64::EPSILON,
            ) * 0.5)
                .tan());
    node.geometric_error_meters_with_ratio(geometric_error_ratio) * projection_scale / distance
}

fn near_camera_lod_priority_weight(
    node: QuadtreeNode,
    camera_world: DVec3,
    terrain_height_range: TerrainHeightRange,
) -> f64 {
    let camera_altitude = (camera_world.length() - PLANET_RADIUS_METERS).max(1.0);
    let node_distance =
        minimum_node_distance_with_height_range(node, camera_world, terrain_height_range).max(1.0);
    ((camera_altitude + 1.0) / (camera_altitude + node_distance + 1.0))
        .sqrt()
        .clamp(LOD_NEAR_DETAIL_PRIORITY_FLOOR, 1.0)
}

fn camera_center_surface_direction(
    camera_world: DVec3,
    camera_forward: DVec3,
    terrain_height_range: TerrainHeightRange,
) -> Option<DVec3> {
    let direction = camera_forward.normalize_or_zero();
    if direction.length_squared() <= f64::EPSILON {
        return None;
    }
    let radius = terrain_height_range.maximum_radius();
    if camera_world.length() <= radius {
        return None;
    }
    let projection = camera_world.dot(direction);
    let discriminant = projection * projection - (camera_world.length_squared() - radius * radius);
    if discriminant <= 0.0 {
        return None;
    }
    let near_distance = -projection - discriminant.sqrt();
    let distance = if near_distance > 0.0 {
        near_distance
    } else {
        -projection + discriminant.sqrt()
    };
    (distance > 0.0).then(|| (camera_world + direction * distance).normalize())
}

fn node_intersects_view_focus_patch(
    node: QuadtreeNode,
    camera_world: DVec3,
    focus_direction: DVec3,
    distance_height_range: TerrainHeightRange,
) -> bool {
    let focus_radius = distance_height_range.maximum_radius();
    let focus_distance = camera_world.distance(focus_direction * focus_radius);
    let patch_radius_radians =
        (focus_distance * LOD_VIEW_FOCUS_HALF_ANGLE_RADIANS.tan()).atan2(focus_radius);
    maximum_direction_dot_in_cone(node_directional_bounds(node), focus_direction)
        >= patch_radius_radians.cos()
}

#[derive(Clone, Debug)]
pub struct LodMetrics {
    pub level_histogram: [u32; MAX_LOD_LEVEL as usize + 1],
    pub active_chunks: u32,
    pub chunks_loaded: u32,
    pub chunks_unloaded: u32,
    pub splits: u32,
    pub merges: u32,
    pub lod_thrash_events: u32,
    pub culled_nodes: u32,
    pub max_level: u8,
    pub max_seam_delta_meters: f64,
    pub budget_limited: bool,
}

impl Default for LodMetrics {
    fn default() -> Self {
        Self {
            level_histogram: [0; MAX_LOD_LEVEL as usize + 1],
            active_chunks: 0,
            chunks_loaded: 0,
            chunks_unloaded: 0,
            splits: 0,
            merges: 0,
            lod_thrash_events: 0,
            culled_nodes: 0,
            max_level: 0,
            max_seam_delta_meters: 0.0,
            budget_limited: false,
        }
    }
}

#[derive(Clone, Debug)]
pub struct LodUpdate {
    pub active_nodes: Vec<QuadtreeNode>,
    pub loaded_nodes: Vec<QuadtreeNode>,
    pub unloaded_nodes: Vec<QuadtreeNode>,
    pub metrics: LodMetrics,
}

#[derive(Clone, Copy)]
struct NodeEvaluation {
    visible: bool,
    projected_error_pixels: f64,
}

struct SplitCandidate {
    node: QuadtreeNode,
    priority: f64,
    visible_children: Vec<QuadtreeNode>,
}

struct SeamSample {
    position: DVec3,
    references: u32,
}

#[derive(Clone, Copy, Eq, PartialEq)]
enum LodTransitionKind {
    Split,
    Merge,
}

struct RecentLodTransition {
    kind: LodTransitionKind,
    update_index: u64,
}

#[derive(Clone, Copy, PartialEq)]
struct SelectionInput {
    camera_world: DVec3,
    camera_basis: Option<CameraViewBasis>,
    aspect_ratio: f64,
    viewport_height: u32,
    vertical_fov_radians: f64,
    geometric_error_ratio: GeometricErrorRatio,
    distance_reference_height_meters: f64,
    view_focus_direction: Option<DVec3>,
    source_level_limited: bool,
    baked_error_limited: bool,
}

impl PartialEq for SplitCandidate {
    fn eq(&self, other: &Self) -> bool {
        self.node == other.node && self.priority.total_cmp(&other.priority) == Ordering::Equal
    }
}

impl Eq for SplitCandidate {}

impl PartialOrd for SplitCandidate {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl Ord for SplitCandidate {
    fn cmp(&self, other: &Self) -> Ordering {
        self.priority
            .total_cmp(&other.priority)
            .then_with(|| self.node.cmp(&other.node))
    }
}

pub struct PlanetLod {
    policy: LodPolicy,
    max_active_chunks: usize,
    split_nodes: HashSet<QuadtreeNode>,
    active_nodes: Vec<QuadtreeNode>,
    seam_samples: HashMap<[i64; 3], SeamSample>,
    max_seam_delta_meters: f64,
    last_selection_input: Option<SelectionInput>,
    last_metrics: LodMetrics,
    update_index: u64,
    recent_lod_transitions: HashMap<QuadtreeNode, RecentLodTransition>,
    terrain_height_range: TerrainHeightRange,
    distance_reference_height_meters: f64,
    view_focus_direction: Option<DVec3>,
}

impl Default for PlanetLod {
    fn default() -> Self {
        Self::new(LodPolicy::default(), max_active_chunks_from_env())
    }
}

#[allow(dead_code)]
impl PlanetLod {
    pub fn new(mut policy: LodPolicy, max_active_chunks: usize) -> Self {
        policy.max_level = policy.max_level.min(MAX_LOD_LEVEL);
        assert!(policy.merge_pixels < policy.split_pixels);
        assert!(max_active_chunks >= FACE_COUNT as usize);
        Self {
            policy,
            max_active_chunks,
            split_nodes: HashSet::new(),
            active_nodes: Vec::new(),
            seam_samples: HashMap::new(),
            max_seam_delta_meters: 0.0,
            last_selection_input: None,
            last_metrics: LodMetrics::default(),
            update_index: 0,
            recent_lod_transitions: HashMap::new(),
            terrain_height_range: TerrainHeightRange::default(),
            distance_reference_height_meters: 0.0,
            view_focus_direction: None,
        }
    }

    pub fn set_terrain_height_range(&mut self, terrain_height_range: TerrainHeightRange) {
        if self.terrain_height_range != terrain_height_range {
            self.terrain_height_range = terrain_height_range;
            self.last_selection_input = None;
        }
    }

    /// Sets the local terrain height used solely for screen-error distance.
    /// Culling still uses the full conservative terrain shell. Separating the
    /// two prevents a low camera inside that global shell from measuring every
    /// node at zero metres and requesting L18 regardless of screen distance.
    pub fn set_distance_reference_height(&mut self, height_meters: f64) {
        assert!(height_meters.is_finite());
        if self.distance_reference_height_meters != height_meters {
            self.distance_reference_height_meters = height_meters;
            self.last_selection_input = None;
        }
    }

    /// Pins the leaf-budget priority to terrain actually reached by the
    /// centre view ray. This is supplied by the terrain source because a
    /// conservative global height shell cannot identify the first surface hit
    /// when a low camera is inside that shell.
    pub fn set_view_focus_direction(&mut self, direction: Option<DVec3>) {
        let direction = direction.map(DVec3::normalize);
        if self.view_focus_direction != direction {
            self.view_focus_direction = direction;
            self.last_selection_input = None;
        }
    }

    pub fn active_nodes(&self) -> &[QuadtreeNode] {
        &self.active_nodes
    }

    pub fn is_split(&self, node: QuadtreeNode) -> bool {
        self.split_nodes.contains(&node)
    }

    pub fn update(
        &mut self,
        camera_world: DVec3,
        viewport_height: u32,
        vertical_fov_radians: f64,
    ) -> LodUpdate {
        self.update_internal(
            camera_world,
            None,
            1.0,
            viewport_height,
            vertical_fov_radians,
            GeometricErrorRatio::uniform(PLACEHOLDER_GEOMETRIC_ERROR_RATIO),
            None,
            None,
        )
    }

    pub fn update_for_view(
        &mut self,
        camera_world: DVec3,
        camera_forward: DVec3,
        aspect_ratio: f64,
        viewport_height: u32,
        vertical_fov_radians: f64,
    ) -> LodUpdate {
        self.update_for_view_with_up(
            camera_world,
            camera_forward,
            DVec3::Y,
            aspect_ratio,
            viewport_height,
            vertical_fov_radians,
        )
    }

    pub fn update_for_view_with_up(
        &mut self,
        camera_world: DVec3,
        camera_forward: DVec3,
        camera_up: DVec3,
        aspect_ratio: f64,
        viewport_height: u32,
        vertical_fov_radians: f64,
    ) -> LodUpdate {
        assert!(camera_world.is_finite());
        assert!(camera_world.length() > MINIMUM_CAMERA_RADIUS_METERS);
        assert!(camera_forward.is_finite() && camera_forward.length_squared() > 0.0);
        assert!(camera_up.is_finite() && camera_up.length_squared() > 0.0);
        assert!(aspect_ratio.is_finite() && aspect_ratio > 0.0);
        self.update_internal(
            camera_world,
            Some(CameraViewBasis::from_forward_and_up(
                camera_forward,
                camera_up,
            )),
            aspect_ratio,
            viewport_height,
            vertical_fov_radians,
            GeometricErrorRatio::uniform(PLACEHOLDER_GEOMETRIC_ERROR_RATIO),
            None,
            None,
        )
    }

    /// Selects visible leaves while allowing the terrain source to stop
    /// refinement once a node has enough mesh cells to represent its texels.
    /// This prevents a coarse ancestor tile from being repeated across many
    /// progressively finer chunks which contain no additional height data.
    pub fn update_for_view_with_up_and_level_limit(
        &mut self,
        camera_world: DVec3,
        camera_forward: DVec3,
        camera_up: DVec3,
        aspect_ratio: f64,
        viewport_height: u32,
        vertical_fov_radians: f64,
        node_level_limit: &dyn Fn(QuadtreeNode) -> u8,
    ) -> LodUpdate {
        self.update_for_view_with_constraints(
            camera_world,
            camera_forward,
            camera_up,
            aspect_ratio,
            viewport_height,
            vertical_fov_radians,
            GeometricErrorRatio::uniform(PLACEHOLDER_GEOMETRIC_ERROR_RATIO),
            node_level_limit,
            None,
        )
    }

    /// Applies screen-space LOD inside the view frustum while constraining
    /// refinement to useful source resolution. A balancing pass may add the
    /// small number of intermediate nodes needed to keep topology graded.
    #[allow(clippy::too_many_arguments)]
    pub fn update_for_view_with_constraints(
        &mut self,
        camera_world: DVec3,
        camera_forward: DVec3,
        camera_up: DVec3,
        aspect_ratio: f64,
        viewport_height: u32,
        vertical_fov_radians: f64,
        geometric_error_ratio: GeometricErrorRatio,
        node_level_limit: &dyn Fn(QuadtreeNode) -> u8,
        baked_error_limit: Option<&dyn Fn(QuadtreeNode) -> u8>,
    ) -> LodUpdate {
        assert!(camera_world.is_finite());
        assert!(camera_world.length() > MINIMUM_CAMERA_RADIUS_METERS);
        assert!(camera_forward.is_finite() && camera_forward.length_squared() > 0.0);
        assert!(camera_up.is_finite() && camera_up.length_squared() > 0.0);
        assert!(aspect_ratio.is_finite() && aspect_ratio > 0.0);
        self.update_internal(
            camera_world,
            Some(CameraViewBasis::from_forward_and_up(
                camera_forward,
                camera_up,
            )),
            aspect_ratio,
            viewport_height,
            vertical_fov_radians,
            geometric_error_ratio,
            Some(node_level_limit),
            baked_error_limit,
        )
    }

    fn update_internal(
        &mut self,
        camera_world: DVec3,
        camera_basis: Option<CameraViewBasis>,
        aspect_ratio: f64,
        viewport_height: u32,
        vertical_fov_radians: f64,
        geometric_error_ratio: GeometricErrorRatio,
        node_level_limit: Option<&dyn Fn(QuadtreeNode) -> u8>,
        baked_error_limit: Option<&dyn Fn(QuadtreeNode) -> u8>,
    ) -> LodUpdate {
        assert!(camera_world.is_finite());
        assert!(camera_world.length() > MINIMUM_CAMERA_RADIUS_METERS);
        assert!(aspect_ratio.is_finite() && aspect_ratio > 0.0);
        assert!(vertical_fov_radians.is_finite() && vertical_fov_radians > 0.0);
        assert!(geometric_error_ratio.total().is_finite() && geometric_error_ratio.total() > 0.0);
        // Past the baked limit the ladder term is the whole error budget, so a
        // source that supplies a limit must also supply something for the mesh
        // to keep resolving -- otherwise refinement stops dead at that level.
        assert!(
            baked_error_limit.is_none()
                || (geometric_error_ratio.ladder.is_finite() && geometric_error_ratio.ladder > 0.0)
        );
        self.update_index += 1;
        self.recent_lod_transitions.retain(|_, transition| {
            self.update_index.saturating_sub(transition.update_index) <= LOD_THRASH_WINDOW_UPDATES
        });
        let selection_input = SelectionInput {
            camera_world,
            camera_basis,
            aspect_ratio,
            viewport_height,
            vertical_fov_radians,
            geometric_error_ratio,
            distance_reference_height_meters: self.distance_reference_height_meters,
            view_focus_direction: self.view_focus_direction,
            source_level_limited: node_level_limit.is_some(),
            baked_error_limited: baked_error_limit.is_some(),
        };
        if self.last_selection_input == Some(selection_input) {
            let mut metrics = self.last_metrics.clone();
            metrics.chunks_loaded = 0;
            metrics.chunks_unloaded = 0;
            metrics.splits = 0;
            metrics.merges = 0;
            metrics.lod_thrash_events = 0;
            metrics.culled_nodes = 0;
            return LodUpdate {
                active_nodes: self.active_nodes.clone(),
                loaded_nodes: Vec::new(),
                unloaded_nodes: Vec::new(),
                metrics,
            };
        }

        let previous_active: HashSet<_> = self.active_nodes.iter().copied().collect();
        let previous_split = self.split_nodes.clone();
        let terrain_height_range = self.terrain_height_range;
        let distance_height_range = TerrainHeightRange::new(
            self.distance_reference_height_meters,
            self.distance_reference_height_meters,
        );
        let mut evaluations = HashMap::new();
        let mut culled_nodes = 0_u32;
        let mut leaves = HashSet::with_capacity(self.max_active_chunks);
        for face in 0..FACE_COUNT {
            let root = QuadtreeNode::root(face);
            if Self::evaluate(
                root,
                camera_world,
                camera_basis,
                aspect_ratio,
                viewport_height,
                vertical_fov_radians,
                terrain_height_range,
                distance_height_range,
                geometric_error_ratio,
                baked_error_limit,
                &mut evaluations,
                &mut culled_nodes,
            )
            .visible
            {
                leaves.insert(root);
            }
        }

        let mut next_split = HashSet::new();
        let mut budget_limited = false;
        let mut candidates = BinaryHeap::new();
        for root in leaves.iter().copied() {
            if let Some(candidate) = Self::split_candidate(
                &self.policy,
                root,
                &previous_split,
                node_level_limit,
                camera_world,
                camera_basis,
                aspect_ratio,
                viewport_height,
                vertical_fov_radians,
                terrain_height_range,
                distance_height_range,
                geometric_error_ratio,
                baked_error_limit,
                self.view_focus_direction,
                &mut evaluations,
                &mut culled_nodes,
            ) {
                candidates.push(candidate);
            }
        }
        while let Some(candidate) = candidates.pop() {
            if !leaves.contains(&candidate.node) {
                continue;
            }
            let mut trial_leaves = leaves.clone();
            trial_leaves.remove(&candidate.node);
            trial_leaves.extend(candidate.visible_children.iter().copied());
            if trial_leaves.len() > self.max_active_chunks {
                budget_limited = true;
                continue;
            }

            // Keep the frontier balanced as each requested split is admitted,
            // rather than filling the leaf budget first and discovering too
            // late that no room remains for its coarse neighbours. A rejected
            // trial leaves its parent in place, so coverage is preserved and
            // the 256-leaf limit cannot manufacture a topology cliff.
            let mut trial_splits = vec![candidate.node];
            let mut trial_fits_budget = true;
            let mut balance_frontier = candidate.visible_children;
            loop {
                let nodes_to_split =
                    unbalanced_coarse_neighbors_touching(&balance_frontier, &trial_leaves);
                if nodes_to_split.is_empty() {
                    break;
                }
                let mut changed = false;
                balance_frontier.clear();
                for node in nodes_to_split {
                    if !trial_leaves.contains(&node) || node.level >= self.policy.max_level {
                        continue;
                    }
                    let visible_children: Vec<_> = node
                        .children()
                        .into_iter()
                        .filter(|child| {
                            Self::evaluate(
                                *child,
                                camera_world,
                                camera_basis,
                                aspect_ratio,
                                viewport_height,
                                vertical_fov_radians,
                                terrain_height_range,
                                distance_height_range,
                                geometric_error_ratio,
                                baked_error_limit,
                                &mut evaluations,
                                &mut culled_nodes,
                            )
                            .visible
                        })
                        .collect();
                    if visible_children.is_empty() {
                        continue;
                    }
                    trial_leaves.remove(&node);
                    trial_leaves.extend(visible_children.iter().copied());
                    balance_frontier.extend(visible_children);
                    trial_splits.push(node);
                    changed = true;
                    if trial_leaves.len() > self.max_active_chunks {
                        trial_fits_budget = false;
                        break;
                    }
                }
                if !trial_fits_budget || !changed {
                    break;
                }
            }
            if !trial_fits_budget {
                budget_limited = true;
                continue;
            }

            let added_leaves: Vec<_> = trial_leaves.difference(&leaves).copied().collect();
            leaves = trial_leaves;
            next_split.extend(trial_splits);
            for child in added_leaves {
                if let Some(child_candidate) = Self::split_candidate(
                    &self.policy,
                    child,
                    &previous_split,
                    node_level_limit,
                    camera_world,
                    camera_basis,
                    aspect_ratio,
                    viewport_height,
                    vertical_fov_radians,
                    terrain_height_range,
                    distance_height_range,
                    geometric_error_ratio,
                    baked_error_limit,
                    self.view_focus_direction,
                    &mut evaluations,
                    &mut culled_nodes,
                ) {
                    candidates.push(child_candidate);
                }
            }
        }

        if camera_basis.is_some() {
            // A large parent sphere can graze the viewport even when every
            // tighter child bound is outside it. Such a parent must not remain
            // as a coarse rendered leaf: it contributes no pixels, defeats the
            // minimum LOD policy, and becomes especially expensive at a narrow
            // optical zoom.
            leaves.retain(|node| {
                node.level >= self.policy.minimum_level()
                    || node.children().into_iter().any(|child| {
                        Self::evaluate(
                            child,
                            camera_world,
                            camera_basis,
                            aspect_ratio,
                            viewport_height,
                            vertical_fov_radians,
                            terrain_height_range,
                            distance_height_range,
                            geometric_error_ratio,
                            baked_error_limit,
                            &mut evaluations,
                            &mut culled_nodes,
                        )
                        .visible
                    })
            });
        }

        // Sparse source coverage can stop a coarse neighbour several levels
        // before a detailed tile. Grade that boundary before rendering: the
        // shared mesh can stitch two levels, but a larger jump exposes giant
        // triangles and skirt walls. Balancing deliberately overrides the
        // source cap only for the narrow transition band; SSE still decides
        // which detailed nodes are wanted in the view frustum.
        loop {
            let nodes_to_split = unbalanced_coarse_neighbors(&leaves);
            if nodes_to_split.is_empty() {
                break;
            }
            let mut changed = false;
            for node in nodes_to_split {
                if !leaves.contains(&node) || node.level >= self.policy.max_level {
                    continue;
                }
                let visible_children: Vec<_> = node
                    .children()
                    .into_iter()
                    .filter(|child| {
                        Self::evaluate(
                            *child,
                            camera_world,
                            camera_basis,
                            aspect_ratio,
                            viewport_height,
                            vertical_fov_radians,
                            terrain_height_range,
                            distance_height_range,
                            geometric_error_ratio,
                            baked_error_limit,
                            &mut evaluations,
                            &mut culled_nodes,
                        )
                        .visible
                    })
                    .collect();
                if visible_children.is_empty() {
                    continue;
                }
                let next_len = leaves.len() - 1 + visible_children.len();
                if next_len > self.max_active_chunks {
                    budget_limited = true;
                    continue;
                }
                leaves.remove(&node);
                next_split.insert(node);
                leaves.extend(visible_children);
                changed = true;
            }
            if !changed {
                break;
            }
        }

        let mut leaves: Vec<_> = leaves.into_iter().collect();
        leaves.sort_unstable();
        let next_active: HashSet<_> = leaves.iter().copied().collect();
        let mut loaded_nodes: Vec<_> = next_active.difference(&previous_active).copied().collect();
        let mut unloaded_nodes: Vec<_> =
            previous_active.difference(&next_active).copied().collect();
        loaded_nodes.sort_unstable();
        unloaded_nodes.sort_unstable();
        self.update_seam_metrics(&loaded_nodes, &unloaded_nodes);

        let split_transitions: Vec<_> = next_split.difference(&previous_split).copied().collect();
        let merge_transitions: Vec<_> = previous_split
            .difference(&next_split)
            .copied()
            .filter(|node| {
                let evaluation = Self::evaluate(
                    *node,
                    camera_world,
                    camera_basis,
                    aspect_ratio,
                    viewport_height,
                    vertical_fov_radians,
                    terrain_height_range,
                    distance_height_range,
                    geometric_error_ratio,
                    baked_error_limit,
                    &mut evaluations,
                    &mut culled_nodes,
                );
                evaluation.visible
                    && node.level >= self.policy.minimum_level()
                    && self
                        .policy
                        .should_merge(evaluation.projected_error_pixels, node.level)
            })
            .collect();
        let lod_thrash_events = self.record_lod_transitions(&split_transitions, &merge_transitions);

        let mut metrics = LodMetrics {
            active_chunks: leaves.len() as u32,
            chunks_loaded: loaded_nodes.len() as u32,
            chunks_unloaded: unloaded_nodes.len() as u32,
            splits: split_transitions.len() as u32,
            merges: merge_transitions.len() as u32,
            lod_thrash_events,
            culled_nodes,
            max_seam_delta_meters: self.max_seam_delta_meters,
            budget_limited,
            ..LodMetrics::default()
        };
        for node in &leaves {
            metrics.level_histogram[node.level as usize] += 1;
            metrics.max_level = metrics.max_level.max(node.level);
        }

        self.split_nodes = next_split;
        self.active_nodes = leaves.clone();
        self.last_selection_input = Some(selection_input);
        self.last_metrics = metrics.clone();
        LodUpdate {
            active_nodes: leaves,
            loaded_nodes,
            unloaded_nodes,
            metrics,
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn split_candidate(
        policy: &LodPolicy,
        node: QuadtreeNode,
        previous_split: &HashSet<QuadtreeNode>,
        node_level_limit: Option<&dyn Fn(QuadtreeNode) -> u8>,
        camera_world: DVec3,
        camera_basis: Option<CameraViewBasis>,
        aspect_ratio: f64,
        viewport_height: u32,
        vertical_fov_radians: f64,
        terrain_height_range: TerrainHeightRange,
        distance_height_range: TerrainHeightRange,
        geometric_error_ratio: GeometricErrorRatio,
        baked_error_limit: Option<&dyn Fn(QuadtreeNode) -> u8>,
        view_focus_direction: Option<DVec3>,
        evaluations: &mut HashMap<QuadtreeNode, NodeEvaluation>,
        culled_nodes: &mut u32,
    ) -> Option<SplitCandidate> {
        let maximum_level = node_level_limit
            .map_or(policy.max_level, |limit| limit(node))
            .min(policy.max_level);
        if node.level >= maximum_level {
            return None;
        }
        let evaluation = Self::evaluate(
            node,
            camera_world,
            camera_basis,
            aspect_ratio,
            viewport_height,
            vertical_fov_radians,
            terrain_height_range,
            distance_height_range,
            geometric_error_ratio,
            baked_error_limit,
            evaluations,
            culled_nodes,
        );
        let was_split = previous_split.contains(&node);
        let refine = if node.level < policy.minimum_level() {
            true
        } else if was_split {
            !policy.should_merge(evaluation.projected_error_pixels, node.level)
        } else {
            policy.should_split(evaluation.projected_error_pixels, node.level)
        };
        if !refine {
            return None;
        }
        let visible_children: Vec<_> = node
            .children()
            .into_iter()
            .filter(|child| {
                Self::evaluate(
                    *child,
                    camera_world,
                    camera_basis,
                    aspect_ratio,
                    viewport_height,
                    vertical_fov_radians,
                    terrain_height_range,
                    distance_height_range,
                    geometric_error_ratio,
                    baked_error_limit,
                    evaluations,
                    culled_nodes,
                )
                .visible
            })
            .collect();
        if visible_children.is_empty() {
            return None;
        }
        // Once the global leaf budget is approached, favour the
        // nearest/deepest visible demand instead of breadth-refining the
        // horizon. Preserve a compact high-detail patch around the actual
        // screen-centre ray as well; otherwise the level multiplier can spend
        // the leaf budget on off-centre L7 leaves and leave a conspicuous
        // coarse square directly under the crosshair.
        let screen_centre_boost = if let Some(direction) = view_focus_direction {
            node_intersects_view_focus_patch(node, camera_world, direction, distance_height_range)
        } else {
            camera_basis
                .and_then(|basis| {
                    camera_center_surface_direction(
                        camera_world,
                        basis.forward,
                        terrain_height_range,
                    )
                })
                .is_some_and(|direction| node_contains_direction(node, direction))
        }
        .then_some(LOD_VIEW_FOCUS_PRIORITY_BOOST)
        .unwrap_or(1.0);
        let priority = evaluation.projected_error_pixels
            * f64::from(1_u32 << node.level)
            * near_camera_lod_priority_weight(node, camera_world, terrain_height_range)
            * screen_centre_boost;
        Some(SplitCandidate {
            node,
            priority,
            visible_children,
        })
    }

    fn evaluate(
        node: QuadtreeNode,
        camera_world: DVec3,
        camera_basis: Option<CameraViewBasis>,
        aspect_ratio: f64,
        viewport_height: u32,
        vertical_fov_radians: f64,
        terrain_height_range: TerrainHeightRange,
        distance_height_range: TerrainHeightRange,
        geometric_error_ratio: GeometricErrorRatio,
        baked_error_limit: Option<&dyn Fn(QuadtreeNode) -> u8>,
        evaluations: &mut HashMap<QuadtreeNode, NodeEvaluation>,
        culled_nodes: &mut u32,
    ) -> NodeEvaluation {
        if let Some(evaluation) = evaluations.get(&node) {
            return *evaluation;
        }
        let visible =
            node_is_above_horizon_with_height_range(node, camera_world, terrain_height_range)
                && camera_basis.map_or(true, |camera_basis| {
                    node_is_in_view_frustum(
                        node,
                        camera_world,
                        camera_basis,
                        aspect_ratio,
                        vertical_fov_radians,
                        terrain_height_range,
                    )
                });
        if !visible {
            *culled_nodes += 1;
        }
        // A split resolves more baked detail only while the child grid still
        // has unread source texels; past that limit the baked term is a debt
        // that refinement cannot pay off, so it must not drive refinement.
        let baked_is_resolvable =
            baked_error_limit.map_or(true, |limit| node.level < limit(node).min(MAX_LOD_LEVEL));
        let evaluation = NodeEvaluation {
            visible,
            projected_error_pixels: projected_error_pixels_with_height_range_and_ratio(
                node,
                camera_world,
                viewport_height,
                vertical_fov_radians,
                distance_height_range,
                geometric_error_ratio.for_node(baked_is_resolvable),
            ),
        };
        evaluations.insert(node, evaluation);
        evaluation
    }

    fn record_lod_transitions(
        &mut self,
        split_nodes: &[QuadtreeNode],
        merge_nodes: &[QuadtreeNode],
    ) -> u32 {
        let mut thrash_events = 0;
        for (nodes, kind) in [
            (split_nodes, LodTransitionKind::Split),
            (merge_nodes, LodTransitionKind::Merge),
        ] {
            for node in nodes {
                if self
                    .recent_lod_transitions
                    .get(node)
                    .is_some_and(|previous| {
                        previous.kind != kind
                            && self.update_index.saturating_sub(previous.update_index)
                                <= LOD_THRASH_WINDOW_UPDATES
                    })
                {
                    thrash_events += 1;
                }
                self.recent_lod_transitions.insert(
                    *node,
                    RecentLodTransition {
                        kind,
                        update_index: self.update_index,
                    },
                );
            }
        }
        thrash_events
    }

    fn update_seam_metrics(
        &mut self,
        loaded_nodes: &[QuadtreeNode],
        unloaded_nodes: &[QuadtreeNode],
    ) {
        for node in unloaded_nodes {
            for (key, _) in node_boundary_samples(*node) {
                if let std::collections::hash_map::Entry::Occupied(mut entry) =
                    self.seam_samples.entry(key)
                {
                    if entry.get().references > 1 {
                        entry.get_mut().references -= 1;
                    } else {
                        entry.remove();
                    }
                }
            }
        }
        for node in loaded_nodes {
            for (key, position) in node_boundary_samples(*node) {
                if let Some(existing) = self.seam_samples.get_mut(&key) {
                    self.max_seam_delta_meters = self
                        .max_seam_delta_meters
                        .max(existing.position.distance(position));
                    existing.references += 1;
                } else {
                    self.seam_samples.insert(
                        key,
                        SeamSample {
                            position,
                            references: 1,
                        },
                    );
                }
            }
        }
    }
}

fn node_boundary_samples(node: QuadtreeNode) -> Vec<([i64; 3], DVec3)> {
    let [u_min, v_min, u_max, v_max] = node.uv_bounds();
    let mut samples = Vec::with_capacity(4 * CHUNK_GRID_QUADS);
    let mut push_sample = |u: f64, v: f64| {
        let direction = cube_face_direction(node.face, u, v);
        let position = direction * (PLANET_RADIUS_METERS + placeholder_height_meters(direction));
        let key = [
            (direction.x * 1.0e10).round() as i64,
            (direction.y * 1.0e10).round() as i64,
            (direction.z * 1.0e10).round() as i64,
        ];
        samples.push((key, position));
    };
    for step in 0..=CHUNK_GRID_QUADS {
        let fraction = step as f64 / CHUNK_GRID_QUADS as f64;
        push_sample(u_min + (u_max - u_min) * fraction, v_min);
    }
    for step in 1..=CHUNK_GRID_QUADS {
        let fraction = step as f64 / CHUNK_GRID_QUADS as f64;
        push_sample(u_max, v_min + (v_max - v_min) * fraction);
    }
    for step in (0..CHUNK_GRID_QUADS).rev() {
        let fraction = step as f64 / CHUNK_GRID_QUADS as f64;
        push_sample(u_min + (u_max - u_min) * fraction, v_max);
    }
    for step in (1..CHUNK_GRID_QUADS).rev() {
        let fraction = step as f64 / CHUNK_GRID_QUADS as f64;
        push_sample(u_min, v_min + (v_max - v_min) * fraction);
    }
    samples
}

#[repr(C)]
#[derive(Clone, Copy, Debug, bytemuck::Pod, bytemuck::Zeroable)]
pub struct ChunkVertex {
    pub anchor_relative_position: [f32; 3],
    pub sphere_direction: [f32; 3],
    pub tile_uv: [f32; 2],
    pub skirt_depth_meters: f32,
}

impl ChunkVertex {
    pub const ATTRIBUTES: [wgpu::VertexAttribute; 4] = wgpu::vertex_attr_array![
        0 => Float32x3,
        1 => Float32x3,
        2 => Float32x2,
        3 => Float32
    ];

    pub fn layout() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout {
            array_stride: size_of::<Self>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &Self::ATTRIBUTES,
        }
    }
}

#[allow(dead_code)]
pub struct ChunkMesh {
    pub node: QuadtreeNode,
    pub anchor_world: DVec3,
    pub vertices: Vec<ChunkVertex>,
    pub indices: Vec<u32>,
    pub edge_length_meters: f64,
    pub skirt_depth_meters: f64,
}

#[allow(dead_code)]
impl ChunkMesh {
    pub fn anchor_relative_to_camera(&self, camera_world: DVec3) -> [f32; 3] {
        (self.anchor_world - camera_world).as_vec3().to_array()
    }

    pub fn vertex_world_position(&self, vertex_index: usize, displaced: bool) -> DVec3 {
        let vertex = self.vertices[vertex_index];
        let direction = DVec3::from_array(vertex.sphere_direction.map(f64::from));
        let base =
            self.anchor_world + DVec3::from_array(vertex.anchor_relative_position.map(f64::from));
        let height = if displaced {
            placeholder_height_meters(direction)
        } else {
            0.0
        };
        base + direction * (height - f64::from(vertex.skirt_depth_meters))
    }
}

pub fn build_chunk_mesh(node: QuadtreeNode) -> ChunkMesh {
    build_chunk_mesh_with_quads(node, CHUNK_GRID_QUADS)
}

pub fn build_chunk_mesh_with_quads(node: QuadtreeNode, grid_quads: usize) -> ChunkMesh {
    assert!(node.is_valid(), "invalid quadtree node {node:?}");
    assert!(grid_quads > 0, "chunk grid must contain at least one quad");
    let [u_min, v_min, u_max, v_max] = node.uv_bounds();
    let anchor_world = node.center_direction() * PLANET_RADIUS_METERS;
    let corners = [
        cube_face_direction(node.face, u_min, v_min) * PLANET_RADIUS_METERS,
        cube_face_direction(node.face, u_max, v_min) * PLANET_RADIUS_METERS,
        cube_face_direction(node.face, u_max, v_max) * PLANET_RADIUS_METERS,
        cube_face_direction(node.face, u_min, v_max) * PLANET_RADIUS_METERS,
    ];
    let edge_length_meters = corners[0]
        .distance(corners[1])
        .max(corners[1].distance(corners[2]))
        .max(corners[2].distance(corners[3]))
        .max(corners[3].distance(corners[0]));
    let skirt_depth_meters = (edge_length_meters * SKIRT_DEPTH_RATIO).min(MAX_SKIRT_DEPTH_METERS);
    let grid_vertices = grid_quads + 1;
    let top_vertex_count = grid_vertices * grid_vertices;
    let skirt_vertex_count = 4 * grid_vertices;
    let mut vertices = Vec::with_capacity(top_vertex_count + skirt_vertex_count);
    let mut indices = Vec::with_capacity(grid_quads * grid_quads * 6 + 4 * grid_quads * 6);

    for y in 0..grid_vertices {
        let v_fraction = y as f64 / grid_quads as f64;
        let v = v_min + (v_max - v_min) * v_fraction;
        for x in 0..grid_vertices {
            let u_fraction = x as f64 / grid_quads as f64;
            let u = u_min + (u_max - u_min) * u_fraction;
            let direction = cube_face_direction(node.face, u, v);
            let world = direction * PLANET_RADIUS_METERS;
            vertices.push(ChunkVertex {
                anchor_relative_position: (world - anchor_world).as_vec3().to_array(),
                sphere_direction: direction.as_vec3().to_array(),
                tile_uv: [u_fraction as f32, v_fraction as f32],
                skirt_depth_meters: 0.0,
            });
        }
    }
    for y in 0..grid_quads {
        for x in 0..grid_quads {
            let lower_left = (y * grid_vertices + x) as u32;
            let lower_right = lower_left + 1;
            let upper_left = lower_left + grid_vertices as u32;
            let upper_right = upper_left + 1;
            indices.extend_from_slice(&[
                lower_left,
                lower_right,
                upper_left,
                lower_right,
                upper_right,
                upper_left,
            ]);
        }
    }

    let bottom: Vec<_> = (0..grid_vertices).map(|x| (x, 0)).collect();
    let right: Vec<_> = (0..grid_vertices).map(|y| (grid_quads, y)).collect();
    let top: Vec<_> = (0..grid_vertices).rev().map(|x| (x, grid_quads)).collect();
    let left: Vec<_> = (0..grid_vertices).rev().map(|y| (0, y)).collect();
    for edge in [bottom, right, top, left] {
        let skirt_start = vertices.len() as u32;
        for &(x, y) in &edge {
            let top_index = y * grid_vertices + x;
            let mut skirt_vertex = vertices[top_index];
            skirt_vertex.skirt_depth_meters = skirt_depth_meters as f32;
            vertices.push(skirt_vertex);
        }
        for segment in 0..grid_quads {
            let top_start = (edge[segment].1 * grid_vertices + edge[segment].0) as u32;
            let top_end = (edge[segment + 1].1 * grid_vertices + edge[segment + 1].0) as u32;
            let skirt_start_vertex = skirt_start + segment as u32;
            let skirt_end_vertex = skirt_start_vertex + 1;
            indices.extend_from_slice(&[
                top_start,
                skirt_start_vertex,
                top_end,
                top_end,
                skirt_start_vertex,
                skirt_end_vertex,
            ]);
        }
    }

    ChunkMesh {
        node,
        anchor_world,
        vertices,
        indices,
        edge_length_meters,
        skirt_depth_meters,
    }
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
pub struct RebasedVertex {
    pub camera_relative_position: [f32; 3],
}

#[allow(dead_code)]
impl RebasedVertex {
    pub const ATTRIBUTES: [wgpu::VertexAttribute; 1] = wgpu::vertex_attr_array![0 => Float32x3];

    pub fn layout() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout {
            array_stride: size_of::<Self>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &Self::ATTRIBUTES,
        }
    }
}

#[allow(dead_code)]
pub struct CubeSphereMesh {
    world_positions: Vec<DVec3>,
    indices: Vec<u32>,
}

#[allow(dead_code)]
impl CubeSphereMesh {
    pub fn new() -> Self {
        let faces = FACE_BASES;
        let vertices_per_face = CHUNK_GRID_VERTICES * CHUNK_GRID_VERTICES;
        let mut world_positions = Vec::with_capacity(faces.len() * vertices_per_face);
        let mut indices = Vec::with_capacity(faces.len() * CHUNK_GRID_QUADS * CHUNK_GRID_QUADS * 6);

        for (face_index, (normal, tangent_u, tangent_v)) in faces.into_iter().enumerate() {
            let face_start = (face_index * vertices_per_face) as u32;
            for y in 0..CHUNK_GRID_VERTICES {
                let v = y as f64 / CHUNK_GRID_QUADS as f64 * 2.0 - 1.0;
                for x in 0..CHUNK_GRID_VERTICES {
                    let u = x as f64 / CHUNK_GRID_QUADS as f64 * 2.0 - 1.0;
                    world_positions.push(
                        (normal + tangent_u * u + tangent_v * v).normalize() * PLANET_RADIUS_METERS,
                    );
                }
            }
            for y in 0..CHUNK_GRID_QUADS {
                for x in 0..CHUNK_GRID_QUADS {
                    let lower_left = face_start + (y * CHUNK_GRID_VERTICES + x) as u32;
                    let lower_right = lower_left + 1;
                    let upper_left = lower_left + CHUNK_GRID_VERTICES as u32;
                    let upper_right = upper_left + 1;
                    indices.extend_from_slice(&[
                        lower_left,
                        lower_right,
                        upper_left,
                        lower_right,
                        upper_right,
                        upper_left,
                    ]);
                }
            }
        }

        Self {
            world_positions,
            indices,
        }
    }

    pub fn indices(&self) -> &[u32] {
        &self.indices
    }

    pub fn rebased_vertices(&self, camera_world_position: DVec3) -> Vec<RebasedVertex> {
        let mut vertices = Vec::with_capacity(self.world_positions.len());
        self.rebase_into(camera_world_position, &mut vertices);
        vertices
    }

    pub fn rebase_into(&self, camera_world_position: DVec3, vertices: &mut Vec<RebasedVertex>) {
        vertices.clear();
        vertices.extend(self.world_positions.iter().map(|world_position| {
            RebasedVertex {
                camera_relative_position: (*world_position - camera_world_position)
                    .as_vec3()
                    .to_array(),
            }
        }));
    }

    #[cfg(test)]
    fn world_positions(&self) -> &[DVec3] {
        &self.world_positions
    }
}

pub struct OrbitCamera {
    pub azimuth_radians: f64,
    pub elevation_radians: f64,
    pub orbit_radius_meters: f64,
    vertical_fov_radians: f64,
    look_yaw_radians: f64,
    look_pitch_radians: f64,
    view_up_hint: DVec3,
}

impl Default for OrbitCamera {
    fn default() -> Self {
        let mut camera = Self {
            azimuth_radians: 0.0,
            elevation_radians: 0.0,
            orbit_radius_meters: 10_000_000.0,
            vertical_fov_radians: DEFAULT_VERTICAL_FOV_RADIANS,
            look_yaw_radians: 0.0,
            look_pitch_radians: 0.0,
            view_up_hint: DVec3::Y,
        };
        camera.look_at_origin();
        camera
    }
}

#[allow(dead_code)]
impl OrbitCamera {
    pub fn world_position(&self) -> DVec3 {
        let horizontal_radius = self.orbit_radius_meters * self.elevation_radians.cos();
        DVec3::new(
            horizontal_radius * self.azimuth_radians.cos(),
            self.orbit_radius_meters * self.elevation_radians.sin(),
            horizontal_radius * self.azimuth_radians.sin(),
        )
    }

    pub fn view_projection(&self, aspect_ratio: f32) -> Mat4 {
        view_projection_for(
            self.direction_dvec3(),
            self.view_up_hint,
            self.orbit_radius_meters - PLANET_RADIUS_METERS,
            self.vertical_fov_radians,
            aspect_ratio,
        )
    }

    pub fn view_projection_in_planet_frame(
        &self,
        aspect_ratio: f32,
        planet_rotation_radians: f64,
    ) -> Mat4 {
        view_projection_for(
            self.planet_frame_direction_dvec3(planet_rotation_radians),
            self.planet_frame_view_up(planet_rotation_radians),
            self.orbit_radius_meters - PLANET_RADIUS_METERS,
            self.vertical_fov_radians,
            aspect_ratio,
        )
    }

    pub fn set_world_pose(&mut self, position: DVec3, look_at: DVec3) {
        self.set_world_pose_with_up(position, look_at, DVec3::Y);
    }

    pub fn set_world_pose_with_up(&mut self, position: DVec3, look_at: DVec3, up_hint: DVec3) {
        assert!(position.is_finite() && look_at.is_finite());
        assert!(up_hint.is_finite() && up_hint.length_squared() > 0.0);
        let radius = position.length();
        assert!(
            radius > 0.0,
            "camera position must not be the planet origin"
        );
        let forward = look_at - position;
        assert!(
            forward.length_squared() > 0.0,
            "camera look target must differ from its position"
        );

        self.orbit_radius_meters = radius;
        self.azimuth_radians = position.z.atan2(position.x);
        self.elevation_radians = (position.y / radius).clamp(-1.0, 1.0).asin();
        self.view_up_hint = up_hint.normalize();

        self.set_look_direction_relative(forward.normalize());
    }

    pub fn orbit(&mut self, azimuth_delta: f64, elevation_delta: f64) {
        self.azimuth_radians += azimuth_delta;
        self.elevation_radians = (self.elevation_radians + elevation_delta).clamp(-1.45, 1.45);
    }

    pub fn advance_inclined_orbit(&mut self, phase_delta_radians: f64, inclination_radians: f64) {
        self.azimuth_radians += phase_delta_radians;
        // Latitude oscillates through the ascending and descending nodes, so
        // the constant-radius path stays in one inclined orbital plane instead
        // of becoming a small circle over a pole.
        self.elevation_radians = (inclination_radians.sin() * self.azimuth_radians.sin())
            .clamp(-1.0, 1.0)
            .asin();
    }

    pub fn look(&mut self, yaw_delta: f64, pitch_delta: f64) {
        self.look_yaw_radians += yaw_delta;
        self.look_pitch_radians = (self.look_pitch_radians + pitch_delta).clamp(-1.5, 1.5);
    }

    pub fn look_with_optical_sensitivity(&mut self, yaw_delta: f64, pitch_delta: f64) {
        let scale = self.look_sensitivity_scale();
        self.look(yaw_delta * scale, pitch_delta * scale);
    }

    pub fn look_at_origin(&mut self) {
        self.look_yaw_radians = 0.0;
        self.look_pitch_radians = 0.0;
    }

    pub fn direction(&self) -> Vec3 {
        self.direction_dvec3().as_vec3()
    }

    pub fn direction_dvec3(&self) -> DVec3 {
        let (down, right, up) = self.orbit_look_frame();
        let horizontal = self.look_pitch_radians.cos();
        (down * (self.look_yaw_radians.cos() * horizontal)
            + right * (self.look_yaw_radians.sin() * horizontal)
            + up * self.look_pitch_radians.sin())
        .normalize()
    }

    pub fn planet_frame_world_position(&self, planet_rotation_radians: f64) -> DVec3 {
        planet_local_vector(self.world_position(), planet_rotation_radians)
    }

    pub fn planet_frame_direction(&self, planet_rotation_radians: f64) -> Vec3 {
        self.planet_frame_direction_dvec3(planet_rotation_radians)
            .as_vec3()
    }

    pub fn planet_frame_direction_dvec3(&self, planet_rotation_radians: f64) -> DVec3 {
        planet_local_vector(self.direction_dvec3(), planet_rotation_radians)
    }

    pub fn planet_frame_view_up(&self, planet_rotation_radians: f64) -> DVec3 {
        planet_local_vector(self.view_up_hint, planet_rotation_radians)
    }

    pub fn vertical_fov_radians(&self) -> f64 {
        self.vertical_fov_radians
    }

    pub fn look_sensitivity_scale(&self) -> f64 {
        (self.vertical_fov_radians / DEFAULT_VERTICAL_FOV_RADIANS).min(1.0)
    }

    pub fn set_vertical_fov_degrees(&mut self, vertical_fov_degrees: f64) {
        self.set_vertical_fov_degrees_for_viewport(
            vertical_fov_degrees,
            REFERENCE_VERTICAL_FOV_VIEWPORT_HEIGHT,
        );
    }

    pub fn set_vertical_fov_degrees_for_viewport(
        &mut self,
        vertical_fov_degrees: f64,
        viewport_height: u32,
    ) {
        assert!(vertical_fov_degrees.is_finite() && vertical_fov_degrees > 0.0);
        self.vertical_fov_radians = vertical_fov_degrees.to_radians().clamp(
            minimum_vertical_fov_radians_for_viewport(viewport_height),
            MAX_VERTICAL_FOV_RADIANS,
        );
    }

    pub fn zoom(&mut self, wheel_delta: f64) {
        self.zoom_for_viewport(wheel_delta, REFERENCE_VERTICAL_FOV_VIEWPORT_HEIGHT);
    }

    pub fn zoom_for_viewport(&mut self, wheel_delta: f64, viewport_height: u32) {
        self.vertical_fov_radians =
            (self.vertical_fov_radians * (-wheel_delta * ZOOM_LOG_FOV_PER_WHEEL_STEP).exp()).clamp(
                minimum_vertical_fov_radians_for_viewport(viewport_height),
                MAX_VERTICAL_FOV_RADIANS,
            );
    }

    pub fn clamp_vertical_fov_for_viewport(&mut self, viewport_height: u32) {
        self.vertical_fov_radians = self.vertical_fov_radians.clamp(
            minimum_vertical_fov_radians_for_viewport(viewport_height),
            MAX_VERTICAL_FOV_RADIANS,
        );
    }

    fn orbit_look_frame(&self) -> (DVec3, DVec3, DVec3) {
        let basis = CameraViewBasis::from_forward(-self.world_position().normalize());
        (basis.forward, basis.right, basis.up)
    }

    fn set_look_direction_relative(&mut self, direction: DVec3) {
        let (down, right, up) = self.orbit_look_frame();
        self.look_yaw_radians = direction.dot(right).atan2(direction.dot(down));
        self.look_pitch_radians = direction.dot(up).clamp(-1.0, 1.0).asin();
    }

    pub fn set_reference_vertical_fov_degrees_for_viewport(
        &mut self,
        reference_vertical_fov_degrees: f64,
        viewport_height: u32,
    ) {
        self.vertical_fov_radians = reference_vertical_fov_radians_for_viewport(
            reference_vertical_fov_degrees.to_radians(),
            viewport_height,
        );
    }
}

#[allow(dead_code)]
fn view_projection_for(
    forward: DVec3,
    up_hint: DVec3,
    altitude_meters: f64,
    vertical_fov_radians: f64,
    aspect_ratio: f32,
) -> Mat4 {
    let view = Mat4::look_to_rh(Vec3::ZERO, forward.as_vec3(), up_hint.as_vec3());
    let near = (altitude_meters * 0.01).clamp(0.05, 10.0) as f32;
    reversed_z_infinite_perspective(vertical_fov_radians as f32, aspect_ratio, near) * view
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
pub struct CameraUniform {
    pub projection_matrix: [[f32; 4]; 4],
    pub camera_forward: [f32; 4],
    pub camera_right: [f32; 4],
    pub camera_up: [f32; 4],
    pub camera_planet_direction_view_altitude: [f32; 4],
    pub sun_direction: [f32; 4],
    pub sun_direction_view: [f32; 4],
    pub projection: [f32; 4],
    pub flat_triangle_options: [f32; 4],
}

#[repr(u32)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum RenderDebugMode {
    Final = 0,
    RawAlbedo = 1,
    SurfaceLighting = 2,
    AerialContribution = 3,
    SkyOnly = 4,
    RayHitStatus = 5,
    FlatTriangles = 6,
}

#[repr(u32)]
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub enum FlatTriangleOutlineMode {
    Off = 0,
    #[default]
    Dark = 1,
    BlackRed = 2,
}

impl FlatTriangleOutlineMode {
    pub const fn next(self) -> Self {
        match self {
            Self::Dark => Self::Off,
            Self::Off => Self::BlackRed,
            Self::BlackRed => Self::Dark,
        }
    }

    pub const fn label(self) -> &'static str {
        match self {
            Self::Off => "off",
            Self::Dark => "dark",
            Self::BlackRed => "black fill / red edges",
        }
    }
}

impl RenderDebugMode {
    pub const fn next(self) -> Self {
        match self {
            Self::Final => Self::RawAlbedo,
            Self::RawAlbedo => Self::SurfaceLighting,
            Self::SurfaceLighting => Self::AerialContribution,
            Self::AerialContribution => Self::SkyOnly,
            Self::SkyOnly => Self::FlatTriangles,
            Self::FlatTriangles | Self::RayHitStatus => Self::Final,
        }
    }

    pub const fn label(self) -> &'static str {
        match self {
            Self::Final => "final HDR scene",
            Self::RawAlbedo => "raw material albedo",
            Self::SurfaceLighting => "surface lighting",
            Self::AerialContribution => "aerial contribution",
            Self::SkyOnly => "sky only",
            Self::RayHitStatus => "ray detail-hit status",
            Self::FlatTriangles => "flat L7 triangles",
        }
    }
}

/// Distance to the near plane. Scaling it with the camera's height keeps depth
/// precision usable across the whole range from orbit to ground, but the height
/// that matters is the one above the *terrain*, not above the reference sphere.
///
/// Measured from sea level, standing on 920 m of ground put the near plane 9.2 m
/// out and quietly clipped away everything within 9.2 m of the camera -- the
/// entire foreground at eye level -- leaving cleared background that reads
/// convincingly as unlit terrain. Any camera near high ground had the same hole
/// in front of it, in proportion to the ground's elevation.
pub fn near_plane_meters(camera_altitude_meters: f64, surface_height_meters: f64) -> f64 {
    let clearance_meters = (camera_altitude_meters - surface_height_meters.max(0.0))
        .clamp(0.0, camera_altitude_meters.max(0.0));
    (clearance_meters * 0.01).clamp(0.05, 10.0)
}

impl CameraUniform {
    pub fn from_camera(
        camera: &OrbitCamera,
        aspect_ratio: f32,
        sun_direction: DVec3,
        planet_rotation_radians: f64,
        ocean_animation_time_seconds: f64,
        render_debug_mode: RenderDebugMode,
        flat_triangle_outline_mode: FlatTriangleOutlineMode,
        // Terrain height under the camera, so the near plane can be set from
        // how far the ground actually is rather than from sea level. Pass 0.0
        // when it is not known; that is the old behaviour.
        surface_height_meters: f64,
    ) -> Self {
        let basis = CameraViewBasis::from_forward_and_up(
            camera.planet_frame_direction_dvec3(planet_rotation_radians),
            camera.planet_frame_view_up(planet_rotation_radians),
        );
        let camera_world_position = camera.planet_frame_world_position(planet_rotation_radians);
        let camera_radius = camera_world_position.length();
        let camera_altitude = camera_radius - PLANET_RADIUS_METERS;
        let planet_direction_view = basis
            .world_to_view(camera_world_position / camera_radius)
            .as_vec3();
        let sun_direction = planet_local_vector(sun_direction, planet_rotation_radians).normalize();
        let sun_direction_view = basis.world_to_view(sun_direction).as_vec3();
        let forward = basis.forward.as_vec3();
        let right = basis.right.as_vec3();
        let up = basis.up.as_vec3();
        let sun_direction = sun_direction.as_vec3();
        let near = near_plane_meters(camera_altitude, surface_height_meters) as f32;
        Self {
            projection_matrix: reversed_z_infinite_perspective(
                camera.vertical_fov_radians as f32,
                aspect_ratio,
                near,
            )
            .to_cols_array_2d(),
            camera_forward: [forward.x, forward.y, forward.z, 0.0],
            camera_right: [right.x, right.y, right.z, 0.0],
            camera_up: [up.x, up.y, up.z, 0.0],
            camera_planet_direction_view_altitude: [
                planet_direction_view.x,
                planet_direction_view.y,
                planet_direction_view.z,
                camera_altitude as f32,
            ],
            sun_direction: [sun_direction.x, sun_direction.y, sun_direction.z, 0.0],
            sun_direction_view: [
                sun_direction_view.x,
                sun_direction_view.y,
                sun_direction_view.z,
                0.0,
            ],
            projection: [
                aspect_ratio,
                (camera.vertical_fov_radians as f32 * 0.5).tan(),
                ocean_animation_time_seconds as f32,
                render_debug_mode as u32 as f32,
            ],
            flat_triangle_options: [flat_triangle_outline_mode as u32 as f32, 0.0, 0.0, 0.0],
        }
    }
}

fn reversed_z_infinite_perspective(
    vertical_fov_radians: f32,
    aspect_ratio: f32,
    near: f32,
) -> Mat4 {
    let focal_length = 1.0 / (vertical_fov_radians * 0.5).tan();
    Mat4::from_cols(
        Vec4::new(focal_length / aspect_ratio, 0.0, 0.0, 0.0),
        Vec4::new(0.0, focal_length, 0.0, 0.0),
        Vec4::new(0.0, 0.0, 0.0, -1.0),
        Vec4::new(0.0, 0.0, near, 0.0),
    )
}

#[cfg(test)]
mod tests {
    use glam::{DVec3, Vec3};

    use super::{
        CHUNK_GRID_QUADS, CHUNK_GRID_VERTICES, CameraUniform, CameraViewBasis, CubeSphereMesh,
        DEFAULT_MAX_ACTIVE_CHUNKS, DEFAULT_VERTICAL_FOV_RADIANS, EARTH_AXIAL_TILT_RADIANS,
        FLAT_TRIANGLE_LOD_LEVEL, FlatTriangleOutlineMode, GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS,
        GLOBAL_TERRAIN_DETAIL_HEIGHT_SCALE, GeometricErrorRatio, LodPolicy, MAX_LOD_LEVEL,
        MAX_SKIRT_DEPTH_METERS, MAX_VERTICAL_FOV_RADIANS, MIN_VERTICAL_FOV_RADIANS,
        MINIMUM_LOD_LEVEL, NEAR_FIELD_GRID_QUADS, OUTMAP_TERRAIN_FAR_HEIGHT_SCALE,
        OUTMAP_TERRAIN_HEIGHT_BLEND_END_METERS, OUTMAP_TERRAIN_HEIGHT_BLEND_START_METERS,
        OUTMAP_TERRAIN_HEIGHT_SCALE, OUTMAP_TERRAIN_NEAR_HEIGHT_SCALE, OrbitCamera,
        PLANET_RADIUS_METERS, PLANET_ROTATION_PERIOD_SECONDS, PlanetLod, QuadtreeNode,
        RenderDebugMode, SKIRT_DEPTH_RATIO, TERRAIN_DETAIL_OCTAVES, TERRAIN_DETAIL_RIDGE_CENTRE,
        TERRAIN_DETAIL_RIDGE_NORMALISATION, TERRAIN_DETAIL_RIDGE_SCALE,
        TERRAIN_DETAIL_RIDGE_SOFTNESS, TERRAIN_DETAIL_RIDGE_STRENGTH, TERRAIN_DETAIL_ROUGHNESS,
        TERRAIN_DETAIL_START_WAVELENGTH_METERS, TerrainHeightRange, build_chunk_mesh,
        build_chunk_mesh_with_quads, continuous_baked_sample_spacing_meters, cube_face_basis,
        cube_face_direction, default_sun_direction, detailed_outmap_land_height_meters,
        global_terrain_detail_meters, minimum_vertical_fov_radians_for_viewport,
        near_camera_lod_priority_weight, near_plane_meters, outmap_surface_height_meters,
        outmap_terrain_height_scale, placeholder_height_meters, planet_local_vector,
        planet_rotation_radians, projected_error_pixels_with_height_range,
        scaled_outmap_macro_height_meters, terrain_detail_meters, terrain_detail_value_noise,
        unbalanced_coarse_neighbors,
    };

    fn projected_error_pixels(
        node: QuadtreeNode,
        camera_world: DVec3,
        viewport_height: u32,
        vertical_fov_radians: f64,
    ) -> f64 {
        projected_error_pixels_with_height_range(
            node,
            camera_world,
            viewport_height,
            vertical_fov_radians,
            TerrainHeightRange::default(),
        )
    }

    #[test]
    fn render_debug_mode_cycles_back_to_final() {
        let mut mode = RenderDebugMode::Final;
        for expected in [
            RenderDebugMode::RawAlbedo,
            RenderDebugMode::SurfaceLighting,
            RenderDebugMode::AerialContribution,
            RenderDebugMode::SkyOnly,
            RenderDebugMode::FlatTriangles,
            RenderDebugMode::Final,
        ] {
            mode = mode.next();
            assert_eq!(mode, expected);
        }
    }

    #[test]
    fn fixed_lod_policy_stops_at_the_experiment_level() {
        let policy = LodPolicy::fixed(FLAT_TRIANGLE_LOD_LEVEL);
        assert_eq!(policy.max_level, FLAT_TRIANGLE_LOD_LEVEL);
        assert!(policy.should_split(0.0, FLAT_TRIANGLE_LOD_LEVEL - 1));
        assert!(!policy.should_split(0.0, FLAT_TRIANGLE_LOD_LEVEL));
        assert!(!policy.should_merge(0.0, FLAT_TRIANGLE_LOD_LEVEL));
    }

    #[test]
    fn near_camera_priority_favours_detail_over_horizon_demand() {
        let camera = DVec3::X * (PLANET_RADIUS_METERS + 1_000.0);
        let terrain_range = TerrainHeightRange::default();
        let near = QuadtreeNode {
            face: 0,
            level: 7,
            x: 64,
            y: 64,
        };
        let far = QuadtreeNode {
            face: 1,
            level: 2,
            x: 0,
            y: 0,
        };
        assert!(
            near_camera_lod_priority_weight(near, camera, terrain_range)
                > near_camera_lod_priority_weight(far, camera, terrain_range)
        );
    }

    #[test]
    fn camera_center_leaf_receives_detail_priority() {
        let camera = DVec3::new(
            3_844_538.706_859_7367,
            -1_062_789.178_810_5723,
            -414_352.755_166_1257,
        );
        let forward = super::planet_local_vector(
            DVec3::new(0.113, 0.546, 0.830).normalize(),
            4.147_097_337_208_69,
        );
        let up = camera.normalize();
        let mut lod = PlanetLod::new(
            LodPolicy::fixed(FLAT_TRIANGLE_LOD_LEVEL),
            DEFAULT_MAX_ACTIVE_CHUNKS,
        );
        lod.set_terrain_height_range(TerrainHeightRange::new(-5_000.0, 40_000.0));
        let update = lod.update_for_view_with_up(
            camera,
            forward,
            up,
            16.0 / 9.0,
            540,
            45.0_f64.to_radians(),
        );
        let centre_direction = camera.normalize();
        let centre = update
            .active_nodes
            .iter()
            .find(|node| super::node_contains_direction(**node, centre_direction))
            .expect("camera-facing direction has a selected leaf");
        assert!(centre.level >= FLAT_TRIANGLE_LOD_LEVEL - 1);
    }

    #[test]
    fn low_flight_inside_global_height_bound_refines_the_viewed_surface() {
        // Captures 008, 013 and 018 from manual run 1787775525-639587. The
        // centre surface moved from 81km to 49km to 8km away, but the old
        // smooth-surface error stopped at L11/L12 and made its flat triangles
        // grow visibly larger during the approach.
        let approach = [
            (
                DVec3::new(
                    -1_610_419.202_839_294_2,
                    -1_650_753.163_871_058_3,
                    3_327_481.670_909_104_4,
                ),
                DVec3::new(-0.841_825, -0.104_310, -0.529_575).normalize(),
                35_125.028_049_250_504,
                81_079.905_653_042_14,
            ),
            (
                DVec3::new(
                    -1_637_169.606_668_696,
                    -1_654_029.092_904_106_2,
                    3_310_537.751_499_275,
                ),
                DVec3::new(-0.838_135, -0.100_913, -0.536_047).normalize(),
                34_857.261_508_259_18,
                48_641.325_137_953_216,
            ),
            (
                DVec3::new(
                    -1_670_860.946_859_876_9,
                    -1_658_026.098_206_200_2,
                    3_288_811.756_989_73,
                ),
                DVec3::new(-0.834_446, -0.097_561, -0.542_386).normalize(),
                37_933.577_111_662_42,
                8_042.000_149_606_683,
            ),
        ];
        let global_height_range = TerrainHeightRange::new(-5_000.0, 190_692.0);
        let mut lod = PlanetLod::default();
        lod.set_terrain_height_range(global_height_range);
        let mut viewed_levels = Vec::new();
        for (camera, forward, local_surface_height_meters, hit_distance) in approach {
            assert!(
                super::camera_center_surface_direction(camera, forward, global_height_range)
                    .is_none(),
                "a camera inside the outer terrain bound must not select its far-side exit",
            );
            let viewed_direction = (camera + forward * hit_distance).normalize();
            lod.set_distance_reference_height(local_surface_height_meters);
            lod.set_view_focus_direction(Some(viewed_direction));
            let update = lod.update_for_view_with_constraints(
                camera,
                forward,
                camera.normalize(),
                16.0 / 9.0,
                1_080,
                75.0_f64.to_radians(),
                GeometricErrorRatio {
                    baked: 0.053_6 * 5.0,
                    ladder: TERRAIN_DETAIL_ROUGHNESS * 2.939_5 * 5.0,
                },
                &|_| MAX_LOD_LEVEL,
                None,
            );
            viewed_levels.push(
                update
                    .active_nodes
                    .iter()
                    .find(|node| super::node_contains_direction(**node, viewed_direction))
                    .expect("the viewed surface has a selected leaf")
                    .level,
            );
        }
        assert!(
            viewed_levels
                .windows(2)
                .all(|levels| levels[1] >= levels[0]),
            "the approached centre terrain became coarser: {viewed_levels:?}",
        );
        assert!(
            viewed_levels[2] >= 14,
            "final focus levels: {viewed_levels:?}"
        );
    }

    #[test]
    fn manual_reverse_approach_keeps_the_central_view_patch_detailed() {
        // The four F12 captures from manual run 1787828575-973578 move
        // backwards from the same valley. The old single-leaf focus selected
        // an L13 needle inside an L11 central patch at the closest pose, so
        // mixed-LOD edge filtering erased visible relief until capture 003.
        let poses = [
            (
                DVec3::new(
                    -1_665_730.801_731_096_6,
                    -1_695_300.517_020_673,
                    3_266_789.230_904_985_7,
                ),
                DVec3::new(-0.560, -0.072, -0.826).normalize(),
                36_369.949_408_103_02,
                8_704.092_243_409_21,
            ),
            (
                DVec3::new(
                    -1_656_365.841_478_380_1,
                    -1_694_075.111_374_183,
                    3_280_557.206_282_143_5,
                ),
                DVec3::new(-0.562, -0.074, -0.824).normalize(),
                36_716.541_375_728_14,
                25_520.148_457_686_704,
            ),
            (
                DVec3::new(
                    -1_647_649.262_732_673_7,
                    -1_692_912.083_495_574_8,
                    3_293_285.051_059_488_7,
                ),
                DVec3::new(-0.565, -0.076, -0.822).normalize(),
                37_547.053_910_746_22,
                41_159.309_864_761_41,
            ),
            (
                DVec3::new(
                    -1_635_713.682_152_411_2,
                    -1_691_285.013_613_014_7,
                    3_310_579.612_690_881,
                ),
                DVec3::new(-0.568, -0.078, -0.819).normalize(),
                37_202.489_330_303_53,
                62_833.722_559_754_904,
            ),
        ];
        let mut lod = PlanetLod::default();
        lod.set_terrain_height_range(TerrainHeightRange::new(-5_000.0, 186_702.0));
        let mut focused_levels = Vec::new();
        for (camera, forward, local_height, centre_distance) in poses {
            let focus = (camera + forward * centre_distance).normalize();
            lod.set_distance_reference_height(local_height);
            lod.set_view_focus_direction(Some(focus));
            let update = lod.update_for_view_with_constraints(
                camera,
                forward,
                camera.normalize(),
                640.0 / 427.0,
                427,
                60.0_f64.to_radians(),
                GeometricErrorRatio {
                    baked: 0.053_6 * 5.0,
                    ladder: TERRAIN_DETAIL_ROUGHNESS * 2.939_5 * 5.0,
                },
                &|_| MAX_LOD_LEVEL,
                None,
            );
            let level = update
                .active_nodes
                .iter()
                .find(|node| super::node_contains_direction(**node, focus))
                .unwrap()
                .level;
            let tangent_x = focus.cross(DVec3::Y).normalize();
            let tangent_y = tangent_x.cross(focus).normalize();
            let focus_radius = centre_distance * 12.0_f64.to_radians().tan();
            let mut neighborhood = Vec::new();
            for (x, y) in [(0, 0), (-1, 0), (1, 0), (0, -1), (0, 1)] {
                let direction = (focus
                    + tangent_x * (f64::from(x) * focus_radius / PLANET_RADIUS_METERS)
                    + tangent_y * (f64::from(y) * focus_radius / PLANET_RADIUS_METERS))
                    .normalize();
                neighborhood.push(
                    update
                        .active_nodes
                        .iter()
                        .find(|node| super::node_contains_direction(**node, direction))
                        .map_or(0, |node| node.level),
                );
            }
            let lowest_near_focus = neighborhood.into_iter().min().unwrap();
            assert!(
                lowest_near_focus + 1 >= level,
                "centre L{level} was an isolated needle above an L{lowest_near_focus} view patch",
            );
            focused_levels.push(level);
        }
        assert!(
            focused_levels
                .windows(2)
                .all(|levels| levels[1] <= levels[0]),
            "moving away increased centre detail: {focused_levels:?}",
        );
    }

    #[test]
    fn quadtree_children_tile_the_parent_node() {
        let children = QuadtreeNode::root(3).children();
        assert_eq!(
            children[0],
            QuadtreeNode {
                face: 3,
                level: 1,
                x: 0,
                y: 0
            }
        );
        assert_eq!(
            children[3],
            QuadtreeNode {
                face: 3,
                level: 1,
                x: 1,
                y: 1
            }
        );
        let policy = LodPolicy::default();
        assert_eq!(policy.split_pixels, 1.25);
        assert_eq!(policy.merge_pixels, 0.625);
        assert!(policy.should_split(2.1, 0));
        assert!(!policy.should_merge(1.0, MINIMUM_LOD_LEVEL - 1));
        assert!(policy.should_merge(0.5, MINIMUM_LOD_LEVEL));
        assert_eq!(policy.max_level, MAX_LOD_LEVEL);
        assert_eq!(children[0].parent(), Some(QuadtreeNode::root(3)));
        assert!(children.iter().all(|child| child.is_valid()));
    }

    #[test]
    fn projected_error_decreases_with_distance_and_level() {
        let node = QuadtreeNode::root(0);
        let near = DVec3::X * (PLANET_RADIUS_METERS * 3.0);
        let far = DVec3::X * (PLANET_RADIUS_METERS * 30.0);
        let near_error = projected_error_pixels(node, near, 1_080, 45.0_f64.to_radians());
        let far_error = projected_error_pixels(node, far, 1_080, 45.0_f64.to_radians());
        assert!(near_error > far_error);
        assert_eq!(
            node.children()[0].geometric_error_meters(),
            node.geometric_error_meters() * 0.5
        );
    }

    #[test]
    fn orbit_selection_stays_coarse_and_bounded() {
        let camera = OrbitCamera::default();
        let mut lod = PlanetLod::default();
        let update = lod.update_for_view(
            camera.world_position(),
            camera.direction_dvec3(),
            1.5,
            1_080,
            45.0_f64.to_radians(),
        );
        assert!(update.metrics.active_chunks <= super::DEFAULT_MAX_ACTIVE_CHUNKS as u32);
        assert_eq!(update.metrics.max_level, MINIMUM_LOD_LEVEL);
        assert!(
            update
                .active_nodes
                .iter()
                .all(|node| node.level >= MINIMUM_LOD_LEVEL)
        );
        assert!(!update.metrics.budget_limited);
    }

    #[test]
    fn frustum_culling_refines_only_the_visible_zoomed_patch() {
        let camera = OrbitCamera::default();
        let position = camera.world_position();
        let forward = -position.normalize();
        let mut wide_lod = PlanetLod::default();
        let wide = wide_lod.update_for_view(position, forward, 1.5, 1_080, 45.0_f64.to_radians());
        let mut zoomed_lod = PlanetLod::default();
        let zoomed =
            zoomed_lod.update_for_view(position, forward, 1.5, 1_080, 2.0_f64.to_radians());

        assert!(
            zoomed.metrics.active_chunks < wide.metrics.active_chunks,
            "wide chunks: {}, zoomed chunks: {}",
            wide.metrics.active_chunks,
            zoomed.metrics.active_chunks
        );
        assert!(zoomed.metrics.max_level >= wide.metrics.max_level);
        assert!(zoomed.metrics.max_level > MINIMUM_LOD_LEVEL);
        assert!(
            zoomed
                .active_nodes
                .iter()
                .all(|node| node.level >= MINIMUM_LOD_LEVEL)
        );
    }

    #[test]
    fn orbital_optical_zoom_traverses_every_lod_level_in_both_directions() {
        let mut camera = OrbitCamera::default();
        camera.set_vertical_fov_degrees(75.0);
        let position = camera.world_position();
        let forward = -position.normalize();
        let mut lod = PlanetLod::default();
        let mut observed_levels = Vec::new();
        let mut lod_thrash_events = 0_u32;

        let mut zoom_in_steps = 0;
        loop {
            let update =
                lod.update_for_view(position, forward, 1.5, 640, camera.vertical_fov_radians());
            assert!(!update.metrics.budget_limited);
            assert!(update.metrics.active_chunks <= super::DEFAULT_MAX_ACTIVE_CHUNKS as u32);
            lod_thrash_events += update.metrics.lod_thrash_events;
            if observed_levels.last() != Some(&update.metrics.max_level) {
                observed_levels.push(update.metrics.max_level);
            }
            if camera.vertical_fov_radians() == MIN_VERTICAL_FOV_RADIANS {
                break;
            }
            camera.zoom(1.0);
            zoom_in_steps += 1;
        }
        for _ in 0..=super::LOD_THRASH_WINDOW_UPDATES {
            let update =
                lod.update_for_view(position, forward, 1.5, 640, camera.vertical_fov_radians());
            assert!(!update.metrics.budget_limited);
            lod_thrash_events += update.metrics.lod_thrash_events;
        }
        let mut zoom_out_steps = 0;
        loop {
            camera.zoom(-1.0);
            zoom_out_steps += 1;
            let update =
                lod.update_for_view(position, forward, 1.5, 640, camera.vertical_fov_radians());
            assert!(!update.metrics.budget_limited);
            assert!(update.metrics.active_chunks <= super::DEFAULT_MAX_ACTIVE_CHUNKS as u32);
            lod_thrash_events += update.metrics.lod_thrash_events;
            if observed_levels.last() != Some(&update.metrics.max_level) {
                observed_levels.push(update.metrics.max_level);
            }
            if camera.vertical_fov_radians() == MAX_VERTICAL_FOV_RADIANS {
                break;
            }
        }

        let mut expected_levels: Vec<_> = (MINIMUM_LOD_LEVEL..=MAX_LOD_LEVEL).collect();
        expected_levels.extend((MINIMUM_LOD_LEVEL..MAX_LOD_LEVEL).rev());
        assert_eq!(observed_levels, expected_levels);
        assert_eq!(lod_thrash_events, 0);
        assert_eq!(zoom_in_steps, zoom_out_steps);
        assert!(zoom_in_steps < 128);
    }

    #[test]
    fn maximum_zoom_reaches_every_lod_at_any_viewport_height() {
        for viewport_height in [1, 240, 640, 2_160] {
            let mut camera = OrbitCamera::default();
            camera.set_vertical_fov_degrees_for_viewport(75.0, viewport_height);
            let position = camera.world_position();
            let forward = -position.normalize();
            let mut lod = PlanetLod::default();
            let mut observed_levels = Vec::new();
            let minimum_fov = minimum_vertical_fov_radians_for_viewport(viewport_height);
            let mut zoom_steps = 0;

            loop {
                let update = lod.update_for_view(
                    position,
                    forward,
                    1.5,
                    viewport_height,
                    camera.vertical_fov_radians(),
                );
                assert!(!update.metrics.budget_limited);
                if observed_levels.last() != Some(&update.metrics.max_level) {
                    observed_levels.push(update.metrics.max_level);
                }
                if camera.vertical_fov_radians() == minimum_fov {
                    break;
                }
                camera.zoom_for_viewport(1.0, viewport_height);
                zoom_steps += 1;
            }

            assert_eq!(
                observed_levels,
                (MINIMUM_LOD_LEVEL..=MAX_LOD_LEVEL).collect::<Vec<_>>(),
                "viewport height {viewport_height} skipped a renderable LOD"
            );
            assert!(zoom_steps < 192);
        }
    }

    #[test]
    fn persistent_selector_respects_split_merge_hysteresis() {
        let node = QuadtreeNode {
            face: 0,
            level: MINIMUM_LOD_LEVEL,
            x: 1 << (MINIMUM_LOD_LEVEL - 1),
            y: 1 << (MINIMUM_LOD_LEVEL - 1),
        };
        let mut lod = PlanetLod::new(
            LodPolicy {
                split_pixels: 2.0,
                merge_pixels: 1.25,
                max_level: MINIMUM_LOD_LEVEL + 1,
            },
            1_024,
        );
        let near = camera_for_error(node, 2.5);
        lod.update(near, 1_080, 45.0_f64.to_radians());
        assert!(lod.is_split(node));

        let hysteresis_band = camera_for_error(node, 1.6);
        lod.update(hysteresis_band, 1_080, 45.0_f64.to_radians());
        assert!(lod.is_split(node));

        let far = camera_for_error(node, 0.1);
        let merged = lod.update(far, 1_080, 45.0_f64.to_radians());
        assert!(!lod.is_split(node));
        assert!(merged.metrics.merges > 0);
        assert!(merged.metrics.lod_thrash_events > 0);
    }

    #[test]
    fn monotonic_descent_does_not_report_lod_thrash() {
        let root = QuadtreeNode::root(0);
        let mut lod = PlanetLod::new(
            LodPolicy {
                split_pixels: 2.0,
                merge_pixels: 1.25,
                max_level: 4,
            },
            256,
        );
        for target_error in [0.8, 1.1, 1.6, 2.1, 3.0, 5.0, 9.0] {
            let update = lod.update(
                camera_for_error(root, target_error),
                1_080,
                45.0_f64.to_radians(),
            );
            assert_eq!(update.metrics.lod_thrash_events, 0);
        }
    }

    #[test]
    fn two_kilometer_selection_uses_screen_distance_without_exhausting_budget() {
        let mut lod = PlanetLod::default();
        let camera = DVec3::X * (PLANET_RADIUS_METERS + 2_000.0);
        let update = lod.update(camera, 1_080, 45.0_f64.to_radians());
        assert!(update.metrics.max_level > MINIMUM_LOD_LEVEL);
        assert!(update.metrics.max_level < MAX_LOD_LEVEL);
        assert!(!update.metrics.budget_limited);
        assert!(update.metrics.active_chunks < super::DEFAULT_MAX_ACTIVE_CHUNKS as u32);
    }

    #[test]
    fn terrain_source_level_limit_prevents_empty_refinement() {
        let mut lod = PlanetLod::default();
        let camera = DVec3::X * (PLANET_RADIUS_METERS + 2_000.0);
        let maximum_useful_level = 6;
        let update = lod.update_for_view_with_up_and_level_limit(
            camera,
            -DVec3::X,
            DVec3::Y,
            16.0 / 9.0,
            1_080,
            60.0_f64.to_radians(),
            &|_| maximum_useful_level,
        );

        assert_eq!(update.metrics.max_level, maximum_useful_level);
        assert!(!update.metrics.budget_limited);
        assert!(update.metrics.active_chunks < super::DEFAULT_MAX_ACTIVE_CHUNKS as u32);
        assert!(
            update
                .active_nodes
                .iter()
                .all(|node| node.level <= maximum_useful_level)
        );
    }

    #[test]
    fn near_surface_selection_reaches_level_eighteen_without_dense_refinement() {
        let mut lod = PlanetLod::default();
        let camera = DVec3::X * (PLANET_RADIUS_METERS + 10.0);
        let update = lod.update(camera, 1_080, 45.0_f64.to_radians());
        assert_eq!(update.metrics.max_level, MAX_LOD_LEVEL);
        assert!(update.active_nodes.len() <= super::DEFAULT_MAX_ACTIVE_CHUNKS);
        assert_eq!(
            update.metrics.level_histogram.iter().copied().sum::<u32>(),
            update.metrics.active_chunks
        );
        assert_eq!(update.metrics.chunks_loaded, update.metrics.active_chunks);
        assert!(update.metrics.culled_nodes > 0);
        assert!(update.metrics.max_seam_delta_meters < 0.01);

        let stable = lod.update(camera, 1_080, 45.0_f64.to_radians());
        assert_eq!(stable.metrics.chunks_loaded, 0);
        assert_eq!(stable.metrics.chunks_unloaded, 0);
    }

    #[test]
    fn chunk_mesh_has_fixed_grid_and_proportional_skirts() {
        assert_eq!(MAX_SKIRT_DEPTH_METERS, 10.0);
        let coarse_chunk = build_chunk_mesh(QuadtreeNode {
            face: 0,
            level: 4,
            x: 7,
            y: 9,
        });
        let top_vertex_count = CHUNK_GRID_VERTICES * CHUNK_GRID_VERTICES;
        assert_eq!(
            coarse_chunk.vertices.len(),
            top_vertex_count + 4 * CHUNK_GRID_VERTICES
        );
        assert_eq!(
            coarse_chunk.indices.len(),
            CHUNK_GRID_QUADS * CHUNK_GRID_QUADS * 6 + 4 * CHUNK_GRID_QUADS * 6
        );
        assert!(
            coarse_chunk.vertices[..top_vertex_count]
                .iter()
                .all(|vertex| vertex.skirt_depth_meters == 0.0)
        );
        assert!(
            coarse_chunk.vertices[top_vertex_count..]
                .iter()
                .all(|vertex| vertex.skirt_depth_meters > 0.0)
        );
        assert_eq!(coarse_chunk.skirt_depth_meters, MAX_SKIRT_DEPTH_METERS);

        let fine_chunk = build_chunk_mesh(QuadtreeNode {
            face: 0,
            level: 18,
            x: 131_071,
            y: 131_071,
        });
        assert!(
            (fine_chunk.skirt_depth_meters / fine_chunk.edge_length_meters - SKIRT_DEPTH_RATIO)
                .abs()
                < f64::EPSILON
        );
        let top_world = coarse_chunk.vertex_world_position(0, false);
        let skirt_world = coarse_chunk.vertex_world_position(top_vertex_count, false);
        assert!(
            (top_world.distance(skirt_world) - coarse_chunk.skirt_depth_meters).abs()
                < coarse_chunk.skirt_depth_meters * 0.001
        );

        let near_field_chunk = build_chunk_mesh_with_quads(
            QuadtreeNode {
                face: 0,
                level: 12,
                x: 2_047,
                y: 2_048,
            },
            NEAR_FIELD_GRID_QUADS,
        );
        let near_field_top_vertex_count = (NEAR_FIELD_GRID_QUADS + 1).pow(2);
        assert_eq!(
            near_field_chunk.vertices.len(),
            near_field_top_vertex_count + 4 * (NEAR_FIELD_GRID_QUADS + 1)
        );
        assert_eq!(
            near_field_chunk.indices.len(),
            NEAR_FIELD_GRID_QUADS * NEAR_FIELD_GRID_QUADS * 6 + 4 * NEAR_FIELD_GRID_QUADS * 6
        );
        let adjacent_near_field_chunk = build_chunk_mesh_with_quads(
            QuadtreeNode {
                face: 0,
                level: 12,
                x: 2_048,
                y: 2_048,
            },
            NEAR_FIELD_GRID_QUADS,
        );
        for y in 0..=NEAR_FIELD_GRID_QUADS {
            let left_index = y * (NEAR_FIELD_GRID_QUADS + 1) + NEAR_FIELD_GRID_QUADS;
            let right_index = y * (NEAR_FIELD_GRID_QUADS + 1);
            assert!(
                near_field_chunk
                    .vertex_world_position(left_index, true)
                    .distance(adjacent_near_field_chunk.vertex_world_position(right_index, true))
                    < 1.0
            );
        }
    }

    #[test]
    fn placeholder_height_and_cube_face_edges_are_seam_continuous() {
        assert!(placeholder_height_meters(DVec3::X).abs() < 1.0e-12);
        assert!(super::PLACEHOLDER_HEIGHT_AMPLITUDE_METERS < 4_000.0);
        for face in 0..6 {
            for y in 0..=8 {
                for x in 0..=8 {
                    let direction =
                        cube_face_direction(face, -1.0 + x as f64 * 0.25, -1.0 + y as f64 * 0.25);
                    assert!(
                        placeholder_height_meters(direction).abs()
                            <= super::PLACEHOLDER_HEIGHT_AMPLITUDE_METERS
                    );
                }
            }
        }
        for step in 0..=CHUNK_GRID_QUADS {
            let v = -1.0 + 2.0 * step as f64 / CHUNK_GRID_QUADS as f64;
            let positive_x_right = cube_face_direction(0, 1.0, v);
            let negative_z_left = cube_face_direction(5, -1.0, v);
            assert!(positive_x_right.distance(negative_z_left) < 1.0e-12);
            assert!(
                (placeholder_height_meters(positive_x_right)
                    - placeholder_height_meters(negative_z_left))
                .abs()
                    < 1.0e-9
            );
        }

        let left = build_chunk_mesh(QuadtreeNode {
            face: 0,
            level: 1,
            x: 0,
            y: 0,
        });
        let right = build_chunk_mesh(QuadtreeNode {
            face: 0,
            level: 1,
            x: 1,
            y: 0,
        });
        for y in 0..CHUNK_GRID_VERTICES {
            let left_index = y * CHUNK_GRID_VERTICES + CHUNK_GRID_QUADS;
            let right_index = y * CHUNK_GRID_VERTICES;
            assert!(
                left.vertex_world_position(left_index, true)
                    .distance(right.vertex_world_position(right_index, true))
                    < 1.0
            );
        }
    }

    #[test]
    fn cube_sphere_vertices_are_on_the_planet_radius() {
        let mesh = CubeSphereMesh::new();
        assert_eq!(mesh.world_positions().len(), 6 * 33 * 33);
        assert_eq!(mesh.indices().len(), 6 * 32 * 32 * 6);
        assert!(
            mesh.world_positions()
                .iter()
                .all(|position| (position.length() - PLANET_RADIUS_METERS).abs() < 0.001)
        );
    }

    #[test]
    fn rebasing_uploads_relative_f32_offsets() {
        let mesh = CubeSphereMesh::new();
        let camera = OrbitCamera::default();
        let camera_position = camera.world_position();
        let vertices = mesh.rebased_vertices(camera_position);
        assert!(vertices.iter().all(|vertex| {
            vertex
                .camera_relative_position
                .iter()
                .all(|value| value.is_finite())
        }));
        assert!(
            vertices
                .iter()
                .any(|vertex| vertex.camera_relative_position[0] < -1_000_000.0)
        );
    }

    #[test]
    fn wheel_zoom_changes_fov_without_moving_the_camera_and_increases_screen_error() {
        let mut camera = OrbitCamera::default();
        let position = camera.world_position();
        assert_eq!(camera.look_sensitivity_scale(), 1.0);
        camera.set_vertical_fov_degrees(22.5);
        assert!((camera.look_sensitivity_scale() - 0.5).abs() < f64::EPSILON);
        camera.set_vertical_fov_degrees(45.0);
        let error_before = projected_error_pixels(
            QuadtreeNode::root(0),
            position,
            1_080,
            camera.vertical_fov_radians(),
        );
        camera.zoom(1_000.0);
        assert_eq!(camera.world_position(), position);
        assert!((camera.vertical_fov_radians() - MIN_VERTICAL_FOV_RADIANS).abs() < f64::EPSILON);
        let minimum_look_scale = MIN_VERTICAL_FOV_RADIANS / DEFAULT_VERTICAL_FOV_RADIANS;
        assert!(minimum_look_scale > 0.0);
        assert!((camera.look_sensitivity_scale() - minimum_look_scale).abs() < f64::EPSILON);
        let error_after = projected_error_pixels(
            QuadtreeNode::root(0),
            position,
            1_080,
            camera.vertical_fov_radians(),
        );
        assert!(error_after > error_before);

        let mut lod = PlanetLod::default();
        let detailed = lod.update_for_view(
            position,
            -position.normalize(),
            1.5,
            640,
            camera.vertical_fov_radians(),
        );
        assert_eq!(detailed.metrics.max_level, MAX_LOD_LEVEL);

        let direction_before_mouse_look = camera.direction_dvec3();
        camera.look_with_optical_sensitivity(0.0006, -0.0006);
        assert_eq!(camera.world_position(), position);
        assert_ne!(camera.direction_dvec3(), direction_before_mouse_look);

        camera.zoom(-1_000.0);
        assert!((camera.vertical_fov_radians().to_degrees() - 75.0).abs() < 1.0e-9);
    }

    #[test]
    fn one_pixel_mouse_look_remains_smooth_at_maximum_optical_zoom() {
        let mut camera = OrbitCamera::default();
        let position = DVec3::new(9_000_000.0, 3_000_000.0, 3_162_277.660_168_379_5);
        let look_at = DVec3::X * PLANET_RADIUS_METERS;
        camera.set_world_pose(position, look_at);
        camera.set_vertical_fov_degrees(super::MIN_VERTICAL_FOV_DEGREES);

        let target_relative = look_at - camera.world_position();
        let direction_before = camera.direction_dvec3();
        let view_before =
            CameraViewBasis::from_forward(direction_before).world_to_view(target_relative);
        camera.look_with_optical_sensitivity(0.0006, 0.0);
        let direction_after = camera.direction_dvec3();
        let view_after =
            CameraViewBasis::from_forward(direction_after).world_to_view(target_relative);

        let pixels_per_view_tangent = 640.0 / (2.0 * (camera.vertical_fov_radians() * 0.5).tan());
        let pixel_before = view_before.x / -view_before.z * pixels_per_view_tangent;
        let pixel_after = view_after.x / -view_after.z * pixels_per_view_tangent;
        let pixel_delta = (pixel_after - pixel_before).abs();

        assert!(direction_after.distance(direction_before) > 1.0e-10);
        assert!(direction_after.distance(direction_before) < 1.0e-9);
        assert!(
            (0.45..0.53).contains(&pixel_delta),
            "one physical mouse pixel moved the target by {pixel_delta} screen pixels"
        );
    }

    #[test]
    fn f64_view_rebase_preserves_small_lateral_offsets_at_orbital_distance() {
        for forward in [
            DVec3::new(-5.0, -3.0, -3.162_277_660_168_379_5),
            DVec3::Y,
            DVec3::NEG_Y,
        ] {
            let basis = CameraViewBasis::from_forward(forward);
            assert!(basis.forward.is_finite());
            assert!(basis.right.is_finite());
            assert!(basis.up.is_finite());
            assert!(basis.forward.dot(basis.right).abs() < 1.0e-12);
            assert!(basis.forward.dot(basis.up).abs() < 1.0e-12);
            assert!(basis.right.dot(basis.up).abs() < 1.0e-12);
        }

        let basis = CameraViewBasis::from_forward(DVec3::new(-5.0, -3.0, -3.162_277_660_168_379_5));
        let orbital_offset =
            basis.forward * 6_633_249.580_710_8 + basis.right * 0.0125 - basis.up * 0.021;
        let packed_view = basis.world_to_view(orbital_offset).as_vec3();
        assert!((f64::from(packed_view.x) - 0.0125).abs() < 1.0e-7);
        assert!((f64::from(packed_view.y) + 0.021).abs() < 1.0e-7);
    }

    /// The ridge fold subtracts the noise's mean absolute value and rescales by
    /// its spread, so that folding changes the field's character and nothing
    /// else. Both constants are properties of the noise, so if the noise ever
    /// changes they stop being true -- and the symptom would be ~10m of silent
    /// uplift on all land, varying wherever the land weight ramps.
    /// The normalisation undoes the variance a two-field blend loses, so it is
    /// a function of the strength and not a free knob. Setting the strength
    /// without following it here adds silent amplitude to every octave -- which
    /// is exactly the mistake the mountain-relief sweep made before this test
    /// existed, overstating the result by 31%.
    #[test]
    fn the_ridge_normalisation_follows_the_strength_it_undoes() {
        let strength = TERRAIN_DETAIL_RIDGE_STRENGTH;
        let expected = 1.0 / ((1.0 - strength) * (1.0 - strength) + strength * strength).sqrt();
        assert!(
            (TERRAIN_DETAIL_RIDGE_NORMALISATION - expected).abs() < 1.0e-4,
            "at strength {strength} the normalisation should be {expected}, not {}",
            TERRAIN_DETAIL_RIDGE_NORMALISATION
        );
    }

    /// A literal read off a spreadsheet goes stale the moment an octave count,
    /// a roughness or a tilt moves. Re-derive it from the series it bounds.
    #[test]
    fn the_ladder_amplitude_bound_is_the_series_it_bounds() {
        use super::{
            TERRAIN_DETAIL_OCTAVES, TERRAIN_DETAIL_ROUGHNESS,
            TERRAIN_DETAIL_START_WAVELENGTH_METERS, TERRAIN_DETAIL_TOTAL_AMPLITUDE_METERS,
            terrain_detail_octave_tilt,
        };
        let mut sum = 0.0;
        let mut wavelength = TERRAIN_DETAIL_START_WAVELENGTH_METERS;
        for _ in 0..TERRAIN_DETAIL_OCTAVES {
            sum += wavelength * TERRAIN_DETAIL_ROUGHNESS * terrain_detail_octave_tilt(wavelength);
            wavelength *= 0.5;
        }
        assert!(
            (TERRAIN_DETAIL_TOTAL_AMPLITUDE_METERS - sum).abs() < 1.0,
            "the ladder sums to {sum}m, not {TERRAIN_DETAIL_TOTAL_AMPLITUDE_METERS}m"
        );
        // It is a ceiling the ray path searches to, so it must not be loose:
        // an overstated reach is spread over the same fixed sample count.
        assert!(TERRAIN_DETAIL_TOTAL_AMPLITUDE_METERS >= sum * 0.99);
    }

    #[test]
    fn sparse_source_detail_matches_its_parent_at_the_shared_border() {
        let level_seven_x = 21.0;
        let level_seven_y = 20.5;
        let border_face_uv = [
            level_seven_x * 2.0 / 128.0 - 1.0,
            level_seven_y * 2.0 / 128.0 - 1.0,
        ];
        let child_spacing = continuous_baked_sample_spacing_meters(border_face_uv, 7, 4);
        let parent_spacing = continuous_baked_sample_spacing_meters(border_face_uv, 6, 4);
        assert!(
            (child_spacing - parent_spacing).abs() < f64::EPSILON,
            "child detail spacing {child_spacing} did not collapse to parent {parent_spacing}"
        );

        let interior_face_uv = [
            (level_seven_x + 0.25) * 2.0 / 128.0 - 1.0,
            level_seven_y * 2.0 / 128.0 - 1.0,
        ];
        assert!(
            (continuous_baked_sample_spacing_meters(interior_face_uv, 7, 4)
                - super::baked_sample_spacing_meters(7))
            .abs()
                < f64::EPSILON,
            "detail did not reach the child source level outside the edge fade"
        );
    }

    /// The long-wave boost is deliberately neutral while ETOPO is evaluated.
    /// Keep the dormant tilt function uniform so merely changing wavelength
    /// cannot reintroduce large random basins.
    #[test]
    fn the_disabled_spectral_tilt_leaves_every_octave_unboosted() {
        use super::{
            TERRAIN_DETAIL_LONG_GAIN, TERRAIN_DETAIL_TILT_TAPER_METERS, terrain_detail_octave_tilt,
        };
        assert!(
            (terrain_detail_octave_tilt(TERRAIN_DETAIL_TILT_TAPER_METERS) - 1.0).abs() < 1.0e-6
        );
        assert!(terrain_detail_octave_tilt(TERRAIN_DETAIL_TILT_TAPER_METERS * 0.5) == 1.0);
        assert!(terrain_detail_octave_tilt(1.0) == 1.0);
        assert_eq!(TERRAIN_DETAIL_LONG_GAIN, 1.0);
        assert_eq!(
            terrain_detail_octave_tilt(TERRAIN_DETAIL_START_WAVELENGTH_METERS),
            1.0
        );
        // Monotone, so no octave is louder than a longer one.
        let mut previous = f64::MAX;
        let mut wavelength = TERRAIN_DETAIL_START_WAVELENGTH_METERS;
        for _ in 0..TERRAIN_DETAIL_OCTAVES {
            let amplitude =
                wavelength * TERRAIN_DETAIL_ROUGHNESS * terrain_detail_octave_tilt(wavelength);
            assert!(amplitude < previous, "octave {wavelength}m is not quieter");
            previous = amplitude;
            wavelength *= 0.5;
        }
    }

    #[test]
    fn the_ridge_fold_is_centred_against_the_noise_it_folds() {
        let mut values = Vec::new();
        for x in 0..60 {
            for y in 0..60 {
                for z in 0..60 {
                    let fraction = DVec3::new(
                        f64::from(x) * 0.0173,
                        f64::from(y) * 0.0311,
                        f64::from(z) * 0.0511,
                    );
                    values.push(
                        super::terrain_detail_value_noise_f64(
                            glam::IVec3::new(x / 7, y / 7, z / 7),
                            fraction,
                        )
                        .value,
                    );
                }
            }
        }
        let count = values.len() as f64;
        let mean = values.iter().sum::<f64>() / count;
        let variance = values.iter().map(|v| (v - mean).powi(2)).sum::<f64>() / count;
        let sd = variance.sqrt();
        // The fold works on a *softened* absolute value, so the centring and
        // rescaling constants are properties of that, not of `abs`.
        let softened: Vec<f64> = values
            .iter()
            .map(|value| {
                (value * value + TERRAIN_DETAIL_RIDGE_SOFTNESS * TERRAIN_DETAIL_RIDGE_SOFTNESS)
                    .sqrt()
            })
            .collect();
        let softened_mean = softened.iter().sum::<f64>() / count;
        let softened_sd = (softened
            .iter()
            .map(|value| (value - softened_mean).powi(2))
            .sum::<f64>()
            / count)
            .sqrt();
        let sd_ratio = sd / softened_sd;
        assert!(
            (softened_mean - TERRAIN_DETAIL_RIDGE_CENTRE).abs() < 0.005,
            "ridge centre {TERRAIN_DETAIL_RIDGE_CENTRE} but the softened fold averages \
             {softened_mean}"
        );
        assert!(
            (sd_ratio - TERRAIN_DETAIL_RIDGE_SCALE).abs() < 0.02,
            "ridge scale {TERRAIN_DETAIL_RIDGE_SCALE} but the softened ratio is {sd_ratio}"
        );

        // And the fold itself must come out centred and the same size, which is
        // what keeps the amplitude discipline above intact.
        let folded: Vec<f64> = values
            .iter()
            .map(|value| {
                super::terrain_detail_ridge(super::DetailNoise {
                    value: *value,
                    gradient: DVec3::ZERO,
                })
                .value
            })
            .collect();
        let folded_mean = folded.iter().sum::<f64>() / count;
        let folded_sd = (folded
            .iter()
            .map(|v| (v - folded_mean).powi(2))
            .sum::<f64>()
            / count)
            .sqrt();
        assert!(
            folded_mean.abs() < 0.01,
            "fold is off-centre: {folded_mean}"
        );
        assert!(
            (folded_sd / sd - 1.0).abs() < 0.05,
            "fold changed the RMS: {folded_sd} vs {sd}"
        );
        let strength = TERRAIN_DETAIL_RIDGE_STRENGTH;
        let expected = 1.0 / ((1.0 - strength).powi(2) + strength.powi(2)).sqrt();
        assert!(
            (TERRAIN_DETAIL_RIDGE_NORMALISATION - expected).abs() < 1.0e-5,
            "normalisation {TERRAIN_DETAIL_RIDGE_NORMALISATION} does not match strength {strength}"
        );
    }

    #[test]
    #[ignore = "diagnostic: what slopes the synthesised ladder actually produces"]
    fn print_detail_slope_distribution() {
        // Finite-difference the ladder over a metre, which is the scale the
        // per-pixel normal works at, and report the distribution of
        // `1 - cos(angle)` -- the exact quantity the material rock threshold
        // is compared against.
        let base =
            DVec3::new(-0.9859869836836004, 0.07585910343295443, -0.148576796414729).normalize();
        let east = base.cross(DVec3::Y).normalize();
        let north = base.cross(east).normalize();
        let step_meters = 1.0;
        let mut slopes = Vec::new();
        for i in 0..300 {
            for j in 0..300 {
                let offset = east * (f64::from(i) * 7.0) + north * (f64::from(j) * 7.0);
                let here = (base * PLANET_RADIUS_METERS + offset).normalize();
                let along_east =
                    (base * PLANET_RADIUS_METERS + offset + east * step_meters).normalize();
                let along_north =
                    (base * PLANET_RADIUS_METERS + offset + north * step_meters).normalize();
                let spacing = super::baked_sample_spacing_meters(4);
                // A mountain, so every octave has its headroom.
                let macro_height = 3_000.0;
                let h = terrain_detail_meters(here, spacing, macro_height);
                let grade_east =
                    (terrain_detail_meters(along_east, spacing, macro_height) - h) / step_meters;
                let grade_north =
                    (terrain_detail_meters(along_north, spacing, macro_height) - h) / step_meters;
                let grade = (grade_east * grade_east + grade_north * grade_north).sqrt();
                slopes.push(1.0 - 1.0 / (1.0 + grade * grade).sqrt());
            }
        }
        slopes.sort_by(f64::total_cmp);
        let at = |q: f64| slopes[((slopes.len() - 1) as f64 * q) as usize];
        println!(
            "slope 1-cos:  p50={:.5} p90={:.5} p99={:.5} p999={:.5} max={:.5}",
            at(0.5),
            at(0.9),
            at(0.99),
            at(0.999),
            slopes[slopes.len() - 1]
        );
        let above = |t: f64| {
            slopes.iter().filter(|s| **s >= t).count() as f64 / slopes.len() as f64 * 100.0
        };
        println!(
            "  above rock threshold 0.10: {:.3}%   fully rock at 0.42: {:.4}%",
            above(0.10),
            above(0.42)
        );
    }

    /// The whole point of the integer hash is that both sides can reproduce it
    /// exactly. These are the values this build produces; if a refactor moves
    /// them, the shader has to move with it or the camera goes back to
    /// colliding with terrain nobody can see.
    #[test]
    fn the_detail_hash_is_pinned_and_reproducible() {
        assert_eq!(super::detail_mix(1), 0x9e36_45df);
        assert_eq!(super::detail_mix(0xffff_ffff), 0x61c8_45de);
        assert_eq!(super::detail_avalanche(0x9e37_79b9), 0xc10e_1b5d);
        // A bare multiply fixes zero, which is why every axis carries its own
        // salt rather than leaving one able to hash to zero.
        assert_eq!(super::detail_mix(0), 0);
    }

    /// A hash that is merely "noise of the right amplitude" is what put the
    /// CPU and the renderer on different planets, so check the properties the
    /// ladder actually relies on rather than assuming them.
    #[test]
    fn the_detail_hash_is_centred_and_decorrelates_between_neighbours() {
        let corner = |x: i32, y: i32, z: i32| {
            super::detail_corner(
                super::detail_axis_hashes(x, 0x27d4_eb2f)[0],
                super::detail_axis_hashes(y, 0x9e37_79b9)[0],
                super::detail_axis_hashes(z, 0x85eb_ca6b)[0],
            )
        };
        let mut values = Vec::new();
        let mut neighbours = Vec::new();
        let mut diagonal = Vec::new();
        for x in -12..12 {
            for y in -12..12 {
                for z in -12..12 {
                    values.push(corner(x, y, z));
                    neighbours.push(corner(x + 1, y, z));
                    // Cells on the diagonal are where a symmetric combine
                    // (plain x ^ y ^ z) collapses, and it shows as a lattice.
                    diagonal.push(corner(y, x, z));
                }
            }
        }
        let count = values.len() as f64;
        let mean = values.iter().sum::<f64>() / count;
        assert!(mean.abs() < 0.02, "hash is off-centre: {mean}");
        let variance = values
            .iter()
            .map(|value| (value - mean).powi(2))
            .sum::<f64>()
            / count;
        // Uniform on [-1, 1) has variance 1/3.
        assert!((variance - 1.0 / 3.0).abs() < 0.02, "variance {variance}");
        assert!(values.iter().all(|value| (-1.0..1.0).contains(value)));

        let correlation = |other: &[f64]| {
            let other_mean = other.iter().sum::<f64>() / count;
            let covariance: f64 = values
                .iter()
                .zip(other)
                .map(|(left, right)| (left - mean) * (right - other_mean))
                .sum::<f64>()
                / count;
            let other_variance = other
                .iter()
                .map(|value| (value - other_mean).powi(2))
                .sum::<f64>()
                / count;
            covariance / (variance * other_variance).sqrt()
        };
        assert!(
            correlation(&neighbours).abs() < 0.05,
            "adjacent cells correlate: {}",
            correlation(&neighbours)
        );
        assert!(
            correlation(&diagonal).abs() < 0.05,
            "the combine is symmetric in x and y: {}",
            correlation(&diagonal)
        );
    }

    #[test]
    fn view_space_round_trips_back_to_the_world_it_came_from() {
        // The surface probe reconstructs planet-frame points from view-space
        // rays, so a sign slip in the inverse would displace every probed
        // point consistently -- which is exactly the kind of error that still
        // produces plausible-looking numbers.
        let basis = CameraViewBasis::from_forward_and_up(
            DVec3::new(0.3, -0.9, 0.31).normalize(),
            DVec3::new(0.1, 0.2, 0.97).normalize(),
        );
        for vector in [
            DVec3::new(1.0, 0.0, 0.0),
            DVec3::new(0.0, 1.0, 0.0),
            DVec3::new(0.0, 0.0, 1.0),
            DVec3::new(-1_234.5, 6_789.0, -42.0),
        ] {
            let round_trip = basis.view_to_world(basis.world_to_view(vector));
            assert!(
                round_trip.distance(vector) < 1.0e-9,
                "{vector} {round_trip}"
            );
        }
        // Straight ahead in view space is -z, and it must come back as the
        // camera's forward axis rather than its opposite.
        let ahead = basis.view_to_world(DVec3::new(0.0, 0.0, -100.0));
        assert!(ahead.normalize().dot(basis.forward) > 0.999_999_999);
    }

    #[test]
    fn planet_rotation_transforms_camera_and_sun_into_a_stable_local_frame() {
        let camera = OrbitCamera::default();
        let rotation = planet_rotation_radians(PLANET_ROTATION_PERIOD_SECONDS * 0.25);
        let world_position = camera.world_position();
        let local_position = camera.planet_frame_world_position(rotation);
        assert!((local_position.length() - world_position.length()).abs() < 1.0e-8);
        assert!(local_position.distance(world_position) > 1_000_000.0);

        let world_sun = DVec3::new(0.4, 0.7, 0.6).normalize();
        let local_sun = planet_local_vector(world_sun, rotation);
        let world_camera_direction = world_position.normalize();
        assert!(
            (local_position.normalize().dot(local_sun) - world_camera_direction.dot(world_sun))
                .abs()
                < 1.0e-12
        );
    }

    #[test]
    fn default_sun_uses_earth_solstice_declination() {
        let sun_direction = default_sun_direction();
        let solar_declination = sun_direction.dot(DVec3::Y).asin();

        assert!((sun_direction.length() - 1.0).abs() < 1.0e-12);
        assert!((solar_declination - EARTH_AXIAL_TILT_RADIANS).abs() < 1.0e-12);
    }

    #[test]
    fn free_look_changes_orientation_without_moving_the_camera() {
        let mut camera = OrbitCamera::default();
        let position = camera.world_position();
        let before = camera.view_projection(1.0);
        camera.look(0.25, -0.1);
        assert_eq!(camera.world_position(), position);
        assert_ne!(camera.view_projection(1.0), before);
    }

    #[test]
    fn terrain_up_keeps_a_tangent_flight_horizon_horizontal() {
        let position = DVec3::X * (PLANET_RADIUS_METERS + 1_524.0);
        let mut camera = OrbitCamera::default();
        camera.set_world_pose_with_up(position, position + DVec3::Z, DVec3::X);
        let uniform = CameraUniform::from_camera(
            &camera,
            1.5,
            DVec3::new(0.4, 0.7, 0.6).normalize(),
            0.0,
            0.0,
            RenderDebugMode::Final,
            FlatTriangleOutlineMode::Dark,
            0.0,
        );

        assert!(
            Vec3::from_array(uniform.camera_forward[..3].try_into().unwrap()).distance(Vec3::Z)
                < 1.0e-6
        );
        assert!(
            Vec3::from_array(uniform.camera_right[..3].try_into().unwrap()).distance(Vec3::Y)
                < 1.0e-6
        );
        assert!(
            Vec3::from_array(uniform.camera_up[..3].try_into().unwrap()).distance(Vec3::X) < 1.0e-6
        );
    }

    #[test]
    fn flat_triangle_outline_mode_cycles_and_is_carried_by_the_camera_uniform() {
        let camera = OrbitCamera::default();
        let uniform = |mode| {
            CameraUniform::from_camera(
                &camera,
                1.0,
                default_sun_direction(),
                0.0,
                0.0,
                RenderDebugMode::FlatTriangles,
                mode,
                0.0,
            )
        };

        assert_eq!(
            FlatTriangleOutlineMode::Dark.next(),
            FlatTriangleOutlineMode::Off
        );
        assert_eq!(
            FlatTriangleOutlineMode::Off.next(),
            FlatTriangleOutlineMode::BlackRed
        );
        assert_eq!(
            FlatTriangleOutlineMode::BlackRed.next(),
            FlatTriangleOutlineMode::Dark
        );
        assert_eq!(
            uniform(FlatTriangleOutlineMode::Off).flat_triangle_options[0],
            0.0
        );
        assert_eq!(
            uniform(FlatTriangleOutlineMode::Dark).flat_triangle_options[0],
            1.0
        );
        assert_eq!(
            uniform(FlatTriangleOutlineMode::BlackRed).flat_triangle_options[0],
            2.0
        );
    }

    #[test]
    fn low_flight_lod_covers_every_sampled_ground_ray() {
        let camera_position = DVec3::X * (PLANET_RADIUS_METERS + 1_524.0);
        let forward = DVec3::Z;
        let up = DVec3::X;
        let basis = CameraViewBasis::from_forward_and_up(forward, up);
        let mut lod = PlanetLod::default();
        lod.set_terrain_height_range(TerrainHeightRange::new(
            -5_000.0 - GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS,
            9_000.0 * OUTMAP_TERRAIN_HEIGHT_SCALE
                + GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS * GLOBAL_TERRAIN_DETAIL_HEIGHT_SCALE,
        ));
        let update = lod.update_for_view_with_up(
            camera_position,
            forward,
            up,
            1.6,
            900,
            60.0_f64.to_radians(),
        );
        assert!(
            !update.metrics.budget_limited,
            "low-flight selection exhausted the terrain leaf budget"
        );
        for horizontal_step in -24..=24 {
            let screen_x = f64::from(horizontal_step) / 30.0;
            for vertical_step in -29..=-4 {
                let screen_y = f64::from(vertical_step) / 30.0;
                let ray = (basis.forward
                    + basis.right * screen_x * (60.0_f64.to_radians() * 0.5).tan() * 1.6
                    + basis.up * screen_y * (60.0_f64.to_radians() * 0.5).tan())
                .normalize();
                let closest_distance = -camera_position.dot(ray);
                let discriminant = closest_distance * closest_distance
                    - (camera_position.length_squared() - PLANET_RADIUS_METERS.powi(2));
                if discriminant < 0.0 {
                    continue;
                }
                let surface_direction =
                    (camera_position + ray * (closest_distance - discriminant.sqrt())).normalize();
                assert!(
                    update.active_nodes.iter().any(|node| {
                        let (normal, tangent_u, tangent_v) = cube_face_basis(node.face);
                        let normal_dot = surface_direction.dot(normal);
                        if normal_dot <= 0.0 {
                            return false;
                        }
                        let u = surface_direction.dot(tangent_u) / normal_dot;
                        let v = surface_direction.dot(tangent_v) / normal_dot;
                        let [u_min, v_min, u_max, v_max] = node.uv_bounds();
                        u >= u_min && u <= u_max && v >= v_min && v <= v_max
                    }),
                    "no active terrain node covers screen ray ({screen_x}, {screen_y})"
                );
            }
        }
    }

    #[test]
    fn downward_low_flight_sse_has_no_multi_level_topology_cliffs() {
        let camera_position = DVec3::X * (PLANET_RADIUS_METERS + 2_198.0);
        let forward = -DVec3::X;
        let up = DVec3::Z;
        let mut lod = PlanetLod::default();
        let update = lod.update_for_view_with_up(
            camera_position,
            forward,
            up,
            16.0 / 9.0,
            1_080,
            60.0_f64.to_radians(),
        );

        assert!(!update.metrics.budget_limited);
        assert!(update.metrics.max_level >= 10);
        assert!(update.metrics.max_level < MAX_LOD_LEVEL);
        for node in &update.active_nodes {
            let [u_min, v_min, u_max, v_max] = node.uv_bounds();
            let outside = (u_max - u_min) * 1.0e-5;
            for edge in 0..4 {
                for sample in 0..8 {
                    let amount = (f64::from(sample) + 0.5) / 8.0;
                    let u = u_min + (u_max - u_min) * amount;
                    let v = v_min + (v_max - v_min) * amount;
                    let (outside_u, outside_v) = match edge {
                        0 => (u, v_min - outside),
                        1 => (u_max + outside, v),
                        2 => (u, v_max + outside),
                        _ => (u_min - outside, v),
                    };
                    let direction = cube_face_direction(node.face, outside_u, outside_v);
                    let Some(neighbor) = update.active_nodes.iter().find(|candidate| {
                        let (normal, tangent_u, tangent_v) = cube_face_basis(candidate.face);
                        let normal_dot = direction.dot(normal);
                        if normal_dot <= 0.0 {
                            return false;
                        }
                        let candidate_u = direction.dot(tangent_u) / normal_dot;
                        let candidate_v = direction.dot(tangent_v) / normal_dot;
                        let [
                            candidate_u_min,
                            candidate_v_min,
                            candidate_u_max,
                            candidate_v_max,
                        ] = candidate.uv_bounds();
                        candidate_u >= candidate_u_min
                            && candidate_u <= candidate_u_max
                            && candidate_v >= candidate_v_min
                            && candidate_v <= candidate_v_max
                    }) else {
                        continue;
                    };
                    assert!(
                        node.level.abs_diff(neighbor.level) <= 2,
                        "L{} node touched L{} neighbor",
                        node.level,
                        neighbor.level,
                    );
                }
            }
        }
    }

    #[test]
    fn budget_limited_mountain_view_keeps_a_balanced_frontier() {
        // capture-001 from manual run 1785265652-40830, transformed into the
        // frozen planet frame used by the deterministic replay. The old
        // selector spent all 256 leaves on primary SSE demand before it tried
        // to balance the frontier, leaving runtime-relief gaps large enough to
        // expose the cleared solid-planet background.
        let camera_position = DVec3::new(
            1_957_011.518_563_716_7,
            2_098_111.804_991_835,
            2_793_801.144_456_436,
        );
        let camera_forward =
            DVec3::new(0.742_653_566_762_582_4, -0.519, -0.423_796_743_468_864_4).normalize();
        let mut lod = PlanetLod::default();
        lod.set_terrain_height_range(TerrainHeightRange::new(
            -5_000.0 - GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS,
            9_000.0 * OUTMAP_TERRAIN_FAR_HEIGHT_SCALE + GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS,
        ));
        lod.set_distance_reference_height(4_434.235_545_999_187);
        let update = lod.update_for_view_with_constraints(
            camera_position,
            camera_forward,
            camera_position.normalize(),
            16.0 / 9.0,
            720,
            34.290_380_625_028_99_f64.to_radians(),
            GeometricErrorRatio {
                baked: 0.053_6,
                ladder: TERRAIN_DETAIL_ROUGHNESS * 2.939_5,
            },
            &|_| MAX_LOD_LEVEL,
            Some(&|_| 6),
        );

        assert!(update.metrics.budget_limited);
        assert!(update.active_nodes.len() <= DEFAULT_MAX_ACTIVE_CHUNKS);
        let leaves = update.active_nodes.iter().copied().collect();
        assert!(
            unbalanced_coarse_neighbors(&leaves).is_empty(),
            "the shipping leaf budget left a multi-level topology cliff"
        );
    }

    #[test]
    fn source_limited_selection_covers_the_elevated_terrain_shell() {
        // capture-012 from manual run 1784065154-40230. The camera was 1,524m
        // above roughly 3,012m baked terrain when a near-field patch vanished.
        let world_position = DVec3::new(
            2_244_963.692_843_628,
            1_492_510.400_237_098_6,
            2_961_226.599_834_886,
        );
        let camera_position = planet_local_vector(world_position, 0.000_984_730_693_783_779_2);
        let up = camera_position.normalize();
        let forward = DVec3::new(-up.z, 0.0, up.x).normalize();
        let basis = CameraViewBasis::from_forward_and_up(forward, up);
        let mut lod = PlanetLod::default();
        lod.set_terrain_height_range(TerrainHeightRange::new(
            -5_000.0 - GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS,
            9_000.0 * OUTMAP_TERRAIN_HEIGHT_SCALE
                + GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS * GLOBAL_TERRAIN_DETAIL_HEIGHT_SCALE,
        ));
        // Preserve coverage for the source-limited selector used by orbital
        // SSE. Near flight deliberately bypasses this cap so sparse texture
        // availability cannot create a multi-level geometry cliff.
        let maximum_global_outmap_level = 6;
        let update = lod.update_for_view_with_up_and_level_limit(
            camera_position,
            forward,
            up,
            1.5,
            960,
            60.0_f64.to_radians(),
            &|_| maximum_global_outmap_level,
        );
        assert!(!update.metrics.budget_limited);

        let surface_radius = camera_position.length() - 1_524.0;
        for horizontal_step in -27..=27 {
            let screen_x = f64::from(horizontal_step) / 30.0;
            for vertical_step in -27..=0 {
                let screen_y = f64::from(vertical_step) / 30.0;
                let ray = (basis.forward
                    + basis.right * screen_x * (60.0_f64.to_radians() * 0.5).tan() * 1.5
                    + basis.up * screen_y * (60.0_f64.to_radians() * 0.5).tan())
                .normalize();
                let closest_distance = -camera_position.dot(ray);
                let discriminant = closest_distance * closest_distance
                    - (camera_position.length_squared() - surface_radius.powi(2));
                if discriminant < 0.0 {
                    continue;
                }
                let surface_direction =
                    (camera_position + ray * (closest_distance - discriminant.sqrt())).normalize();
                let covered = update.active_nodes.iter().any(|node| {
                    let (normal, tangent_u, tangent_v) = cube_face_basis(node.face);
                    let normal_dot = surface_direction.dot(normal);
                    if normal_dot <= 0.0 {
                        return false;
                    }
                    let u = surface_direction.dot(tangent_u) / normal_dot;
                    let v = surface_direction.dot(tangent_v) / normal_dot;
                    let [u_min, v_min, u_max, v_max] = node.uv_bounds();
                    u >= u_min && u <= u_max && v >= v_min && v <= v_max
                });
                assert!(
                    covered,
                    "no active terrain node covers elevated-shell screen ray ({screen_x}, {screen_y})"
                );
            }
        }
    }

    #[test]
    fn global_terrain_detail_is_bounded_and_direction_based() {
        let directions = [
            DVec3::X,
            DVec3::Y,
            DVec3::Z,
            DVec3::new(0.27, -0.61, 0.74).normalize(),
        ];
        for direction in directions {
            let detail = global_terrain_detail_meters(direction);
            assert!(detail.abs() <= GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS);
            assert!((detail - global_terrain_detail_meters(direction * 7.0)).abs() < 1.0e-8);
        }
    }

    #[test]
    fn global_terrain_detail_uses_continuous_non_periodic_value_noise() {
        let position = Vec3::new(12.345, -67.89, 0.125);
        let base = terrain_detail_value_noise(position);
        assert!((-1.0..=1.0).contains(&base));
        assert!(
            (base - terrain_detail_value_noise(position + Vec3::new(0.03, 0.0, 0.0))).abs() < 0.2
        );
        assert_ne!(
            terrain_detail_value_noise(position + Vec3::new(0.0, 0.4, 0.0)),
            terrain_detail_value_noise(position + Vec3::new(0.0, 0.0, 0.4)),
        );
    }

    #[test]
    fn outmap_detail_preserves_ocean_and_coastline() {
        // Most of the planet draws from the dense L4 pyramid.
        const L4_SPACING: f64 = 2.0 * PLANET_RADIUS_METERS / (16.0 * 128.0);
        let direction = DVec3::new(0.27, -0.61, 0.74).normalize();
        assert_eq!(
            outmap_surface_height_meters(-800.0, direction, 1_524.0, L4_SPACING),
            0.0
        );
        // Headroom is asked per octave, and what has to hold is that the whole
        // ladder's worst case still cannot reach sea level -- thirteen octaves
        // each individually safe are not collectively safe, which is where the
        // factor of eight comes from.
        for step in 1..2000 {
            let height = f64::from(step) * 2.0;
            let mut admitted = 0.0;
            let mut wavelength = TERRAIN_DETAIL_START_WAVELENGTH_METERS;
            for _ in 0..TERRAIN_DETAIL_OCTAVES {
                let amplitude = wavelength * TERRAIN_DETAIL_ROUGHNESS;
                admitted += amplitude * super::terrain_detail_octave_headroom(height, amplitude);
                wavelength *= 0.5;
            }
            assert!(
                admitted <= height,
                "at {height}m the ladder can admit {admitted}m of relief"
            );
        }
        // And low ground must still get its *small* hills, which is what a
        // single scalar weight took away once the ladder reached 4km.
        let hummock = 16.0 * TERRAIN_DETAIL_ROUGHNESS;
        assert!(
            super::terrain_detail_octave_headroom(40.0, hummock) > 0.9,
            "a 40m plain gets only {} of its 16m hummocks",
            super::terrain_detail_octave_headroom(40.0, hummock)
        );
        // ...and none of the hills it has no room for.
        let big_hill = TERRAIN_DETAIL_START_WAVELENGTH_METERS * TERRAIN_DETAIL_ROUGHNESS;
        assert!(super::terrain_detail_octave_headroom(40.0, big_hill) < 0.02);
        // Above the weighting it is applied whole.
        let scaled_macro_height = scaled_outmap_macro_height_meters(400.0, 1_524.0);
        assert_eq!(
            detailed_outmap_land_height_meters(400.0, direction, 1_524.0, L4_SPACING),
            scaled_macro_height
                + GLOBAL_TERRAIN_DETAIL_HEIGHT_SCALE * global_terrain_detail_meters(direction)
                + terrain_detail_meters(direction, L4_SPACING, scaled_macro_height)
        );
    }

    /// The whole point of the CPU ladder: it has to see the relief the shader
    /// displaces with. A camera placed from a surface height that ignores it
    /// ends up inside the ground.
    #[test]
    fn cpu_clearance_sees_the_synthesised_relief() {
        // The measured landing site: biome 6, 919.8m baked.
        let direction =
            DVec3::new(-0.9859869836836004, 0.07585910343295443, -0.148576796414729).normalize();
        let baked_meters = 919.8;
        // The ladder fills exactly the band the baked data cannot carry, so
        // what it contributes depends on which pyramid level is under the
        // point. The sparse corridor reaches L18, whose samples are 0.24m
        // apart, and there the ladder must add essentially nothing: the baker's
        // erosion already describes that ground and synthesising over it would
        // be the same hills twice.
        let corridor = outmap_surface_height_meters(
            baked_meters,
            direction,
            40.0,
            super::baked_sample_spacing_meters(18),
        );
        let scaled_baked_meters = scaled_outmap_macro_height_meters(baked_meters, 40.0);
        assert!(
            (corridor - scaled_baked_meters).abs() < 0.5,
            "the ladder added {}m on top of L18 baked erosion",
            corridor - scaled_baked_meters
        );
        // Away from the corridor the finest baked data is L4, 3.9km samples,
        // which carries nothing below about 7.8km. There the ladder is the only
        // thing there is, and it has to deliver.
        let dense = outmap_surface_height_meters(
            baked_meters,
            direction,
            40.0,
            super::baked_sample_spacing_meters(4),
        );
        let detail = dense - scaled_baked_meters;
        assert!(
            detail.abs() > 0.5,
            "clearance saw only {detail}m of synthesised relief over L4 data"
        );
        // This used to pin a 920..940m bracket read off a render. That number
        // was a property of one particular noise field, so it went stale the
        // moment the ladder changed, and it only ever checked one point.
        // Agreement with the render is now measured directly and continuously
        // by the surface probe -- see the `stand_on_ground` scenario, which
        // holds the camera's clearance above the *drawn* ground to 2m +/- 0.5m
        // in both render paths. What is left here is what can be checked
        // without a GPU: that the ladder contributes, and that it stays inside
        // the amplitude its own constants allow.
        assert!(
            (scaled_baked_meters - 400.0..=scaled_baked_meters + 400.0).contains(&dense),
            "clearance puts the landing site at {dense}m, implausibly far from \
             the {scaled_baked_meters}m scaled terrain under it"
        );
        // Self-similar amplitude sums to twice the first octave, so nothing the
        // ladder produces may exceed that however the octaves line up.
        let bound = TERRAIN_DETAIL_START_WAVELENGTH_METERS * TERRAIN_DETAIL_ROUGHNESS * 2.0;
        for offset in [0.0_f64, 0.3, 1.1, 2.7] {
            let probe = DVec3::new(
                direction.x + offset * 1.0e-4,
                direction.y - offset * 0.7e-4,
                direction.z + offset * 0.4e-4,
            )
            .normalize();
            assert!(
                terrain_detail_meters(probe, super::baked_sample_spacing_meters(4), 3_000.0).abs()
                    <= bound
            );
        }
    }

    /// The near plane used to scale with height above *sea level*, so standing
    /// on 920 m of ground pushed it 9.2 m out and clipped the whole foreground.
    /// The hole read convincingly as unlit terrain, which is how it survived
    /// being looked at.
    #[test]
    fn near_plane_follows_height_above_ground_not_sea_level() {
        // Eye level on high ground has to clip at centimetres, not metres.
        let standing = near_plane_meters(923.0, 920.0);
        assert!(
            standing <= 0.1,
            "near plane {standing}m clips the foreground of a camera 3m above the ground"
        );
        // Sea-level ground is unaffected: same height, same near plane as before.
        assert_eq!(near_plane_meters(3.0, 0.0), near_plane_meters(923.0, 920.0));
        // Distance still scales with clearance below the 10m ceiling, which the
        // old formula reached at 1km and everything above it shares.
        assert!(near_plane_meters(900.0, 0.0) > near_plane_meters(100.0, 0.0));
        assert_eq!(near_plane_meters(400_000.0, 0.0), 10.0);
        // A camera below the surface must not produce a negative or zero plane.
        assert!(near_plane_meters(900.0, 920.0) >= 0.05);
    }

    #[test]
    fn terrain_height_scale_is_fixed_and_preserves_bathymetry() {
        for altitude in [
            0.0,
            OUTMAP_TERRAIN_HEIGHT_BLEND_START_METERS,
            (OUTMAP_TERRAIN_HEIGHT_BLEND_START_METERS + OUTMAP_TERRAIN_HEIGHT_BLEND_END_METERS)
                * 0.5,
            OUTMAP_TERRAIN_HEIGHT_BLEND_END_METERS,
            2_000_000.0,
        ] {
            assert_eq!(
                outmap_terrain_height_scale(altitude),
                OUTMAP_TERRAIN_NEAR_HEIGHT_SCALE
            );
        }
        assert_eq!(
            OUTMAP_TERRAIN_NEAR_HEIGHT_SCALE,
            OUTMAP_TERRAIN_FAR_HEIGHT_SCALE
        );
        assert_eq!(scaled_outmap_macro_height_meters(-800.0, 0.0), -800.0);
        assert_eq!(scaled_outmap_macro_height_meters(0.0, 0.0), 0.0);
        assert_eq!(
            scaled_outmap_macro_height_meters(400.0, 0.0),
            400.0 * OUTMAP_TERRAIN_NEAR_HEIGHT_SCALE
        );
    }

    #[test]
    fn projected_error_uses_the_exaggerated_land_shell() {
        let node = QuadtreeNode::root(0);
        let camera = DVec3::X * (PLANET_RADIUS_METERS + 12_000.0);
        let baseline_error = projected_error_pixels_with_height_range(
            node,
            camera,
            427,
            60.0_f64.to_radians(),
            TerrainHeightRange::default(),
        );
        let exaggerated_error = projected_error_pixels_with_height_range(
            node,
            camera,
            427,
            60.0_f64.to_radians(),
            TerrainHeightRange::new(
                -5_000.0 - GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS,
                9_000.0 * OUTMAP_TERRAIN_HEIGHT_SCALE
                    + GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS * GLOBAL_TERRAIN_DETAIL_HEIGHT_SCALE,
            ),
        );

        assert!(exaggerated_error > baseline_error * 100.0);
    }

    #[test]
    fn captured_zoomed_low_flight_view_is_bounded() {
        // Worst sustained sample from manual run 1784106903-166364: the
        // 2.2-degree flight view selected 991 active chunks, retained 1,070
        // draw calls, and took 705ms. A narrow optical FOV must remain bounded
        // while still reaching the detail justified by its projected error.
        let world_position = DVec3::new(
            3_891_789.424_464_821,
            434_429.081_719_413_6,
            880_386.714_197_311_1,
        );
        let camera_position = planet_local_vector(world_position, 0.072_884_613_494_864_83);
        let up = camera_position.normalize();
        let forward = DVec3::new(-up.z, 0.0, up.x).normalize();
        let mut lod = PlanetLod::default();
        lod.set_terrain_height_range(TerrainHeightRange::new(
            -5_000.0 - GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS,
            9_000.0 * OUTMAP_TERRAIN_HEIGHT_SCALE
                + GLOBAL_TERRAIN_DETAIL_AMPLITUDE_METERS * GLOBAL_TERRAIN_DETAIL_HEIGHT_SCALE,
        ));

        let update = lod.update_for_view_with_up(
            camera_position,
            forward,
            up,
            640.0 / 427.0,
            427,
            2.236_187_176_989_754_f64.to_radians(),
        );

        assert!(!update.metrics.budget_limited);
        assert!(update.active_nodes.len() <= 256);
        assert!(update.metrics.max_level >= 10);
        assert!(update.metrics.max_level < MAX_LOD_LEVEL);
    }

    #[test]
    fn default_look_tracks_orbital_down_with_a_persistent_mouse_offset() {
        let mut camera = OrbitCamera::default();
        assert!(
            camera
                .direction_dvec3()
                .distance(-camera.world_position().normalize())
                < 1.0e-12
        );

        camera.look(0.25, -0.1);
        let (down_before, right_before, up_before) = camera.orbit_look_frame();
        let relative_before = [
            camera.direction_dvec3().dot(down_before),
            camera.direction_dvec3().dot(right_before),
            camera.direction_dvec3().dot(up_before),
        ];
        camera.orbit(0.4, 0.0);
        let (down_after, right_after, up_after) = camera.orbit_look_frame();
        let relative_after = [
            camera.direction_dvec3().dot(down_after),
            camera.direction_dvec3().dot(right_after),
            camera.direction_dvec3().dot(up_after),
        ];
        for (before, after) in relative_before.into_iter().zip(relative_after) {
            assert!((before - after).abs() < 1.0e-6);
        }
    }

    #[test]
    fn inclined_orbit_stays_in_one_plane_and_crosses_the_equator() {
        let mut camera = OrbitCamera::default();
        let inclination = 28.5_f64.to_radians();
        let radius = camera.orbit_radius_meters;

        camera.advance_inclined_orbit(std::f64::consts::FRAC_PI_2, inclination);
        let ascending = camera.world_position();
        camera.advance_inclined_orbit(std::f64::consts::PI, inclination);
        let descending = camera.world_position();

        for position in [ascending, descending] {
            assert!((position.length() - radius).abs() < 1.0e-6);
            assert!(
                (position.y * inclination.cos() - position.z * inclination.sin()).abs() < 1.0e-6
            );
        }
        assert!(ascending.y > 0.0);
        assert!(descending.y < 0.0);
    }

    #[test]
    fn waypoint_pose_preserves_f64_position_and_arbitrary_look_direction() {
        let mut camera = OrbitCamera::default();
        let position =
            DVec3::new(1.0, 2.0, -3.0).normalize() * (PLANET_RADIUS_METERS + 1_234.567_890_123);
        let look_at = DVec3::new(-81_234.5, 456_789.25, 12_345.75);
        camera.set_world_pose(position, look_at);

        assert!(camera.world_position().distance(position) < 1.0e-8);
        let expected_direction = (look_at - position).normalize();
        assert!(camera.direction_dvec3().distance(expected_direction) < 1.0e-12);
        assert!(camera.view_projection(1.5).is_finite());
    }

    fn camera_for_error(node: QuadtreeNode, target_error_pixels: f64) -> DVec3 {
        let mut near_radius = PLANET_RADIUS_METERS + 10.0;
        let mut far_radius = PLANET_RADIUS_METERS * 10_000.0;
        for _ in 0..100 {
            let radius = (near_radius + far_radius) * 0.5;
            let error =
                projected_error_pixels(node, DVec3::X * radius, 1_080, 45.0_f64.to_radians());
            if error > target_error_pixels {
                near_radius = radius;
            } else {
                far_radius = radius;
            }
        }
        DVec3::X * ((near_radius + far_radius) * 0.5)
    }
}
